<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
    CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;

class PZiyaret extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('pziyaret', $plugin);
		$this->setDescription('Oyuncunun pazarını ziyaret edin');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
				$apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

		$for = $apii->createCustomForm(function (Player $p, array $data = null) {
		$result = $data;
	if ($result === null) {
			return true;
		}

					$o = $data[0];
				if ($o == $p->getName()) {
                $p->sendMessage("§6Silver§fMcpe §7»§c Kendi pazarını ziyaret edemezsin.");
				}else{
                    $this->cfg = new Config($this->main->getDataFolder() . $o . ".json", Config::JSON);
                    $this->cfg = new Config($this->main->getDataFolder() . $this->cfg->get("AIsim") . ".json", Config::JSON);
                    if($this->cfg->get("PZ") != null){
                         $kor = explode(":", $this->cfg->get("PZ"));
                         $this->main->getServer()->loadLevel($this->cfg->get("AIsim"));
                         $world = $this->main->getServer()->getLevelByName($this->cfg->get("AIsim"));
                         $spawn = $world->getSafeSpawn();
                         $p->teleport($spawn, 0, 0);
                         $p->teleport(new Vector3((int) $kor[0], (int) $kor[1], (int) $kor[2]));
                          $p->sendMessage("§6Silver§fMcpe §7» §aPazar ziyaret ediliyor.");
                    }else{
                        $p->sendMessage("§6Silver§fMcpe §7»§c Oyuncunun pazar tabelası bulunamadı.");
                    }
                    
								
                   

			}


	});
		$for->setTitle("§6Silver§fMCPE §r- Pazar Ziyaret");

		$for->addInput("Oyuncu ismi");
		$for->sendToPlayer($p);


      return true;
	}



	}