<?php

namespace SilverMCPE\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\Position;

class isinlanTask extends Task{

    public function __construct($main, $p, $yer){
    	$this->main = $main;
        $this->p = $p;
        $this->yer = $yer;
    }
    public function onRun($tick){
    if ($this->yer == "tend") {
        $s = $this->main->endSüre[$this->p->getName()];
    
    $ys = $s - 1;
    if ($ys <= 0) {
       $this->main->üzatForm($this->p, $this->yer);
     }else{
      $this->main->endSüre[$this->p->getName()] = $ys;
      $this->p->sendPopup("§aKalan Süre:§b " . $ys);

     }
    }else{
         $s = $this->main->netherSüre[$this->p->getName()];
    
    $ys = $s - 1;
    if ($ys <= 0) {
       $this->main->üzatForm($this->p, $this->yer);
     }else{
         $this->p->sendPopup("§aKalan Süre:§b " . $ys);
      $this->main->netherSüre[$this->p->getName()] = $ys;
     }
    }
 
    }
}