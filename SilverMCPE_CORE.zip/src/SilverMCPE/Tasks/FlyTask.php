<?php

namespace SilverMCPE\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\Position;

class FlyTask extends Task{

    public function __construct($main, $p){
    	$this->main = $main;
        $this->p = $p;
    }
    public function onRun($tick){
        if ($this->p instanceof Player) {
            $sure = $this->main->FlySure[$this->p->getName()];
            $ysure = $sure - 1;
            $this->main->FlySure[$this->p->getName()] = $ysure;
            if ($ysure == 0) {
                                      $this->main->getScheduler()->cancelTask($this->main->FlyId[$this->p->getName()]);
                                      $this->p->sendMessage("§6Silver§fMcpe §7» §cFly Süreniz Doldu.");
                                      $this->p->setFlying(false);
                                      $this->p->setAllowFlight(false);
                                      unset($this->main->FlyId[$this->p->getName()]);
                   }else{
                    $this->p->sendPopup("§6Silver§fMcpe §7» §aUçuş Süreniz:§b " . $ysure . " §aSaniye");
                   }      
        }
         
    }
}