<?php

namespace SilverMCPE\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\Position;
use pocketmine\entity\{Zombie, Entity};
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\math\Vector3;


class MobTask extends Task{

    public function __construct($main, $x, $y, $z, $level, $mob){
    	$this->main = $main;
        $this->x = $x;
        $this->y = $y;
        $this->z = $z;
        $this->level = $level;
        $this->mobs = $mob;
    }
    public function onRun($tick){
    	$l = $this->main->getServer()->getLevelByName($this->level);
    	if ($l === null) return false;
        $nbt = Entity::createBaseNBT(new Vector3((int) $this->x, (int) $this->y, (int) $this->z));
        $entity = Entity::createEntity($this->mobs, $l, $nbt);
        $entity->spawnToAll();
    }
}