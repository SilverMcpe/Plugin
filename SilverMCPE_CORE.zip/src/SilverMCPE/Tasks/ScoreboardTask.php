<?php

namespace SilverMCPE\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\Position;
use pocketmine\utils\Config;
use jasonwynn10\ScoreboardAPI\Scoreboard;
use jasonwynn10\ScoreboardAPI\ScoreboardAPI;
use jasonwynn10\ScoreboardAPI\ScoreboardEntry;

class ScoreboardTask extends Task
{

    public function __construct($main)
    {
        $this->main = $main;

    }

    public function onRun($tick)
    {
       foreach ($this->main->getServer()->getOnlinePlayers() as $p){
           $this->cfg = new Config($this->main->getDataFolder() ."Oyuncu Verileri/" . $p->getName() . ".yml", Config::YAML);
           if($this->cfg->get("Scoreboard") || empty($this->cfg->get("Scoreboard"))){
               $api = $this->main->getServer()->getPluginManager()->getPlugin("ScoreboardAPI");
               $scoreboard = $api->createScoreboard("objective", "SilverMCPE", 10); //create scoreboard
               $line = 1; // line number
               $score = 1; // current score
               $type = ScoreboardEntry::TYPE_FAKE_PLAYER; // other types are TYPE_PLAYER and TYPE_ENTITY
               $identifier = "Deneme test wuuuuu"; // this is a string for fake players but must be an entity id for other types
           	$entry = $scoreboard->createEntry($line, $score, $type, $identifier);
               $scoreboard->addEntry($entry);
			   $line = 2; // line number
			   $score = 2; // current score
			   $type = ScoreboardEntry::TYPE_FAKE_PLAYER; // other types are TYPE_PLAYER and TYPE_ENTITY
			   $identifier = "Deneme test wuuuuu2222"; // this is a string for fake players but must be an entity id for other types
			   $entry = $scoreboard->createEntry($line, $score, $type, $identifier);
			   $scoreboard->addEntry($entry);
               $api->sendScoreboard($scoreboard, [$p]);
           }


       }

    }
}