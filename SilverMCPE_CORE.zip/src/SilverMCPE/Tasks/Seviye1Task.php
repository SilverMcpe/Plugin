<?php

namespace SilverMCPE\Tasks;

use pocketmine\tile\Sign;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\block\Chest;
use pocketmine\utils\Config;

class Seviye1Task extends Task{
    

    private static $main;
    
    public function __construct($p){
        self::$main = $p;
      
    }
    
    public function onRun($tick){
		self::$main->getServer()->dispatchCommand(new ConsoleCommandSender(), "time set day");
        $so = self::$main->getServer()->getOnlinePlayers();
        foreach ($so as $ao) {
			$oc = new Config(self::$main->getDataFolder() . $ao->getName() . ".yml", Config::YAML);
			$sv = $oc->get("1");
			if(isset($sv) && is_array($sv)){
			
				foreach ($sv as $fab){

					foreach (self::$main->getServer()->getLevels() as $l) {
						if ($l->getFolderName() == "[fab]". $ao->getName()){


							foreach ($l->getTiles() as $baa) {
								if ($baa instanceof Sign) {
									if ($fab == $baa->getLine(1)) {
										$tile = $baa->getBlock()->getSide(0);
										if ($tile instanceof Chest) {

											$t = $l->getTile($tile);
											if ($fab == "Vip") {
												if ($ao->hasPermission("fabrika.vip")){
													$s = ["266", "265", "264", "263", "388"];
													$id = $s[array_rand($s)];
													$t->getInventory()->addItem(Item::get($id, 0, 1));
													$ao->sendMessage(Item::get($id, 0, 1)->getName());

												}
											}
											if ($fab == "Kömür") {
												$t->getInventory()->addItem(Item::get(Item::COAL, 0, 1));
											}
											if ($fab == "Demir") {
												$t->getInventory()->addItem(Item::get(Item::IRON_INGOT, 0, 1));
											}
											if ($fab == "Altın") {
												$t->getInventory()->addItem(Item::get(Item::GOLD_INGOT, 0, 1));
											}
											if ($fab == "Elmas") {
												$t->getInventory()->addItem(Item::get(Item::DIAMOND, 0, 1));
											}
											if ($fab == "Zümrüt") {
												$t->getInventory()->addItem(Item::get(Item::EMERALD, 0, 1));
											}
											if ($fab == "Çim") {
												$t->getInventory()->addItem(Item::get(Item::GRASS, 0, 1));
											}
											if ($fab == "Cam") {
												$t->getInventory()->addItem(Item::get(Item::GLASS, 0, 1));
											}
											if ($fab == "Kum") {
												$t->getInventory()->addItem(Item::get(Item::SAND, 0, 1));
											}
											if ($fab == "Kırıktaş") {
												$t->getInventory()->addItem(Item::get(Item::COBBLESTONE, 0, 1));
											}
											if ($fab == "Taş") {
												$t->getInventory()->addItem(Item::get(Item::STONE, 0, 1));
											}
											if ($fab == "Toprak") {
												$t->getInventory()->addItem(Item::get(Item::DIRT, 0, 1));
											}
											if ($fab == "Tohum") {
												$t->getInventory()->addItem(Item::get(Item::WHEAT_SEEDS, 0, 1));
											}
											if ($fab == "Buğday") {
												$t->getInventory()->addItem(Item::get(Item::WHEAT, 0, 1));
											}
											if ($fab == "Havuç") {
												$t->getInventory()->addItem(Item::get(Item::CARROT, 0, 1));
											}
											if ($fab == "Patates") {
												$t->getInventory()->addItem(Item::get(Item::POTATO, 0, 1));
											}
											if ($fab == "Ekmek") {
												$t->getInventory()->addItem(Item::get(Item::BREAD, 0, 1));
											}
											if ($fab == "Elma") {
												$t->getInventory()->addItem(Item::get(Item::APPLE, 0, 1));
											}


										} else {

										}
									} else {

									}
								} else {

								}
							}
					}
					}
					}
				
		}
		}
}
}