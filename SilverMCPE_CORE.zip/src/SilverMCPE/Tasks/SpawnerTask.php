<?php

namespace SilverMCPE\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\Position;

class SpawnerTask extends Task{

    public function __construct($main, $x, $y, $z, $level, $item){
    	$this->main = $main;
        $this->x = $x;
        $this->y = $y;
        $this->z = $z;
        $this->level = $level;
        $this->it = $item;
    }
    public function onRun($tick){
    	$l = $this->main->getServer()->getLevelByName($this->level);
    	if ($l === null) return false;
    	     	$pos = new Position((int) $this->x, (int) $this->y, (int) $this->z, $l);
     $pos->level->dropItem($pos->asVector3(), $this->it);
    }
}