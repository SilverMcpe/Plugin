<?php

namespace SilverMCPE\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\Position;
use pocketmine\math\Vector3;

class StoneTask extends Task{

    public function __construct($main, $b, $p){
    	$this->main = $main;
        $this->p = $p;
        $this->b = $b;
    }
    public function onRun($tick){
      //$this->p->getName() . ", " . $this->b->getX()
      if (isset($this->main->a[$this->p->getName() . ", " . $this->b->getX()])) {
        $a = $this->p->getName() . ", " . $this->b->getX();
      }elseif(isset($this->main->a[$this->p->getName() . ", " . $this->b->getZ()])){
        $a = $this->p->getName() . ", " . $this->b->getZ();
      }
      if (isset($a)) {
         $this->main->a[$a] = $this->main->a[$a] + 1;
      if ($this->main->a[$a] == 2) {
      $this->b->getLevel()->setBlock(new Vector3($this->b->getX(), $this->b->getY(), $this->b->getZ()), $this->b);
      $this->main->getScheduler()->cancelTask($this->main->sId[$a]);
      unset($this->main->sId[$a]);
      unset($this->main->a[$a]);
      }
     
      }

         
    }
}