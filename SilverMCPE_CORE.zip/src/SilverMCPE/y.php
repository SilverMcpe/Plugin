<?php

namespace SilverMCPE;

use mcpepazarim\EventTask;
use pocketmine\plugin\PluginBase;
use SilverMCPE\Commands\{
	Kasakur,
	Adafly,
	Arkadas,
	Ayarlar,
	Tpa,
	Tpak,
	Tpar,
	Msg,
	Rütbe,
	Spmarket,
	Spver,
	Sat,
	Fkur,
	Fbilgi,
	Fab,
	FabrikaAda,
	Buyu,
	End,
	Nether,
	Canta,
	Mobsp,
	Ada,
	Adalevel,
	Toplevel,
	PZiyaret,
	Event,
	Koruma,
	Top3,
	ykabul,
	Panel,
	ping,
	flyver
};

use SilverMCPE\Events\{
	Kasa,
    Spawner,
    Fabrika,
    Otoenvanter,
	FabrikaAdaE,
	AdaE
};

use pocketmine\event\{
	Listener,
	player\PlayerJoinEvent,
	block\BlockBreakEvent,
	player\PlayerInteractEvent,
	entity\EntityTeleportEvent,
	entity\EntityDamageEvent,
	player\PlayerToggleSneakEvent,
    block\BlockPlaceEvent,
	player\PlayerChatEvent,
	player\PlayerJumpEvent,
	block\BlockGrowEvent,
	player\PlayerPreLoginEvent,
};
use SilverMCPE\Tasks\{
     Seviye1Task,
     Seviye2Task,
     Seviye3Task,
     SpawnerTask,
	 isinlanTask,
	 AktiflikTask,
    MobTask,
	StoneTask,
	ScoreboardTask
};
use pocketmine\level\Position;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use raklib\protocol\EncapsulatedPacket;
use pocketmine\network\mcpe\protocol\BatchPacket;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\Player;
use pocketmine\block\BlockFactory;
use pocketmine\block\Block;
use korado531m7\InventoryMenuAPI\event\InventoryCloseEvent;
use korado531m7\InventoryMenuAPI\event\InventoryClickEvent;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\entity\{Entity, Human};


class Main extends PluginBase implements Listener{

	public $mobs = [
		"Koyun" => "Sheep",
		"Domuz" => "Pig",
		"İnek" => "Cow",
		"Tavuk" => "Chicken",
		"Creeper" => "Creeper",
		"Örümcek" => "Spider",
		"İskelet" => "Skeleton",
		"Blaze" => "Blaze",
		"Zombi" => "Zombie"
	];

	public function onLogin(PlayerPreLoginEvent $e){

		
	}

	public function onJoin(PlayerJoinEvent $e){
		$p = $e->getPlayer();

		$this->banl = new Config($this->getDataFolder() . "sbanlist.yml", Config::YAML);
		$bans = $this->banl->get($p->getName());
		if(isset($bans)){
			$now = time();
			$remainingTime = $bans - $now;
			$day = floor($remainingTime / 86400);
			$hourSeconds = $remainingTime % 86400;
			$hour = floor($hourSeconds / 3600);
			$minuteSec = $hourSeconds % 3600;
			$minute = floor($minuteSec / 60);
			if($minute <= 0 && $hour <= 0 && $day <= 0){
				
			}else{
			    $p->kick("Sunucudan banlandın\n" . $day . " Gün ". $hour . " Saat " . $minute . " Dakika");
			}
		}
		
		$this->banl = new Config($this->getDataFolder() . "banlist.yml", Config::YAML);
		$bans = $this->banl->get("Ban");
		if(is_array($bans)){
			if(in_array($p->getName(), $bans)){
			 $p->kick("Sunucudan banlandın");
			}
		}
		$this->banl = new Config($this->getDataFolder() . "ipbanlist.yml", Config::YAML);
		$bans = $this->banl->get("Ban");
		if(is_array($bans)){
			if(in_array($p->getAddress(), $bans)){
			 $p->kick("Sunucudan banlandın");
			}
		}


		$this->level = new Config($this->getDataFolder() ."toplevel.json", Config::JSON);
		$message = null;
			   $level_top = $this->level->getAll();
		
			if(count($level_top) > 0){
				arsort($level_top);
				$i = 1;
			   
				foreach($level_top as $name => $level){
          if($i == 1){
			  $i1 = $name;
		  }			
		  if($i == 3){
			$i3 = $name;
		}		
		if($i == 2){
			$i2 = $name;
		}			   
					if($i >= 3){
						break;
						}
						$i++;
					}
				}else{

			}
			$this->cfg = new Config($this->getDataFolder() . "Top3.yml", Config::YAML);

			$kor3 = explode(":", $this->cfg->get("1"));
            if($kor3 != null){
			if($i1 == $p->getName()){
				$level3 = $this->getServer()->getLevelByName($kor3[3]);
				$this->getServer()->loadLevel($kor3[3]);			
				$entity3 = $level3->getNearestEntity(new Vector3($kor3[0], $kor3[1], $kor3[2]), 10, Human::class);
				$entity3->setSkin($p->getSkin());
			}
			$kor3 = explode(":", $this->cfg->get("3"));
			if($i3 == $p->getName()){
				$level3 = $this->getServer()->getLevelByName($kor3[3]);
				$this->getServer()->loadLevel($kor3[3]);			
				$entity3 = $level3->getNearestEntity(new Vector3($kor3[0], $kor3[1], $kor3[2]), 10, Human::class);
				$entity3->setSkin($p->getSkin());
			}
			$kor3 = explode(":", $this->cfg->get("2"));
			if($i2 == $p->getName()){
				$level3 = $this->getServer()->getLevelByName($kor3[3]);
				$this->getServer()->loadLevel($kor3[3]);			
				$entity3 = $level3->getNearestEntity(new Vector3($kor3[0], $kor3[1], $kor3[2]), 10, Human::class);
				$entity3->setSkin($p->getSkin());
			}
		   } 
			

		$folder = $this->getDataFolder();
		$this->pcfg = new Config($this->getDataFolder() . $p->getName() . ".json", Config::JSON);
		$this->pcfg = new Config($this->getDataFolder() . $this->pcfg->get("AIsim") . ".json", Config::JSON);
		$pc = $this->getServer()->getPluginManager()->getPlugin("PureChat");
		if(!empty($this->pcfg->get("Level"))){
			$pc->setSuffix($this->pcfg->get("Level"), $p);

		}


		$this->pcfg = new Config($this->getDataFolder() . "Plugin Verileri/OffSp.yml", Config::YAML);
		if($this->pcfg->get($p->getName()) != null){
			$this->cfg = new Config($this->getDataFolder() . "Plugin Verileri/ÖSpawnerlar.yml", Config::YAML);
			$spawners = $this->cfg->get("Spawnerlar");
			foreach($spawners as $isim => $bilgi){
				$spawners2[] = $isim;
			}
			$deger =  array_search($this->pcfg->get($p->getName()), $spawners2);
			$isim = $spawners2[$deger];
			if ($isim == $this->pcfg->get($p->getName())) {

				if (isset($isim)) {
					$item = Item::get(52, 0, 1);
					$item->setLore([$isim . " 1"]);
					$item->setCustomName("§7» §e" . $isim . " §aSpawner §7«");
					$p->getInventory()->addItem($item);
					$p->sendMessage("§6Silver§fMcpe §7» §esize §a" . $isim . "§e spawner verdi.");
				}else{

				}
			}else{
				$item = Item::get(52, 0, 1);
				$item->setCustomName("§r§1" . $this->pcfg->get($p->getName()) . " Spawner");
				$item->setLore([$this->pcfg->get($p->getName())]);
				$p->getInventory()->addItem($item);
				$p->sendMessage($this->pcfg->get($p->getName()) . " Spawner verildi.");
			}
			$this->pcfg->remove($p->getName());
			$this->pcfg->save();
		}
		if(file_exists($folder . "Oyuncu Verileri/" . $p->getName() . ".yml")) {
			$this->ocfg = new Config($this->getDataFolder() ."Oyuncu Verileri/" . $p->getName() . ".yml", Config::YAML);
			/*if($this->cfg->get("Scoreboard")){
				$api = $this->getServer()->getPluginManager()->getPlugin("ScoreboardAPI");
				$scoreboard = $api->createScoreboard("objective", "SilverMCPE"); //create scoreboard
				$api->sendScoreboard($scoreboard, [$p]);
				$line = 1; // line number
				$score = 1; // current score
				$type = ScoreboardEntry::TYPE_FAKE_PLAYER; // other types are TYPE_PLAYER and TYPE_ENTITY
				$identifier = "line 1"; // this is a string for fake players but must be an entity id for other types
				/** @var Scoreboard $scoreboard */
			/*	$entry = $scoreboard->createEntry($line, $score, $type, $identifier);
				$scoreboard->addEntry($entry);
			}*/
      }else{
      	$this->ocfg = new Config($this->getDataFolder() ."Oyuncu Verileri/" . $p->getName() . ".yml", Config::YAML);
      	$this->ocfg->set("Msg", true);
      	$this->ocfg->set("Tpa", true);
      	$this->ocfg->set("Arkadas", true);
      	$this->ocfg->set("Otoenvanter", true);
			$this->ocfg->set("Scoreboard", true);
		  $this->ocfg->set("TasHız", 5);
		  $this->ocfg->set("Kayıt", $this->turkcetarih_formati('j F Y , l'));
      	$this->ocfg->set("1", array("Kırıktaş", " "));
      	$this->ocfg->save();

      }
	}
 
	

	function turkcetarih_formati($format, $datetime = 'now'){
		$z = date("$format", strtotime($datetime));
		$gun_dizi = array(
			'Monday'    => 'Pazartesi',
			'Tuesday'   => 'Salı',
			'Wednesday' => 'Çarşamba',
			'Thursday'  => 'Perşembe',
			'Friday'    => 'Cuma',
			'Saturday'  => 'Cumartesi',
			'Sunday'    => 'Pazar',
			'January'   => 'Ocak',
			'February'  => 'Şubat',
			'March'     => 'Mart',
			'April'     => 'Nisan',
			'May'       => 'Mayıs',
			'June'      => 'Haziran',
			'July'      => 'Temmuz',
			'August'    => 'Ağustos',
			'September' => 'Eylül',
			'October'   => 'Ekim',
			'November'  => 'Kasım',
			'December'  => 'Aralık',
			'Mon'       => 'Pts',
			'Tue'       => 'Sal',
			'Wed'       => 'Çar',
			'Thu'       => 'Per',
			'Fri'       => 'Cum',
			'Sat'       => 'Cts',
			'Sun'       => 'Paz',
			'Jan'       => 'Oca',
			'Feb'       => 'Şub',
			'Mar'       => 'Mar',
			'Apr'       => 'Nis',
			'Jun'       => 'Haz',
			'Jul'       => 'Tem',
			'Aug'       => 'Ağu',
			'Sep'       => 'Eyl',
			'Oct'       => 'Eki',
			'Nov'       => 'Kas',
			'Dec'       => 'Ara',
		);
		foreach($gun_dizi as $en => $tr){
			$z = str_replace($en, $tr, $z);
		}
		if(strpos($z, 'Mayıs') !== false && strpos($format, 'F') === false) $z = str_replace('Mayıs', 'May', $z);
		return $z;
	}

    private function cfgOlustur(){
        $cfg = new Config($this->getDataFolder() . "Ayarlar.json", Config::JSON);
        $cfg->set("Koyun", 1000000);
        $cfg->set("Domuz", 1000000);
        $cfg->set("İnek", 1300000);
        $cfg->set("Tavuk", 1200000);
        $cfg->set("Örümcek", 1500000);
        $cfg->set("İskelet", 1600000);
        $cfg->set("Blaze", 1800000);
        $cfg->set("Zombi", 1700000);
		$cfg->set("Creeper", 1650000);
        $cfg->save();
    }

	public function onEnable(){
		$this->cfg = new Config($this->getDataFolder() . "Top3.yml", Config::YAML);
		$kor3 = explode(":", $this->cfg->get("3"));
		$this->level = new Config($this->getDataFolder() ."toplevel.json", Config::JSON);
		$message = null;
			   $level_top = $this->level->getAll();
		
			if(count($level_top) > 0){
				arsort($level_top);
				$i = 1;
			   
				foreach($level_top as $name => $level){
          if($i == 1){
			  $i1 = $name;
			  $l1= $level;
		  }			
		  if($i == 3){
			$i3 = $name;
			$l3= $level;
		}		
		if($i == 2){
			$i2 = $name;
			$l2= $level;
		}			   
					if($i >= 3){
						break;
						}
						$i++;
					}
				}else{

			}
		if(!empty($this->cfg->get("3"))){
			$level3 = $this->getServer()->getLevelByName($kor3[3]);
			$this->getServer()->loadLevel($kor3[3]);			
			$entity3 = $level3->getNearestEntity(new Vector3($kor3[0], $kor3[1], $kor3[2]), 5, Human::class);
			$entity3->setNameTag("3." . $i3 . ": " . $l3);
			$this->id3 = $entity3->getId();
			$entity3->setScale(0.8);
			
		}
		$kor3 = explode(":", $this->cfg->get("2"));
		if($this->cfg->get("2") != null){
			$level3 = $this->getServer()->getLevelByName($kor3[3]);
			$this->getServer()->loadLevel($kor3[3]);
			$entity3 = $level3->getNearestEntity(new Vector3($kor3[0], $kor3[1], $kor3[2]), 5, Human::class);
			$entity3->setNameTag("2." . $i2 . ": " . $l2);
			$this->id2 = $entity3->getId();
			$entity3->setScale(1);

		}
		$kor3 = explode(":", $this->cfg->get("1"));
		if($this->cfg->get("1") != null){
			$level3 = $this->getServer()->getLevelByName($kor3[3]);
			$this->getServer()->loadLevel($kor3[3]);
			$entity3 = $level3->getNearestEntity(new Vector3($kor3[0], $kor3[1], $kor3[2]), 5, Human::class);
			$entity3->setNameTag("1." . $i1 . ": " . $l1);
			$this->id1 = $entity3->getId();
			$entity3->setScale(1.2);

		}

		$this->db = new \mysqli("138.201.82.84", "silvermc_root", "8%hy69Eb", "silvermc_leaderosmcpe", 3306);
		$sql = "SELECT isim, level FROM adalevel";
		$result = $this->db->query($sql);
		$this->level = new Config($this->getDataFolder() . "toplevel.json", Config::JSON);
		$message = null;
		$level_top = $this->level->getAll();
		if ($result->num_rows > 0) {

			// her bir satırı döker
			$oyuncular[] = "";
			while ($row = $result->fetch_assoc()) {
				$oyuncular[] = $row["isim"];
			}


			if (count($level_top) > 0) {

				foreach ($level_top as $name => $level) {
					if (in_array($name, $oyuncular)) {
						$sql = "UPDATE adalevel SET level='$level' WHERE isim='$name'";
					} else {
						$sql = "INSERT INTO adalevel (isim, level) VALUES ('$name', '$level')";
					}
					$this->db->query($sql);
				}
			} else {

			}
		}else{
			if (count($level_top) > 0) {

				foreach ($level_top as $name => $level) {

						$sql = "INSERT INTO adalevel (isim, level) VALUES ('$name', '$level')";
					$this->db->query($sql);
					}

				}else{
				echo "veri yok";
			}
			}


		//$this->getScheduler()->scheduleRepeatingTask(new ScoreboardTask($this), 20 * 3);
		$this->getServer()->getPluginManager()->registerEvents($this, $this);

		if(file_exists($this->getDataFolder()."config.yml")){
			$this->data = new Config($this->getDataFolder()."config.yml", Config::YAML);
		} else {
			$this->data = new Config($this->getDataFolder()."config.yml", Config::YAML);
			$this->data->set("items", ["1", "17", "265"]);
			$this->data->set("sure", 30);
			$this->data->save();
		}

        if(!file_exists($this->getDataFolder() . "Ayarlar.json")) $this->cfgOlustur();
        $this->ocfg = new Config($this->getDataFolder() . "OSpawnerlar.yml", Config::YAML);
        foreach ($this->ocfg->getAll() as $sp => $bilgi) {
            $kordi = explode(",", $sp);

			$tür = $bilgi["Tür"];
			if(isset($this->mobs[$tür])){
				$this->getScheduler()->scheduleRepeatingTask($task = new MobTask($this, $kordi[0], $kordi[1], $kordi[2], $kordi[3], $this->mobs[$tür]), 20 * 90);
				$this->Id[implode(" ", $kordi)] = $task->getTaskID();
			}
        }
	
				$folder = $this->getDataFolder();
				@mkdir($folder . "Oyuncu Verileri");
		@mkdir($folder . "Plugin Verileri");
		@mkdir($folder . "Fabrika Adalar");


     if (!file_exists($folder . "Plugin Verileri/Spawnerlar.yml")) {
     	
          $this->cfg = new Config($folder . "Plugin Verileri/Spawnerlar.yml", Config::YAML);
     	$this->cfg->setNested("Spawnerlar.Elmas.Fiyat.SatınAl", 10);
     	$this->cfg->setNested("Spawnerlar.Elmas.Fiyat.1", 10);
     	$this->cfg->setNested("Spawnerlar.Elmas.Fiyat.2", 10);
     	$this->cfg->setNested("Spawnerlar.Elmas.Fiyat.3", 10);
     	$this->cfg->setNested("Spawnerlar.Elmas.Süre.1", 100);
     	$this->cfg->setNested("Spawnerlar.Elmas.Süre.2", 80);
     	$this->cfg->setNested("Spawnerlar.Elmas.Süre.3", 60);
     	 $this->cfg->setNested("Spawnerlar.Elmas.Id", "264, 0, 1");
     	 $this->cfg->save();

     	     }
     	          $this->ocfg = new Config($folder . "Plugin Verileri/OSpawnerlar.yml", Config::YAML);
     $this->cfg = new Config($folder . "Plugin Verileri/Spawnerlar.yml", Config::YAML);
     foreach ($this->ocfg->getAll() as $sp => $bilgi) {
     	$kordi = explode(",", $sp);

        $tür = $bilgi["Tür"];
        $süre = $this->cfg->getNested("Spawnerlar." . $tür . ".Süre.". $bilgi["Level"]);
		$id = $this->cfg->getNested("Spawnerlar." . $tür . ".Id");
		if(empty($id)){
			$this->cfg = new Config($this->getDataFolder() . "Plugin Verileri/ÖSpawnerlar.yml", Config::YAML);
			$süre = $this->cfg->getNested("Spawnerlar." . $tür . ".Süre.". $bilgi["Level"]);
			$id = $this->cfg->getNested("Spawnerlar." . $tür . ".Id");
		  }

        $item = Item::get((int) $id);
        $this->getScheduler()->scheduleRepeatingTask($task = new SpawnerTask($this, $kordi[0], $kordi[1], $kordi[2], $kordi[3], $item), 20 * $süre);
        $this->Id[implode(" ", $kordi)] = $task->getTaskID();
     }

	$msgcmd = $this->getServer()->getCommandMap()->getCommand("msg");
	if($msgcmd != null){
		$this->getServer()->getCommandMap()->unregister($msgcmd);
	}

	$this->registerCommands();
	$this->registerEvents();
		  if (file_exists($this->getDataFolder() . "Plugin Verileri/Kasalar.yml")) {
	  	$this->cfg = new Config($this->getDataFolder() . "Plugin Verileri/Kasalar.yml", Config::YAML);
	  }else{
	  	$this->configOlustur();
	  }
	}

	  
   /**
   * @priority MONITOR
   */
 

	public function onIntreact(PlayerInteractEvent $e){
		if($e->isCancelled()) return false;
		if($e->getBlock() instanceof \pocketmine\block\EnchantingTable){
			$e->setCancelled();
			if($e->getPlayer()->getInventory()->getItemInHand()->getName() == "Air"){
				$e->getPlayer()->getLevel()->setBlock($e->getBlock(), BlockFactory::get(Block::AIR));
				$e->getPlayer()->getInventory()->addItem(Item::get(116, 0, 1));
				return true;
			}
			
			
			$this->getServer()->dispatchCommand($e->getPlayer(), "buyu");
		}
	}

	public function onChat(PlayerChatEvent $e){
		$p = $e->getPlayer();
		$message = $e->getMessage();
		$this->banl = new Config($this->getDataFolder() . "mutelist.yml", Config::YAML);
		$bans = $this->banl->get("Mute");
		if(is_array($bans)){
			if(in_array($p->getName(), $bans)){
			 $p->sendMessage("Sonsuza dek konuşamazsın");
			  $e->setCancelled();
			}
		}
		$this->banl = new Config($this->getDataFolder() . "smutelist.yml", Config::YAML);
		$bans = $this->banl->get($p->getName());
		if(isset($bans)){
			$now = time();
			$remainingTime = $bans - $now;
			$day = floor($remainingTime / 86400);
			$hourSeconds = $remainingTime % 86400;
			$hour = floor($hourSeconds / 3600);
			$minuteSec = $hourSeconds % 3600;
			$minute = floor($minuteSec / 60);
			if($minute <= 0){
				
			}else{
				$p->sendMessage($minute ." dakika konuşamazsın");
				$e->setCancelled();
			}
		}

		$m = strtolower($message);
		if(isset($this->cevap) && $this->cevap == $m){
			$this->getServer()->broadcastMessage("§aSoru Eventi §8» §e" . $p->getName() . " §bdoğru cevabı buldu.\n§aCevap §8» §b" . $this->cevap);
			unset($this->cevap);
		}


	}

	public function eventBaslat(){
		$this->getServer()->broadcastMessage("§6Event başlıyor!");
		$saniye = $this->data->get("sure");
		$data = $this->data->get("pos1");
		$args = explode(":", $data);
		$pos1 = new Position($args[0], $args[1], $args[2], $this->getServer()->getLevelByName($args[3]));
		$data = $this->data->get("pos2");
		$args = explode(":", $data);
		$pos2 = new Position($args[0], $args[1], $args[2], $this->getServer()->getLevelByName($args[3]));
		$this->getScheduler()->scheduleRepeatingTask(new EvTask($this, $saniye, $pos1, $pos2), 20);
	}

	public function eventBitir(){
		$this->getServer()->broadcastMessage("§6Event bitti!");
	}

    public function onInteract(PlayerInteractEvent $e){
		$cfg = new Config($this->getDataFolder() . "mapler.yml", Config::YAML);
		if(!empty($cfg->get($e->getPlayer()->getLevel()->getFolderName() . "-touch")) && !$cfg->get($e->getPlayer()->getLevel()->getFolderName() . "-touch")){
			$e->setCancelled();

		}else{

		}
	}
	public function onPlace(BlockPlaceEvent $e){
        if($e->isCancelled()) return false;
		$cfg = new Config($this->getDataFolder() . "mapler.yml", Config::YAML);
		if(empty($cfg->get($e->getPlayer()->getLevel()->getFolderName() . "-touch"))){
		}else{
			if($cfg->get($e->getPlayer()->getLevel()->getFolderName() . "-touch") == "aktif"){

			}else{
				$e->setCancelled();
			}
		}
        $it = $e->getItem();
        $o = $e->getPlayer();
        $blok = $e->getBlock();
        if ($it->getId() == 52) {

            if ($it->getLore() === null) {


            }else{
                if(isset($this->mobsp[$e->getPlayer()->getName()]) && $this->mobsp[$e->getPlayer()->getName()] == true) return true;
				$this->mobsp[$e->getPlayer()->getName()] = true;
				$this->getScheduler()->scheduleDelayedTask(new class($this, $e->getPlayer()) extends Task{

					public function __construct($c, $p){

						$this->c = $c;

						$this->p = $p;
					}

					public function onRun(int $currentTick){

						unset($this->c->mobsp[$this->p->getName()]);

					}

				}, 10);


                $spd = implode(" ", $it->getLore());
                if(!isset($this->mobs[$spd])) return true;
                $this->ocfg = new Config($this->getDataFolder() . "OSpawnerlar.yml", Config::JSON);
                $pos = $blok->getX() . "," . $blok->getY() . "," . $blok->getZ() . "," . $blok->getLevel()->getFolderName();
                $this->ocfg->setNested($pos . ".Sahibi", $o->getName());
                $this->ocfg->setNested($pos . ".Tür", $spd);
                $this->ocfg->save();
                $o->sendMessage("§6Silver§fMcpe §7» §aSpawner yerleştirildi");
                $kordi = explode(",", $pos);
                $this->getScheduler()->scheduleRepeatingTask($task = new MobTask($this, $kordi[0], $kordi[1], $kordi[2], $kordi[3], $this->mobs[$spd]), 20 * 90);

                $this->Id[implode(" ", $kordi)] = $task->getTaskID();
            }

        }
    }

	public function onBreak(BlockBreakEvent $e){
		$cfg = new Config($this->getDataFolder() . "mapler.yml", Config::YAML);
		if(empty($cfg->get($e->getPlayer()->getLevel()->getFolderName() . "-touch"))){
		}else{
			if($cfg->get($e->getPlayer()->getLevel()->getFolderName() . "-touch") == "aktif"){

			}else{
				$e->setCancelled();
			}
		}

        $o = $e->getPlayer();
        $blok = $e->getBlock();
        $item = $e->getItem();

        if ($e->getBlock()->getId() == 52) {
            $folder = $this->getDataFolder();
            $this->ocfg = new Config($folder . "OSpawnerlar.yml", Config::YAML);
            $pos = $blok->getX() . "," . $blok->getY() . "," . $blok->getZ() . "," . $blok->getLevel()->getFolderName();
            $sahibi = $this->ocfg->getNested($pos . ".Sahibi");
            if ($sahibi === null) {

            } elseif ($sahibi == $o->getName()) {
				if($o->getInventory()->getItemInHand()->getLore() == ["Spawner Kazması"]){
					$it = Item::get(52, 0, 1);
					$isim = $this->ocfg->getNested($pos . ".Tür");
					$this->ocfg->remove($pos);
					$this->ocfg->save();
					$it->setLore([$isim]);
					$it->setCustomName("§7» §e" . $isim . " §aSpawner §7«");
					$e->setDrops([$it]);
					$pos2 = explode(",", $pos);
					$this->getScheduler()->cancelTask($this->Id[implode(" ", $pos2)]);
					unset($this->Id[implode(" ", $pos2)]);

				}else{
					$e->setCancelled();
					$o->sendMessage("§6Silver§fMcpe §7»§c Spawner Kazması kullanmalısın");
				}


            } else {
                $o->sendMessage("§6Silver§fMcpe §7» §cBu spawner sana ait değil.");
                $e->setCancelled();
            }


        }

		$p = $e->getPlayer();
		$b = $e->getBlock();
		$x = $b->getX();
		$y = $b->getY();
		$z = $b->getZ();
		if ($b->getId() == 4 || $b->getId() == 1) {
		if ($b->getLevel()->getBlock(new Vector3($x + 1, $y, $z))->getName() == "Water" && $b->getLevel()->getBlock(new Vector3($x - 1, $y, $z))->getName() == "Lava" || $b->getLevel()->getBlock(new Vector3($x + 1, $y, $z))->getName() == "Lava" && $b->getLevel()->getBlock(new Vector3($x - 1, $y, $z))->getName() == "Water" || $b->getLevel()->getBlock(new Vector3($x, $y, $z + 1))->getName() == "Water" && $b->getLevel()->getBlock(new Vector3($x, $y, $z - 1))->getName() == "Lava" || $b->getLevel()->getBlock(new Vector3($x, $y, $z + 1))->getName() == "Lava" && $b->getLevel()->getBlock(new Vector3($x, $y, $z - 1))->getName() == "Water") $this->tasHiz($b, $p, $b->getId()); $this->itemOran($p, $e);

		}

			
	}

	/**
     * @priority MONITOR
    */
	public function itemOran($p, $e){
		if($e->isCancelled()) return false;
		$rand = rand(1, 650);
		$yetki = $this->yetkiSorgula($p);
		if ($rand <= $yetki) {
			$cfg = new Config($this->getDataFolder() . "orani.yml", Config::YAML);
			$it = $cfg->get("Itemler");
			$data = array_rand($it);
			$item = $it[$data];
			$ite = explode(",", $item);
			if($ite[0] == 464){
         if($e->getPlayer()->hasPermission("Anahtar")){

		 }else{
			 return true;
		 }
			}else{
			}
			$item = Item::get($ite[0], $ite[1], $ite[2]);
			$datas = 3;
			$this->enchAdd($datas, $ite, $item);
			$e->setDrops([$item]);
		}
	}

	public function enchAdd($data, $itd, $item){

		if (isset($itd[$data]) && isset($itd[$data + 1])) {
	   
		  $enc = Enchantment::getEnchantment($itd[$data]);
		  $enc1 = new EnchantmentInstance($enc, $itd[$data + 1]);
		  $item->addEnchantment($enc1);
		  $ydata = $data + 2;
		  $this->enchAdd($ydata, $itd, $item);
		  
		}else{
  
		  if(isset($itd[$data])){
	  
			$item->setCustomName($itd[$data]);
		  }else{
  
  
		   
		  }
   
		  }
  
			
		  }

	public function yetkiSorgula($p){
       if ($p->hasPermission("mvip")) {
       	return 25;
       }elseif ($p->hasPermission("vip+")) {
       	return 20;
       }elseif ($p->hasPermission("vip")) {
       	return 15;
       }else{
       	return 10;
       }
	}

	public function onGrow(BlockGrowEvent $e){
		if($e->getBlock()->getId() === Block::FARMLAND) {
			$e->setCancelled();
		}



	}
	public function üzatForm($p, $yer){
		$this->yer = $yer;
   $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");

				$form = $api->createModalForm(function (Player $p, $data) {
					$result = $data;
					if ($result === null) {
						return true;
					}
					switch ($result) {
						case 0:
						$dnya = $this->getServer()->getLevelByName("lobi");
						$spawn = $dnya->getSafeSpawn();
						$p->teleport($spawn, 0, 0);
						$p->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));
						if ($this->yer == "tend") {
$this->getScheduler()->cancelTask($this->endId[$p->getName()]);
						}else{
							$this->getScheduler()->cancelTask($this->netherId[$p->getName()]);

						}
						break;
						case 1:
						$this->süreUzat($p, $this->yer);
					}


				});

				
				$form->setTitle("§6Silver§bMcpe §r-". $yer . "Süre Uzat");
				$form->setContent($yer. "Süre uzatmak istiyor musun?");
				$form->setButton1("Uzat");
				$form->setButton2("Iptal");
				$form->sendToPlayer($p);
	}

	public function onTeleport(EntityTeleportEvent $e){
		$en = $e->getEntity();
		if($e->getTo()->getLevel() == null){
			return false;
		}
		
		if($en instanceof Player){
			$to = $e->getTo();
			$this->cfg = new Config($this->getDataFolder() . $to->getLevel()->getFolderName() . ".json", Config::JSON);
				$eng = $this->cfg->get("Engel");
				if($eng != null){
					if(in_array($en->getName(), $eng)){
						$e->setCancelled();
						$en->sendMessage("Bu adaya ışınlanamazsın.");
					}
				}
            if($en->hasPermission("fly")) return true;
			if(isset($this->FlyId[$en->getName()])){
				$this->getScheduler()->cancelTask($this->FlyId[$en->getName()]);
				unset($this->FlySure[$en->getName()]);
			} 
			if (isset($this->endId[$en->getName()])){
				$this->getScheduler()->cancelTask($this->endId[$en->getName()]);
				}elseif(isset($this->netherId[$en->getName()])){
				$this->getScheduler()->cancelTask($this->netherId[$en->getName()]);
				
			}else{
				
			}

                                      
			$en->setFlying(false);
            $en->setAllowFlight(false);
		}
	}

	public function tasHiz($b, $p){
		$cfg = new Config($this->getDataFolder() . "Oyuncu Verileri/" . $p->getName() .".yml", Config::YAML);
		$süre = $cfg->get("TasHız");
		if($b->getDamage() != 0){
			return true;
		}
		$this->a[$p->getName() . ", " . $b->getX()] = 0;
		$this->a[$p->getName() . ", " . $b->getZ()] = 0;
		$this->getScheduler()->scheduleDelayedTask(new class($this, $b, $p) extends Task{

			public function __construct($main, $b, $p){
				$this->main = $main;
				$this->p = $p;
				$this->b = $b;

			}

			public function onRun(int $currentTick){

				//$this->p->getName() . ", " . $this->b->getX()
				if (isset($this->main->a[$this->p->getName() . ", " . $this->b->getX()])) {
					$a = $this->p->getName() . ", " . $this->b->getX();
				}elseif(isset($this->main->a[$this->p->getName() . ", " . $this->b->getZ()])){
					$a = $this->p->getName() . ", " . $this->b->getZ();
				}
				if (isset($a)) {
					$this->main->a[$a] = $this->main->a[$a] + 1;
					if ($this->main->a[$a] == 2) {
						$this->b->getLevel()->setBlock(new Vector3($this->b->getX(), $this->b->getY(), $this->b->getZ()), $this->b);
						unset($this->main->a[$a]);
						$this->p->sendPopup("Taş yerleştirildi.");
					}

				}

			}

		}, 20 * $süre);
	}

	public function pvp(EntityDamageEvent $e){
		if($e->getEntity() instanceof Player){
			$lada = $e->getEntity()->getLevel()->getFolderName();
			if($lada == "[fab]". $e->getEntity()->getName() && !in_array($e->getCause(), [$e::CAUSE_FALL, $e::CAUSE_FIRE, $e::CAUSE_ENTITY_EXPLOSION, $e::CAUSE_VOID])){
				$e->setCancelled(true);
			}
		}
	}

	public function süreUzat($p, $yer){
			$eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
		if ($eco->myMoney($p->getName()) >= 100) {
			$süre = 15;
	if ($yer == "tend") {
		$this->getScheduler()->cancelTask($this->endId[$p->getName()]);

		$this->getScheduler()->scheduleRepeatingTask($task = new isinlanTask($this, $p, $yer), 20);

		        $this->endId[$p->getName()] = $task->getTaskID();
        $this->endSüre[$p->getName()] = $süre;
	}else{
		$this->getScheduler()->cancelTask($this->netherId[$p->getName()]);

		$this->getScheduler()->scheduleRepeatingTask($task = new isinlanTask($this, $p, $yer), 20);

				        $this->netherId[$p->getName()] = $task->getTaskID();
        $this->netherSüre[$p->getName()] = $süre;
	}

        $p->sendMessage("Süre uzatıldı");
		}
	}

  
  	public function configOlustur(){
         $this->cfg = new Config($this->getDataFolder() . "Plugin Verileri/Kasalar.yml", Config::YAML);
         $items = array("1, 0, 1", "2, 0, 2", "3, 0, 3");
         $this->cfg->setNested("Gold.Itemler", $items); 
         $this->cfg->setNested("Gold.Anahtar", "378, 0, 1");
         $this->cfg->save();
	}

	public function tpaIstekSorgula($p){
       if (isset($this->istek[$p->getName()])) {
       	return $this->istek[$p->getName()];
       }else{
       	return "false";
       }
	}

	private function registerCommands(){
		$map = $this->getServer()->getCommandMap();
        $map->register("adafly", new Adafly($this)); //adafly
		$map->register("msg", new Msg($this)); //msg
		$map->register("tpa", new Tpa($this)); //tpa
        $map->register("tpak", new Tpak($this)); //tpak
        $map->register("tpar", new Tpar($this)); //tpar
        $map->register("arkadas", new Arkadas($this)); //arkadas
        $map->register("ayarlar", new Ayarlar($this)); //ayarlar
        $map->register("kasakur", new Kasakur($this));
        $map->register("rütbe", new Rütbe($this)); //rütbe
        $map->register("spmarket", new Spmarket($this)); //spmarket
		$map->register("spver", new Spver($this)); //spver
		$map->register("sat", new Sat($this)); //sat
		$map->register("fab", new FabrikaAda($this)); //fab
		$map->register("buyu", new Buyu($this)); 
		$map->register("end", new End($this));
		$map->register("canta", new Canta($this));
		$map->register("nether", new Nether($this)); 
		$map->register("ada", new Ada($this)); 
		$map->register("adalevelim", new Adalevel($this));
		$map->register("toplevel", new Toplevel($this));  
		$map->register("pziyaret", new PZiyaret($this));
		$map->register("mobsp", new Mobsp($this));
		$map->register("event", new Event($this));

		$map->register("koruma", new Koruma($this));
		$map->register("top3", new Top3($this));
		$map->register("ykabul", new ykabul($this));
		$map->register("panel", new Panel($this));
		$map->register("ping", new ping($this));
		$map->register("flyver", new flyver($this));









	}
    public function fiyat($mob){
        $cfg = new Config($this->getDataFolder() . "MobSpAyar.json", Config::JSON);
        $fiyat = $cfg->get($mob);
        return $fiyat;
    }

    public function spawner($d){
        $item = Item::get(52, 0, 1);
        switch($d){
            case "§r§fKoyun Spawner":
                $item->setCustomName("§r§fKoyun Spawner");
                $item->setLore(["Koyun"]);
                $isim = "Koyun";
                break;
            case "§r§eDomuz Spawner":
                $item->setCustomName("§r§eDomuz Spawner");
                $item->setLore(["Domuz"]);
                $isim = "Domuz";
                break;
            case "§r§3İnek Spawner":
                $item->setCustomName("§r§3İnek Spawner");
                $item->setLore(["İnek"]);
                $isim = "İnek";
                break;
            case "§r§aTavuk Spawner":
                $item->setCustomName("§r§aTavuk Spawner");
                $item->setLore(["Tavuk"]);
                $isim = "Tavuk";
                break;
            case "§r§cIron Golem Spawner":
                $item->setCustomName("§r§cIron Golem Spawner");
                $item->setLore(["Iron Golem"]);
                $isim = "Iron Golem";
                break;
            case "§r§1Örümcek Spawner":
                $item->setCustomName("§r§1Örümcek Spawner");
                $item->setLore(["Örümcek"]);
                $isim = "Örümcek";
                break;
            case "§r§2İskelet Spawner":
                $item->setCustomName("§r§2İskelet Spawner");
                $item->setLore(["İskelet"]);
                $isim = "İskelet";
                break;
            case "§r§3Zombi Spawner":
                $item->setCustomName("§r§3Zombi Spawner");
                $item->setLore(["Zombi"]);
                $isim = "Zombi";
                break;
            case "§r§4Blaze Spawner":
                $item->setCustomName("§r§4Blaze Spawner");
                $item->setLore(["Blaze"]);
                $isim = "Blaze";
                break;
			case "§r§5Creeper Spawner":
				$item->setCustomName("§r§5Creeper Spawner");
				$item->setLore(["Creeper"]);
				$isim = "Creeper";
				break;

        }
        $a = [$item, $isim];
        return $a;
    }

    public function onClick(InventoryClickEvent $e){
		$inv = $e->getInventory();
		if($inv->getName() == "Spawner Market"){
			$eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
			$d = $e->getItem()->getName();
			$sp = $this->spawner($d);
			if(isset($this->mobsp[$e->getPlayer()->getName()]) && $this->mobsp[$e->getPlayer()->getName()]) return true;
			if($eco->myMoney($e->getPlayer(), $this->fiyat($sp[1]))){
				$eco->reduceMoney($e->getPlayer(), $this->fiyat($sp[1]));
				$e->getPlayer()->getInventory()->addItem($sp[0]);
				$e->getPlayer()->sendMessage($sp[1] . " Spawner ". $this->fiyat($sp[1]) . " TL satın alındı.");

				$this->mobsp[$e->getPlayer()->getName()] = true;
							}else{
				$e->getPlayer()->sendMessage("Paran yetersiz.");
			}
				$this->getScheduler()->scheduleDelayedTask(new class($this, $e->getPlayer()) extends Task{


					public function __construct($c, $p){

						$this->c = $c;

						$this->p = $p;
					}

					public function onRun(int $currentTick){

						unset($this->c->mobsp[$this->p->getName()]);

					}

				}, 10);

		}
	}
	public function onClose(InventoryCloseEvent $e){


        $g = $e->getPlayer();
		$inv = $e->getInventory();
		$cfg = new Config($this->getDataFolder(). "Oyuncu Verileri/".  $g->getName() . ".yml", Config::YAML);
		if ($inv->getName() == "Çanta 1"){
			
			
			$cfg->set("canta-1E", serialize($inv->getContents()));
			$cfg->save();
		}elseif ($inv->getName() == "Çanta 2"){
			
		
			$cfg->set("canta-2E", serialize($inv->getContents()));
			$cfg->save();
		}elseif ($inv->getName() == "Çanta 3"){
			

			$cfg->set("canta-3E", serialize($inv->getContents()));
			$cfg->save();
		}elseif ($inv->getName() == "Çanta 4"){
			
			
			$cfg->set("canta-4E", serialize($inv->getContents()));
			$cfg->save();
		}
	}

	private function registerEvents(){
      $event = $this->getServer()->getPluginManager();
      $event->registerEvents($this, $this);
       $event->registerEvents(new Kasa($this), $this);
      $event->registerEvents(new Otoenvanter($this), $this);
     $event->registerEvents(new Spawner($this), $this);
	  $event->registerEvents(new FabrikaAdaE($this), $this);
	  $event->registerEvents(new AdaE($this), $this);

	}
}

class EvTask extends Task {
	public $plugin;
	public $saniye;
	public $pos1;
	public $pos2;

	public function __construct($plugin, $saniye, $pos1, $pos2){
		$this->plugin = $plugin;
		$this->saniye = $saniye;
		$this->pos1 = $pos1;
		$this->pos2 = $pos2;
	}
	public function onRun(int $tick){
		$this->saniye--;
		if($this->saniye > 0){
			$pos = $this->getRandomPos();
			$item = $this->getRandomItem();
			$pos->getLevel()->dropItem($pos, $item);
		}
		if($this->saniye == 0){
			$this->plugin->eventBitir();
		}
	}
	public function getRandomPos(){
		$x = rand($this->pos1->getX(), $this->pos2->getX());
		$y = rand($this->pos1->getY(), $this->pos2->getY());
		$z = rand($this->pos1->getZ(), $this->pos2->getZ());
		$level = $this->pos1->getLevel();
		return new Position($x, $y, $z, $level);
	}
	public function getRandomItem(){
		$items = $this->plugin->data->get("items");
		$key = array_rand($items);
		$id = $items[$key];
		return Item::get($id);
	}
}