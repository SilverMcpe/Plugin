<?php

namespace SilverMCPE\Events;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\block\Chest;

class FabrikaAdaE implements Listener
{

    public function __construct($plugin)
    {

        $this->main = $plugin;

    }

    public function onBreak(BlockBreakEvent $e)
    {
        if ($e->getPlayer()->isOp()) {
            return;
        }
        $le = $e->getPlayer()->getLevel()->getFolderName();
        if (strpos(strtolower($le), "[fab]") !== false) {
            $e->setCancelled();
        }
    }

    public function onPlace(BlockPlaceEvent $e)
    {
        if ($e->getPlayer()->isOp()) {
            return;
        }
        $le = $e->getPlayer()->getLevel()->getFolderName();
        if (strpos(strtolower($le), "[fab]") !== false) {
            $e->setCancelled();
        }
    }

    public function onInteract(PlayerInteractEvent $e)
    {
        if ($e->getPlayer()->isOp()) {
            return;
        }
        $le = $e->getPlayer()->getLevel()->getFolderName();
        if (strpos(strtolower($le), "[fab]") !== false) {
            if (strpos(strtolower($le), strtolower($e->getPlayer()->getName())) !== false) {
                if ($e->getBlock()->getId() == 54) {

                } else {
                    $e->setCancelled();
                }
            } else {
                $e->setCancelled();
            }


        }
    }

}



