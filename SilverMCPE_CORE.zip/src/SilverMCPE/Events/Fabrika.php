<?php

namespace SilverMCPE\Events;

use pocketmine\block\Stair;
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJumpEvent;
use pocketmine\event\player\PlayerToggleSneakEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\RemoveActorPacket;
use pocketmine\network\mcpe\protocol\SetActorLinkPacket;
use pocketmine\network\mcpe\protocol\types\EntityLink;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\level\Level;
use onebone\economyapi\EconomyAPI;
use pocketmine\Player;

class Fabrika implements Listener
{

    public function __construct($plugin)
    {

        $this->main = $plugin;

    }



    public function onTouch(PlayerInteractEvent $e)
    {




        if (isset($this->main->tur[$g->getName()])) {
            $tile = $e->getPlayer()->getLevel()->getTile($e->getBlock());
            if ($tile instanceof \pocketmine\tile\Sign) {
                $lines = $tile->getText();
                if ($this->main->tur[$g->getName()] == "Kırıktaş") {
                    $tile->setText("§7= §6Fabrika §7=", $this->main->tur[$g->getName()], "§bSeviye: §a1");
                } else {
                    $tile->setText("§7= §6Fabrika §7=", $this->main->tur[$g->getName()], "§2Kırık");
                }


                $e->getPlayer()->sendMessage("§6Silver§fMcpe §7»§aFabrika Ayarlandı!");
                $cfg = new Config($this->main->getDataFolder() . "Plugin Verileri/Fabrika.yml", Config::YAML);
                $kor = $e->getBlock()->getX() . "," . $e->getBlock()->getY() . "," . $e->getBlock()->getZ();
                $cfg->set($this->main->tur[$g->getName()], $kor);
                $cfg->save();
                unset($this->main->tur[$g->getName()]);
            }
        } else {
            $tile = $g->getLevel()->getTile($e->getBlock());
            if ("[fab]" . $g->getName() == $g->getLevel()->getFolderName()) {

                if ($tile instanceof \pocketmine\tile\Sign) {
                    $oc = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $g->getName() . ".yml", Config::YAML);
                    $fab = $tile->getLine(1);
                    $this->yuk[$g->getName()] = $fab;
                    $s1 = $oc->get("1");
                    $s2 = $oc->get("2");
                    $s3 = $oc->get("3");
                    if (is_array($s1)) {
                        foreach ($s1 as $se1) {
                            if ($fab == $se1) {
                                $data = 2;
                            }
                        }
                    } elseif ($fab == $s1) {
                        $data = 2;


                    } elseif (is_array($s2)) {
                        foreach ($s2 as $se2) {
                            if ($fab == $se2) {
                                $data = 3;
                            }
                        }
                    } elseif ($fab == $s2) {
                        $data = 3;
                    } elseif (is_array($s3)) {
                        foreach ($s3 as $se2) {
                            if ($fab == $se3) {

                            }
                        }
                    } else {
                        if ($fab == $s3) {
                            $data = "false";
                        } else {
                            $data = 1;
                        }
                    }
                    if (isset($data)) {

                    } else {
                        $data = 1;
                    }
                    if ($fab == "Vip") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat

                            $fiyat = 31;
                        } elseif
                        ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 32;
                        } elseif
                        ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 33;
                        }
                    }
                    if ($fab == "Kömür") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat

                            $fiyat = 31;
                        } elseif
                        ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 32;
                        } elseif
                        ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 33;
                        }
                    }
                    if ($fab == "Demir") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Altın") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Elmas") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Zümrüt") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Çim") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Cam") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Kum") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Kırıktaş") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Taş") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Toprak") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Tohum") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Buğday") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Havuç") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Patates") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Ekmek") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($fab == "Elma") {
                        $as = "true";
                        if ($data == 1) {
                            //seviye 1 fiyat
                            $fiyat = 31;
                        } elseif ($data == 2) {
                            //seviye 2 fiyat
                            $fiyat = 31;
                        } elseif ($data == 3) {
                            //seviye 3 fiyat
                            $fiyat = 31;
                        }
                    }
                    if ($data == "false") {
                        $g->sendMessage("§7» §cBu Fabrika Yükseltemezsin");
                    } else {

                        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                        $form = $api->createModalForm(function (Player $g, $data) {
                            $result = $data;
                            if ($result === null) {
                                return true;
                            }
                            switch ($result) {
                                case 0:
                                    $g->sendMessage("§7» §cFabrika Yükseltimedi");
                                    break;
                                case 1:
                                    $til = $g->getLevel()->getTiles();
                                    foreach ($til as $tile) {
                                        if ($tile instanceof Sign) {

                                            $oc = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $e->getPlayer()->getName() . ".yml", Config::YAML);
                                            $fab = $tile->getLine(1);
                                            if ($fab == $this->yuk[$g->getName()]) {
                                                $s1 = $oc->get("1");
                                                $s2 = $oc->get("2");
                                                $s3 = $oc->get("3");
                                                if (is_array($s1)) {
                                                    foreach ($s1 as $se1) {
                                                        if ($fab == $se1) {
                                                            $data = 2;
                                                        }
                                                    }
                                                } else {
                                                    if ($fab == $s1) {
                                                        $data = 2;
                                                    }
                                                }
                                                if (is_array($s2)) {
                                                    foreach ($s2 as $se2) {
                                                        if ($fab == $se2) {
                                                            $data = 3;
                                                        }
                                                    }
                                                } else {
                                                    if ($fab == $s2) {
                                                        $data = 3;
                                                    }

                                                    if (is_array($s3)) {
                                                        foreach ($s3 as $se2) {
                                                            if ($fab == $se3) {

                                                            }
                                                        }
                                                    } else {
                                                        if ($fab == $s3) {

                                                        }
                                                        if (isset($data)) {

                                                        } else {
                                                            $data = 1;
                                                        }
                                                        if ($fab == "Vip") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat

                                                                $fiyat = 31;
                                                            } elseif
                                                            ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 32;
                                                            } elseif
                                                            ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 33;
                                                            }
                                                        }
                                                        if ($fab == "Kömür") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat

                                                                $fiyat = 31;
                                                            } elseif
                                                            ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 32;
                                                            } elseif
                                                            ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 33;
                                                            }
                                                        }
                                                        if ($fab == "Demir") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Altın") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Elmas") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Zümrüt") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Çim") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Cam") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Kum") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Kırıktaş") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Taş") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Toprak") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Tohum") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Buğday") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Havuç") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Patates") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Ekmek") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if ($fab == "Elma") {
                                                            $as = "true";
                                                            if ($data == 1) {
                                                                //seviye 1 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 2) {
                                                                //seviye 2 fiyat
                                                                $fiyat = 31;
                                                            } elseif ($data == 3) {
                                                                //seviye 3 fiyat
                                                                $fiyat = 31;
                                                            }
                                                        }
                                                        if (EconomyAPI::getInstance()->myMoney($g->getName()) >= $fiyat) {
                                                            $oc = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $g->getName() . ".yml", Config::YAML);
                                                            EconomyAPI::getInstance()->reduceMoney($g->getName(), $fiyat, true);
                                                            $seviy = $oc->get($data);
                                                            $seviy[] = $fab;
                                                            $oc->set($data, $seviy);
                                                            $tile->setText("§7= §4Fabrika §7=", $fab, "§bSeviye: §a" . $data);

                                                            if ($data == "1") {

                                                            } else {
                                                                $datay = $data - 1;
                                                                $se = $oc->get($datay);
                                                                $deger = array_search($fab, $se);
                                                                unset($se[$deger]);
                                                                $oc->set($datay, $se);
                                                            }
                                                            $oc->save();
                                                            $g->sendMessage("§7» §aFabrika seviye atladı");
                                                        } else {
                                                            $g->sendMessage("§7» §cParan Yetersiz");
                                                        }
                                                    }
                                                }
                                            }


                                            $form->setTitle("§c§k!§r §bFabrika §c§k!§r");

                                            $form->setContent("§bTür:§a " . $fab . "\n§bYükseltilecek Seviye:§a " . $data . "\n§bFiyat:§a " . $fiyat);
                                            $form->setButton1("§aOnayla");
                                            $form->setButton2("§cReddet");
                                            $form->sendToPlayer($g);
                                        }


                                    }
                            }
                        }
  });
                }
            }