<?php

namespace SilverMCPE\Events;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent
;
class Kasa implements Listener {

  public function __construct($plugin){

		$this->main = $plugin;

	}
  
      public function onBreak(BlockBreakEvent $e){
$le = $e->getPlayer()->getLevel()->getFolderName();
if(strpos(strtolower($le), "[fab]") !== false) {
  $e->setCancelled();
}
  }
  public function onPlace(BlockPlaceEvent $e){
    $le = $e->getPlayer()->getLevel()->getFolderName();
    if(strpos(strtolower($le), "[fab]") !== false) {
      $e->setCancelled();
    }
  }
  public function onInteract(PlayerInteractEvent $e)
  {
    $le = $e->getPlayer()->getLevel()->getFolderName();
    if (strpos(strtolower($le), "[fab]") !== false) {
      if (strpos(strtolower($le), strtolower($e->getPlayer()->getName())) !== false) {

      }else{
        $e->setCancelled();
      }


    }
  }

}



