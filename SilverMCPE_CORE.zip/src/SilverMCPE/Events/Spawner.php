<?php

namespace SilverMCPE\Events;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\utils\Config;
use pocketmine\item\{Item, Pickaxe};
use pocketmine\block\Chest;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use korado531m7\InventoryMenuAPI\InventoryMenu;
use korado531m7\InventoryMenuAPI\event\InventoryClickEvent;
use korado531m7\InventoryMenuAPI\inventory\DoubleChestInventory;
use korado531m7\InventoryMenuAPI\inventory\ChestInventory;
use korado531m7\InventoryMenuAPI\InventoryType;
use pocketmine\inventory\Inventory;
use SilverMCPE\Tasks\SpawnerTask;
use pocketmine\Player;

class Spawner implements Listener {

  public function __construct($plugin){

		$this->main = $plugin;

	}
  public function onTouch(PlayerInteractEvent $e){

      $o = $e->getPlayer();
      $blok = $e->getBlock();
            if ($e->getItem() instanceof Pickaxe) {

      
      }else{

      if ($e->getBlock()->getId() == 52) {

        $folder = $this->main->getDataFolder();
      $this->ocfg = new Config($folder . "Plugin Verileri/OSpawnerlar.yml", Config::YAML);
       $this->cfg = new Config($folder . "Plugin Verileri/Spawnerlar.yml", Config::YAML);
      $this->pos1 = $blok->getX() . "," . $blok->getY() . "," . $blok->getZ() . "," . $blok->getLevel()->getFolderName();
      $sahibi = $this->ocfg->getNested($this->pos1 . ".Sahibi");
      if ($sahibi === null) {

      }elseif($sahibi == $o->getName()){

        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

        $form = $api->createModalForm(function (Player $o, $data) {
          $result = $data;
          if ($result === null) {
            return true;
          }
          switch ($result) {
            case 0:
              $o->sendMessage("§6Silver§fMcpe §7» §cSpawner yükseltilmedi.");
              break;
            case 1:
          $tür = $this->ocfg->getNested($this->pos1 . ".Tür");
          $level = $this->ocfg->getNested($this->pos1 . ".Level");
          $ylevel = $level + 1;
          $fiyat = $this->cfg->getNested( "Spawnerlar.". $tür .".Fiyat." . $ylevel);
                    $eco = $this->main->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    if ($ylevel >= 4) {
                      
                    }else{
            if ($eco->myMoney($o) >= $fiyat) {
              $eco->reduceMoney($o->getName(), $fiyat);
              $this->ocfg->setNested($this->pos1 . ".Level", $ylevel);
              $this->ocfg->save();
              $o->sendMessage("§6Silver§fMcpe §7» §aSpawner §e" . $ylevel . ".seviyeye §ayükseldi");
                    $pos2 = explode(",", $this->pos1);
               $this->main->getScheduler()->cancelTask($this->main->Id[implode(" ", $pos2)]);
        $süre = $this->cfg->getNested("Spawnerlar." . $tür . ".Süre.". $ylevel);
        $id = $this->cfg->getNested("Spawnerlar." . $tür . ".Id");
        if(empty($id)){
          $this->cfg = new Config($this->main->getDataFolder() . "Plugin Verileri/ÖSpawnerlar.yml", Config::YAML);
          $süre = $this->cfg->getNested("Spawnerlar." . $tür . ".Süre.". $ylevel);
          $id = $this->cfg->getNested("Spawnerlar." . $tür . ".Id");
        }

      $posi = explode(",", $this->pos1);
      $this->main->getScheduler()->cancelTask($this->main->Id[implode(" ", $posi)]);
      unset($this->main->Id[implode(" ", $posi)]);
                              $item = Item::get((int) $id);

             $kordi = explode(",", $this->pos1);
        $this->main->getScheduler()->scheduleRepeatingTask($task = new SpawnerTask($this->main, $kordi[0], $kordi[1], $kordi[2], $kordi[3], $item), 20 * $süre);
            $this->main->Id[implode(" ", $kordi)] = $task->getTaskID();
            }
}
              }
          


        });
          $tür = $this->ocfg->getNested($this->pos1 . ".Tür");
          $level = $this->ocfg->getNested($this->pos1 . ".Level");
          $ylevel = $level + 1;
          $fiyat = $this->cfg->getNested( "Spawnerlar.". $tür .".Fiyat." . $ylevel);

        $form->setTitle("§6Silver§bMcpe §r- Spawner");
        $form->setContent("§b" . $tür . " §aspawnerı §b" . $ylevel . "§aseviyesine §ayükseltmek için §b". $fiyat . "§aTL §alazım.\n\n§aYükseltmek istiyor musun?");
        $form->setButton1("Yükselt");
        $form->setButton2("Iptal");
                if ($ylevel == 4) {
                  $o->sendMessage("§6Silver§fMcpe §7» §cBu spawner yükseltilemez.");
                }else{
                  $form->sendToPlayer($o);
                }
        
      }else{
      $o->sendMessage("§6Silver§fMcpe §7» §cBu spawner sana ait değil.");
      $e->setCancelled();
      }
       
       


      }
    }
    }

    public function onBreak(BlockBreakEvent $e)
    {
      $o = $e->getPlayer();
      $blok = $e->getBlock();
      $item = $e->getItem();

      if ($e->getBlock()->getId() == 52) {
        $folder = $this->main->getDataFolder();
      $this->ocfg = new Config($folder . "Plugin Verileri/OSpawnerlar.yml", Config::YAML);
      $pos = $blok->getX() . "," . $blok->getY() . "," . $blok->getZ() . "," . $blok->getLevel()->getFolderName();
      $sahibi = $this->ocfg->getNested($pos . ".Sahibi");
      if ($sahibi === null) {
        
      }elseif($sahibi == $o->getName()){
        if ($o->getInventory()->getItemInHand()->getLore() == ["Spawner Kazması"]) {
                $it = Item::get(52, 0, 1);
      $isim = $this->ocfg->getNested($pos . ".Tür");
      $s = $this->ocfg->getNested($pos . ".Level");
      $this->ocfg->remove($pos);
      $this->ocfg->save();
    
      $it->setLore([$isim . " " . $s]);
        $it->setCustomName("§7» §e" .  $isim  ." §aSpawner §7«");
      $e->setDrops([$it]);
      $pos2 = explode(",", $pos);
      $this->main->getScheduler()->cancelTask($this->main->Id[implode(" ", $pos2)]);
      unset($this->main->Id[implode(" ", $pos2)]);
        }else{
          $e->setCancelled();
          $o->sendMessage("§6Silver§fMcpe §7»§c Spawner Kazması kullanmalısın");
        }

      }else{
      $o->sendMessage("§6Silver§fMcpe §7» §cBu spawner sana ait değil.");
      $e->setCancelled();
      }
       
       


      }
      
    }

  
/**
* @priority MONITOR
*/

    public function onPlace(BlockPlaceEvent $e){
      if($e->isCancelled()) return false;
      $it = $e->getItem();
      $o = $e->getPlayer();
      $blok = $e->getBlock();
      if ($it->getId() == 52) {

        if ($it->getLore() === null) {
        }else{
        $folder = $this->main->getDataFolder();
      $this->ocfg = new Config($folder . "Plugin Verileri/OSpawnerlar.yml", Config::YAML);
      $this->cfg = new Config($folder . "Plugin Verileri/Spawnerlar.yml", Config::YAML);
      $spd1 = implode(" ", $it->getLore());
      $spd = explode(" ", $spd1);
      if(!isset($spd[1])) return true;
          $pos = $blok->getX() . "," . $blok->getY() . "," . $blok->getZ() . "," . $blok->getLevel()->getFolderName();
        $this->ocfg->setNested($pos . ".Sahibi", $o->getName());
        $this->ocfg->setNested($pos . ".Tür", $spd[0]);
        $this->ocfg->setNested($pos . ".Level", $spd[1]);
        $this->ocfg->save();
        $o->sendMessage("§6Silver§fMcpe §7» §aSpawner yerleştirildi");
        $süre = $this->cfg->getNested("Spawnerlar." . $spd[0] . ".Süre." . $spd[1]);
        $id = $this->cfg->getNested("Spawnerlar." .  $spd[0] . ".Id");
        if(empty($id)){
          $this->cfg = new Config($this->main->getDataFolder() . "Plugin Verileri/ÖSpawnerlar.yml", Config::YAML);
          $süre = $this->cfg->getNested("Spawnerlar." . $spd[0] . ".Süre.". $spd[1]);
          $id = $this->cfg->getNested("Spawnerlar." . $spd[0] . ".Id");
        }

                    $item = Item::get((int) $id);
            $kordi = explode(",", $pos);
        $this->main->getScheduler()->scheduleRepeatingTask($task = new SpawnerTask($this->main, $kordi[0], $kordi[1], $kordi[2], $kordi[3], $item), 20 * $süre);

            $this->main->Id[implode(" ", $kordi)] = $task->getTaskID();
        }

      }
    }

}



