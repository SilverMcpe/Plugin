<?php

namespace SilverMCPE\Events;

use pocketmine\block\Stair;
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerJumpEvent;
use pocketmine\event\player\PlayerToggleSneakEvent;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\RemoveActorPacket;
use pocketmine\network\mcpe\protocol\SetActorLinkPacket;
use pocketmine\network\mcpe\protocol\types\EntityLink;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\item\Item;
use pocketmine\block\Chest;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use korado531m7\InventoryMenuAPI\InventoryMenu;
use korado531m7\InventoryMenuAPI\event\InventoryClickEvent;
use korado531m7\InventoryMenuAPI\inventory\DoubleChestInventory;
use korado531m7\InventoryMenuAPI\inventory\ChestInventory;
use korado531m7\InventoryMenuAPI\InventoryType;
use pocketmine\inventory\Inventory;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\math\Vector3;
use pocketmine\level\particle\MobSpawnParticle;

class Kasa implements Listener
{

    public $indexs = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 17, 18, 26, 27, 35, 36, 44, 45, 46, 52, 53, 49];

    public function __construct($plugin)
    {

        $this->main = $plugin;
        $this->cfg = new Config($this->main->getDataFolder() . "Plugin Verileri/Kasalar.yml", Config::YAML);

    }

    public function SeatDown($player, $stair)
    {
        $sx = intval($stair->getX());
        $sy = intval($stair->getY());
        $sz = intval($stair->getZ());
        $nx = $sx + 0.5;
        if ($stair instanceof Stair){
            $ny = $sy + 1.5;
        }else{
            $ny = $sy + 2.0;
        }
        $nz = $sz + 0.5;
        $pk = new AddActorPacket();
        $entityRuntimeId = $player->getId() + 10000;
        $this->onChair[$player->getName()] = $entityRuntimeId;
        $pk->entityRuntimeId = $entityRuntimeId;
        $pk->type = AddActorPacket::LEGACY_ID_MAP_BC[84];
        $pk->position = new Vector3($nx, $ny, $nz);
        $pk->motion = new Vector3(0, 0, 0);
        $flags = (
            (1 << Entity::DATA_FLAG_IMMOBILE) | (1 << Entity::DATA_FLAG_INVISIBLE)
        );
        $pk->metadata = [
            Entity::DATA_FLAGS => [Entity::DATA_TYPE_LONG, $flags],
        ];

        $pk->links[] = new EntityLink($pk->entityRuntimeId, $player->getId(), 2, true, false);
        $player->dataPacket($pk);
        Server::getInstance()->broadcastPacket(Server::getInstance()->getOnlinePlayers(), $pk);
        $id = $pk->entityRuntimeId;
        $pk = new SetActorLinkPacket();
        $pk->link = new EntityLink($id, $player->getId(), 2, true, false);
        $player->dataPacket($pk);
    }
    public function onSneak(PlayerToggleSneakEvent $event){

        $player = $event->getPlayer();
        if (isset ($this->onChair [$player->getName()])) {
            $this->StandUp($player);
            unset ($this->onChair [$player->getName()]);
            unset($this->doubleTap[$player->getName()]);
        }
    }

    public function StandUp($player)
    {
        $removepk = new RemoveActorPacket();
        $removepk->entityUniqueId = $this->onChair [$player->getName()];
        Server::getInstance()->broadcastPacket(Server::getInstance()->getOnlinePlayers(), $removepk);
    }


    public function onJump(PlayerJumpEvent $event)
    {
        $player = $event->getPlayer();
        if (isset ($this->onChair [$player->getName()])) {
            $this->StandUp($player);
            unset ($this->onChair [$player->getName()]);
            unset($this->doubleTap[$player->getName()]);
        }
    }

    public function onTouch(PlayerInteractEvent $e)
    {
        $g = $e->getPlayer();
        $player = $e->getPlayer();
        $block = $e->getBlock();
        $this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $player->getName() . ".yml", Config::YAML);
        if ($this->cfg->get("oturma") and $player->getInventory()->getItemInHand()->getId() == 0) {
            if (!empty($this->onChair[$player->getName()])) $this->StandUp($player);
            if (empty($this->doubleTap[$player->getName()])) {
                $this->doubleTap[$player->getName()] = true;
                $player->sendPopup("§aTekrar tıklayın");
                return;
            }
            $this->SeatDown($player, $block);
            unset($this->doubleTap[$player->getName()]);
        }
        $p = $e->getPlayer();
        $block = $e->getBlock();
        $pos = $block->getX() . ", " . $block->getY() . ", " . $block->getZ() . ", " . $block->getLevel()->getFolderName();
        if (isset($this->main->kasaKDurum[$p->getName()])) {
            if ($block instanceof Chest) {

                $this->cfg->set($pos, $this->main->kasaIsim[$p->getName()]);
                $this->cfg->save();
                unset($this->main->kasaKDurum[$p->getName()]);
                unset($this->main->kasaIsim[$p->getName()]);
                $p->sendMessage("Kasa ayarlandı");
            } else {

                $p->sendMessage("§cSandığa tıkla");

            }
        } elseif (!empty($this->cfg->get($pos))) {
            if ($block instanceof Chest) {
                $kasa = $this->cfg->get($pos);
                if ($kasa == "Vip Kasası") {
                    if ($p->hasPermission("vip")) {

                    } else {
                        $p->sendMessage("Bu kasayı açamazsınız.");
                        return true;
                    }
                }


                $anahtar = Item::get((int)$this->cfg->getNested($kasa . ".Anahtar"));
                $it = $p->getInventory()->getItemInHand();
                $e->setCancelled();
                if ($anahtar->getId() == $it->getId() && $anahtar->getDamage() == $it->getDamage()) {
                    $array = $this->cfg->getNested($kasa . ".Itemler");
                    $itid = array_rand($array);
                    $it_id = explode(",", $array[$itid]);
                    $item = Item::get((int)$it_id[0], $it_id[1], $it_id[2]);
                    $datas = 3;
                    $this->enchAdd($datas, $it_id, $item);

                    $p->getLevel()->addSound(new AnvilFallSound(new Vector3($p->x, $p->y, $p->z)));
                    $p->getLevel()->addParticle(new MobSpawnParticle(new Vector3($block->x, $block->y + 1, $block->z)));
                    $p->getInventory()->removeItem(Item::get($it->getId(), $it->getDamage(), 1));
                    $p->getInventory()->addItem($item);
                    $p->sendPopup("§8- §a" . $item->getCustomName() . " §8-");
                } else {
                    $this->caseView($p, $kasa);
                }


            }

        }
    }

    public function enchAdd($data, $itd, $item)
    {

        if (isset($itd[$data]) && isset($itd[$data + 1])) {

            $enc = Enchantment::getEnchantment($itd[$data]);
            $enc1 = new EnchantmentInstance($enc, $itd[$data + 1]);
            $item->addEnchantment($enc1);
            $ydata = $data + 2;
            $this->enchAdd($ydata, $itd, $item);

        } else {

            if (isset($itd[$data])) {

                $item->setCustomName($itd[$data]);
            } else {


            }

        }


    }


    public function caseView($p, $kasa, $data = 0)
    {

        if ($data < 0){
            $data = 0;
        }
        $this->kasa = $kasa;
        $this->olddata = $data;
        $max = $data + 11;
        $menu = new DoubleChestInventory();
        $id = $this->cfg->getNested($kasa . ".Id");
        $exp = explode(":", $id);
        $item = Item::get($exp[0], $exp[1], 1);
        foreach ($this->indexs as $index) {
            $menu->setItem($index, $item);
        }
        foreach ([48, 50] as $i) {
            $menu->setItem($i, Item::get(Item::PAPER, $i));

        }
        for ($i = $data; $i < $max; $i++){
            if (isset($this->cfg->getNested($kasa . ".Itemler")[$i])){
                $it = $this->cfg->getNested($kasa . ".Itemler")[$i];
                $it_id = explode(",", $it);
                $item = Item::get((int)$it_id[0], $it_id[1], $it_id[2]);
                $datas = 3;
                $this->enchAdd($datas, $it_id, $item);

                $menu->setItem($i + 21, $item);
            }
        }
        $menu->setClickedCallable(function (InventoryClickEvent $event) {
            $index = $event->getItem()->getDamage();
            if ($event->getItem()->getId() == Item::PAPER) {
                if($index == 48){
                    $this->caseView($event->getPlayer(), $this->kasa, $this->olddata - 10);
                }
                if($index == 50){
                    $this->caseView($event->getPlayer(), $this->kasa, $this->olddata + 10);
                }
            }
        });
        $menu->setName($kasa);
        $menu->send($p);
    }


}



