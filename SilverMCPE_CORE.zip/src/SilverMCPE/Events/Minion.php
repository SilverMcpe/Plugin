<?php

namespace SilverMCPE\Events;

/*
 * TO-DO:
 * Minion Vurma engelle [%0]
 * Minion animasyonlu kırma [%0]
 * minion envanter aktarma doluysa huniye atma [%0]
 * Çiftçi kemik tozu basma [%0]
 */

use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\utils\Config;
use pocketmine\block\Block;
use pocketmine\scheduler\Task;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\entity\{Entity, Human};

class Minion implements Listener
{

	public function __construct($plugin)
	{

		$this->main = $plugin;
	}

    public function onInteract(PlayerInteractEvent $e){
		$item = $e->getItem();
		if($item->getId() == 501){
			$this->itemSil(501, $e->getPlayer());
			$id = $this->minionSpawnla("Madenci", $e->getBlock(), $e->getPlayer());
			$this->cfg = new Config($this->main->getDataFolder() . "Minions.yml", Config::YAML);
			$this->cfg->set($id, $e->getPlayer()->getName() ."," . "Madenci");
			$this->cfg->save();
		}elseif($item->getId() == 506){
			$this->itemSil(506, $e->getPlayer());
			$id = $this->minionSpawnla("Çiftçi", $e->getBlock(), $e->getPlayer());
			$this->cfg = new Config($this->main->getDataFolder() . "Minions.yml", Config::YAML);
			$this->cfg->set($id, $e->getPlayer()->getName() ."," . "Çiftçi");
			$this->cfg->save();
		}elseif($item->getId() == 502){
			$this->itemSil(502, $e->getPlayer());
			$id = $this->minionSpawnla("Oduncu", $e->getBlock(), $e->getPlayer());
			$this->cfg = new Config($this->main->getDataFolder() . "Minions.yml", Config::YAML);
			$this->cfg->set($id, $e->getPlayer()->getName() ."," . "Oduncu");
			$this->cfg->save();
		}
	}

	/**
	 * @param String $tür
	 * @param Block $b
	 * @param Player $p
	 */
	public function minionSpawnla(String $tür, Block $b, Player $p): Int{

		$nbt = Entity::createBaseNBT($p->add(0, 2));
		$skinTag = $p->namedtag->getCompoundTag("Skin");
		assert($skinTag !== null);
		$nbt->setTag(clone $skinTag);
		$entity = Entity::createEntity("Human", $b->getLevel(), $nbt);
		if($tür == "Madenci"){
			$entity->setNameTag("§7» §eMadenci §7«");
			$entity->getInventory()->setItemInHand(Item::get(Item::DIAMOND_PICKAXE));
		}elseif($tür == "Çiftçi"){
			$entity->setNameTag("§7» §aÇiftçi §7«");
			$entity->getInventory()->setItemInHand(Item::get(Item::DIAMOND_HOE));

		}else{
			$entity->setNameTag("§7» §bOduncu §7«");
			$entity->getInventory()->setItemInHand(Item::get(Item::DIAMOND_AXE));
		}

		$entity->setHealth(1);
		$entity->setMaxHealth(1);
		$entity->setNameTagAlwaysVisible();
		$scale = (float) 0.6;
		$entity->getDataPropertyManager()->setFloat(Entity::DATA_SCALE, $scale);
		$entity->sendData($entity->getViewers());

		$entity->spawnToAll();

      return $entity->getId();
	}



	/**
	 * @param Int $id
	 * @param Player $p
	 */
	public function itemSil(Int $id, Player $p){
       $item = Item::get($id, 0, 1);
       $p->getInventory()->removeItem($item);

	}

}