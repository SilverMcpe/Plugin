<?php

namespace SilverMCPE\Events;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\utils\Config;
use pocketmine\block\Block;
use pocketmine\scheduler\Task;

class Otoenvanter implements Listener
{

    public function __construct($plugin)
    {

        $this->main = $plugin;

    }

    /**
     * @priority MONITOR
     */

    public function onBreak(BlockBreakEvent $e)
    {
        if ($e->isCancelled()) return false;
        $this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $e->getPlayer()->getName() . ".yml", Config::YAML);
        if ($this->cfg->get("Otoenvanter") == true) {
            $worlds = ["lobi", "markettt"];
            if (in_array($e->getBlock()->getLevel()->getFolderName(), $worlds)) {

            } else {
                $drops = $e->getDrops();
                foreach ($drops as $drop) {
                    if ($drop->getId() == 52) {

                    } else {
                        $e->setDrops([]);

                        $e->getPlayer()->getInventory()->addItem($drop);


                    }

                }
            }


        }


    }

}



