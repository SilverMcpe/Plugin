<?php

namespace SilverMCPE\Events;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\inventory\PlayerInventory;
use pocketmine\utils\Config;
use pocketmine\block\Block;
use pocketmine\tile\Sign;
use pocketmine\scheduler\Task;
use pocketmine\Player;

class AdaE implements Listener
{
    public const DEFAULT = 50;

    public $blocks = [1];
    public function __construct($plugin)
    {

        $this->main = $plugin;
        $this->worlds = ["obsidhm", "world", "end", "nether"];

    }
    public function onSign(SignChangeEvent $e)
    {

        $b = $e->getBlock();
        $p = $e->getPlayer();
        if ($e->getLine(0) == "pziyaret") {

            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);


            if ($p->getName() == $p->getLevel()->getFolderName()) {

                $e->setLines(["§8[§aPazar Ziyareti§8]", "§e" . "§eSahibi §7: §f" . $e->getPlayer()->getName(), "", ""]);
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                $this->cfg->set("PZ", $b->getX() . ":" . $b->getY() . ":" . $b->getZ());
                $this->cfg->save();
            } else {
                $p->sendMessage("§6Silver§fMcpe §7»§c Buraya kuramazsın.");

            }

        }
    }


    public function onBreak(BlockBreakEvent $e)
    {
        if ($e->isCancelled()) return false;
        $p = $e->getPlayer();
        $b = $e->getBlock();
        if ($this->kontrol($p, "BKı")) {
            if ($e->getBlock()->getName() == "Wall Sign" || $e->getBlock()->getName() == "Sign Post") {
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                $kordi = $this->cfg->get("PZ");
                if ($kordi == $b->getX() . ":" . $b->getY() . ":" . $b->getZ()) {
                    $this->cfg->remove("PZ");
                    $this->cfg->save();
                    $p->sendMessage("§6Silver§fMcpe §7» §cPazar tabelası kaldırıldı.");
                } else {
                }
            }
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            $ada = $this->cfg->get("AIsim");
            $this->cfg = new Config($this->main->getDataFolder() . $ada . ".json", Config::JSON);
            if (in_array($e->getBlock()->getId(), $this->blocks)){
                if (empty($this->cfg->get("sınır"))){
                    $this->cfg->set("sınır", self::DEFAULT);
                    $this->cfg->set("placed", 0);
                    $this->cfg->save();
                }
                $placed = $this->cfg->get("placed");
                $placed--;
                if ($placed < 0){
                }else{
                    $this->cfg->set("placed", $placed);
                    $this->cfg->save();
                }
            }

            $this->adaLevel($p, "Break", $e);


        } else {
            if (in_array($p->getLevel()->getFolderName(), $this->worlds)) return true;
            $e->setCancelled();
        }

    }

    /*public function onPickup(InventoryPickupItemEvent $e){

        if($this->kontrol($p, "IA")){

        }else{
            $e->setCancelled();
        }

       }*/
    public function onPlace(BlockPlaceEvent $e)
    {

        if ($e->isCancelled()) return false;

        $p = $e->getPlayer();
        if ($this->kontrol($p, "BKo")) {
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            $ada = $this->cfg->get("AIsim");
            $this->cfg = new Config($this->main->getDataFolder() . $ada . ".json", Config::JSON);
            if (in_array($e->getBlock()->getId(), $this->blocks)){
                if (empty($this->cfg->get("sınır"))){
                    $this->cfg->set("sınır", self::DEFAULT);
                    $this->cfg->set("placed", 0);
                    $this->cfg->save();
                }
                $sinir = $this->cfg->get("sınır");
                $placed = $this->cfg->get("placed");
                if ($placed >= $sinir){
                    $e->setCancelled();
                    $p->sendMessage("§cSınırın doldu");
                    return;
                }
                $placed++;
                $this->cfg->set("placed", $placed);
                $this->cfg->save();
            }

            $this->adaLevel($p, "Place", $e);
        } else {
            if (in_array($p->getLevel()->getFolderName(), $this->worlds)) return true;
            $e->setCancelled();
        }

    }

    public function onBInteract(PlayerInteractEvent $e)
    {
        $p = $e->getPlayer();
        if ($e->isCancelled()) return false;
        if ($p->getLevel()->getFolderName() == "[fab]" . $e->getPlayer()->getName()) return true;

        if ($this->kontrol($p, "CA")) {
        } else {
            if (in_array($p->getLevel()->getFolderName(), $this->worlds)) return true;
            $e->setCancelled();
        }

    }


    /**
     * @priority MONITOR
     */
    public function onPvp(EntityDamageByEntityEvent $e)
    {

        if ($e->isCancelled()) return false;
        $p = $e->getDamager();
        $en = $e->getEntity();
        $lada = $e->getEntity()->getLevel()->getFolderName();
        if ($p instanceof Player) {

        } else {
            return false;
        }
        if (!empty($this->main->id1) && !empty($this->main->id2) && !empty($this->main->id3)) {
            if ($en->getId() == $this->main->id1 || $en->getId() == $this->main->id2 || $en->getId() == $this->main->id3) {
                $e->setCancelled();
                return false;
            }
        }


        $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
        $this->pcfg = new Config($this->main->getDataFolder() . $this->cfg->get("AIsim") . ".json", Config::JSON);
        if ($lada == $this->cfg->get("AIsim")) {


            if (!$this->pcfg->get("Pvp")) {
                $enti = $e->getEntity();
                if ($enti == null) {
                }
                if ($enti instanceof Player) {
                    $e->setCancelled();
                } else {

                    return false;
                }

            } elseif ($this->pcfg->get("Pvp")) {

            } else {
                $enti = $e->getEntity();
                if ($enti == null) {

                }
                if ($enti instanceof Player) {
                    $e->setCancelled();
                } else {

                    return false;
                }


            }
        } else {

            $cfg = new Config($this->main->getDataFolder() . "mapler.yml", Config::YAML);
            if (empty($cfg->get($e->getDamager()->getLevel()->getFolderName() . "-pvp"))) {
                $e->setCancelled();
            } else {
                if ($cfg->get($e->getDamager()->getLevel()->getFolderName() . "-pvp") == "aktif") {

                } else {
                    $e->setCancelled();
                }
            }

        }

    }

    public function onDrop(InventoryPickupItemEvent $event){
        $inv = $event->getInventory();
        if ($inv instanceof PlayerInventory){
            if (!isset($inv->getViewers()[0])) return false;
            $player = $inv->getViewers()[0];
            if ($player->isOp()) return true;
            if ($player->getName() == $player->getLevel()->getFolderName()) {
                return true;
            } else {
                $this->cfg = new Config($this->main->getDataFolder() . $player->getName() . ".json", Config::JSON);
                if ($this->cfg->get("AIsim") == $player->getLevel()->getFolderName()) {

                }else{
                    $event->setCancelled();
                }
            }
        }
    }
    public function kontrol($p, $event)
    {
        if ($p->isOp()) return true;
        if ($p->getName() == $p->getLevel()->getFolderName()) {
            return true;
        } else {
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if ($this->cfg->get("AIsim") == $p->getLevel()->getFolderName()) {
                if ($this->cfg->get($event)) {

                    return true;
                } else {
                    return false;
                }

            } else {
                if ($this->cfg->getNested($p->getLevel()->getFolderName() . "." . $event)) {
                    return true;
                } else {
                    return false;
                }
            }

        }
    }


    public function adaLevel($p, $event, $e)
    {
        $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);

        $this->cfg = new Config($this->main->getDataFolder() . $this->cfg->get("AIsim") . ".json", Config::JSON);

        $this->bloklar = new Config($this->main->getDataFolder() . "adalevel.json", Config::JSON);

        if ($event == "Place") {
            $xp = $this->cfg->get("xp");
            $sxp = $this->cfg->get("sxp");
            $item = $p->getInventory()->getItemInHand();
            if ($this->bloklar->get($item->getId() . "," . $item->getDamage()) != null) {
                $xpa = $this->bloklar->get($item->getId() . "," . $item->getDamage());
                $yxp = $xp + $xpa;
                if ($yxp >= $sxp) {
                    $level = $this->cfg->get("level");
                    $ylevel = $level + 1;
                    $this->level = new Config($this->main->getDataFolder() . "toplevel.json", Config::JSON);
                    if ($this->cfg->get("AIsim") != null) {
                        $this->level->set($this->cfg->get("AIsim"), $ylevel);
                    } else {
                        $this->level->set($p->getName(), $ylevel);
                    }
                    $this->level->save();
                    $this->cfg->set("level", $ylevel);
                    $this->cfg->set("xp", 0);
                    $ysxp = $sxp + 200;
                    $this->cfg->set("sxp", $ysxp);
                    $pc = $this->main->getServer()->getPluginManager()->getPlugin("PureChat");
                    $pc->setSuffix($ylevel, $p);
                    $p->sendMessage("§6Silver§fMcpe §7» §aLevel atlandı.");
                } else {
                    $this->cfg->set("xp", $yxp);
                }
                $this->cfg->save();
            }

        }
        if ($event == "Break") {
            $xp = $this->cfg->get("xp");
            $sxp = $this->cfg->get("sxp");
            $item = $e->getBlock();
            if ($item->getId() == 1 || $item->getId() == 4 && $item->getDamage() == 0) {
                return true;
            }
            if ($this->bloklar->get($item->getId() . "," . $item->getDamage()) != null) {
                $xpa = $this->bloklar->get($item->getId() . "," . $item->getDamage());
                $yxp = $xp - $xpa;
                if ($yxp <= 0) {
                    $level = $this->cfg->get("level");
                    $ylevel = $level - 1;
                    $this->cfg->set("level", $ylevel);
                    if ($ylevel <= 0) return true;
                    $this->level = new Config($this->main->getDataFolder() . "toplevel.json", Config::JSON);
                    if ($this->cfg->get("AIsim") != null) {
                        $this->level->set($this->cfg->get("AIsim"), $ylevel);
                    } else {
                        $this->level->set($p->getName(), $ylevel);
                    }
                    $this->cfg->set("xp", 0);
                    $ysxp = $sxp - 200;
                    $this->cfg->set("sxp", $ysxp);
                    $pc = $this->main->getServer()->getPluginManager()->getPlugin("PureChat");
                    $pc->setSuffix($ylevel, $p);
                    $p->sendMessage("§6Silver§fMcpe §7» §cLevel Düştü");
                } else {
                    $this->cfg->set("xp", $yxp);
                }
                $this->cfg->save();
            }

        }

    }

}