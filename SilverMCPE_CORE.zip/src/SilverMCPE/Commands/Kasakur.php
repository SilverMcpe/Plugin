<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;

class Kasakur extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('kasakur', $plugin);
		$this->setDescription('Kasa Kurma');
		$this->setPermission("admin.command");
		$this->main = $plugin;
		$this->cfg = new Config($this->main->getDataFolder() . "Kasalar.yml", Config::YAML);
	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
			if ($p->isOp()) {
				if (isset($args[0])){
					
						if ($this->cfg->get($args[0]) !== null){
						$this->main->kasaKDurum[$p->getName()] = "true";
						$this->main->kasaIsim[$p->getName()] = $args[0];
						$p->sendMessage("§aSandığa tıkla");
					}else{
					$p->sendMessage("§c/kasakur <kasa ismi>");
				}
			
		}
			}
      return true;
	}



	}