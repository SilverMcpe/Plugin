<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
    Command,
    PluginCommand,
	ConsoleCommandSender,
    CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use korado531m7\InventoryMenuAPI\InventoryMenu;
use korado531m7\InventoryMenuAPI\InventoryType;
use korado531m7\InventoryMenuAPI\inventory\ChestInventory;
use korado531m7\InventoryMenuAPI\event\InventoryClickEvent;
use korado531m7\InventoryMenuAPI\inventory\DoubleChestInventory;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\Level;

class FabrikaAda extends PluginCommand{

    public $oyuncu = array();

    public function __construct($plugin){
        parent::__construct('fabrika', $plugin);
        $this->setDescription('Fabrika Menüsü');
        $this->plugin = $plugin;
    }


    public function execute(CommandSender $g, string $commandLabel, array $args): bool{

        $api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");
			$form = $api->createSimpleForm(function (Player $g, int $args = null){
			$result = $args;
			if($result === null){

			return true;
			}
			switch ($result) {
				case 0:

								$ofab = $this->plugin->getDataFolder() . "Fabrika Adalar/" .$g->getName() . ".yml";
								if (!file_exists($ofab)) {




									$sd = $this->plugin->getServer()->getDataPath();
									@mkdir($sd . "worlds/" . "[fab]" . $g->getName() . "/");
									@mkdir($sd . "worlds/" . "[fab]" . $g->getName() . "/region/");
									$dunya = opendir($this->plugin->getServer()->getDataPath() . "FAB/region/");
									while ($dosya = readdir($dunya)) {
										if ($dosya != "." and $dosya != "..") {
											copy($sd . "FAB/region/" . $dosya, $sd . "worlds/" ."[fab]" . $g->getName() . "/region/" . $dosya);
										}
									}

									copy($sd . "FAB/level.dat", $sd . "worlds/" . "[fab]" .$g->getName() . "/level.dat");
									$this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender, "lvdat " . $g->getName() . " fixname");

                                    $fab = new Config($this->plugin->getDataFolder(). "Fabrika Adalar/" . $g->getName() . ".yml", Config::YAML);

$fab->save();
									$this->plugin->getServer()->loadLevel("[fab]" . $g->getName());
									$dnya = $this->plugin->getServer()->getLevelByName("[fab]" . $g->getName());
									$spawn = $dnya->getSafeSpawn();
									$g->teleport($spawn, 0, 0);
									$g->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));

									$g->addTitle("§6Silver§fMCPE §7» §aFabrika Oluşturuldu!");
								} else {
									$g->sendMessage("§6Silver§fMCPE §7» §cZaten Bir Fabrikaya Sahipsin!");
								}

					break;
				case 1:
					$oada = $this->plugin->getDataFolder() . "Fabrika Adalar/" . $g->getName() . ".yml";
					if (file_exists($oada)) {
						$this->plugin->getServer()->loadLevel("[fab]" . $g->getName());
						$dnya = $this->plugin->getServer()->getLevelByName("[fab]" . $g->getName());
						$spawn = $dnya->getSafeSpawn();
						$g->teleport($spawn, 0, 0);
						$g->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));
						$g->addTitle("§6Silver§fMCPE §7» §aFabrikaya Işınlandınız!");
					} else {
						$g->sendMessage("§6Silver§fMCPE §7» §cÖnce Fabrika Oluşturmalısın!");
					}
					break;
				case 2:
					$apii = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");

					$for = $apii->createCustomForm(function (Player $g, array $data = null) {
						$result = $data;
						if ($result === null) {
							return true;
						}
                    foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                    	$nick[] = $p->getName();
                    }
                    $data[0] = $nick[$data[0]];
						$oada = $this->plugin->getDataFolder() .  "Fabrika Adalar/" . $data[0] . ".yml";
						if (file_exists($oada)) {
							$oadac = new Config($this->plugin->getDataFolder() . "Fabrika Adalar/" . $g->getName() . ".yml", Config::YAML);
							$this->plugin->getServer()->loadLevel("[fab]" . $data[0]);
							$dnya = $this->plugin->getServer()->getLevelByName("[fab]" . $data[0]);
							$spawn = $dnya->getSafeSpawn();
							$g->teleport($spawn, 0, 0);
							$g->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));
							$g->addTitle("§6Silver§fMcpe§7» §b" . $data[0] . " §aFabrikasını Ziyaret Ediyorsun");
							$o = $this->plugin->getServer()->getPlayer($data[0]);
							if ($o instanceof Player){
								$o->sendMessage("§6Silver§f §7» §b" . $g->getName() . " §aFabrikanı Ziyaret Ediyor");
							}
						} else {
							$g->sendMessage("§6Silver§fMCPE §7» §cOyuncunun Fabrikası Yok!");
						}

					});

                    foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                    	$nick[] = $p->getName();
                    }
					$for->setTitle("§6Silver§fMCPE §r- Fabrika Ziyaret");
					$for->addDropdown("§bOyuncu", $nick);

					$for->sendToPlayer($g);
					
					}
					
        });
        $form->setTitle("§6Silver§fMCPE §r- Fabrika Ada");
        $form->addButton("Fabrika Oluştur");
        $form->addButton("Fabrika Işınlan");
        $form->addButton("Fabrika Ziyaret");


        $form->sendToPlayer($g);


        return true;
    }

}