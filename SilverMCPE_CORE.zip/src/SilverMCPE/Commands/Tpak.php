<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;

class Tpak extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('tpak', $plugin);
		$this->setDescription('Oyuncuya ışınlanma isteği kabul et');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
		$istek = $this->main->tpaIstekSorgula($p);
		if($istek == "false"){
			$p->sendMessage("§6Silver§fMCPE §7» §cIşınlanma isteği bulunamadı.");
		}else{
			$o = $this->main->getServer()->getPlayer($istek);
			if ($o instanceof Player) {
			    if($p->getLevel()->getFolderName() != "tnether" || $p->getLevel()->getFolderName() != "tend"){
                    $o->sendMessage("§6Silver§fMCPE §7» §cBu alana ışınlanamazsın.");
                    return true;
                }
						$o->sendMessage("§6Silver§fMCPE §7» §aIşınlanıyorsunuz.");
						$o->teleport($p);
						unset($this->main->istek[$p->getName()]);
			}else{
				$p->sendMessage("§6Silver§fMCPE §7» §eOyuncu bulunamadı.");
			}
		}

      return true;
	}



	}