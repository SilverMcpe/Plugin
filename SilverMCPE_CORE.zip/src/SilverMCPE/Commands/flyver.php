<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use SilverMCPE\Tasks\FlyTask;
use pocketmine\Server;
use pocketmine\math\Vector3;

class flyver extends PluginCommand
{


	public function __construct($plugin)
	{
		parent::__construct('flyver', $plugin);
		$this->setDescription('Bir oyuncuya fly verir');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
		if(!$p->hasPermission("flyver")){
			return true;
		}
		if(isset($args)){
			$isim = implode(" ", $ærgs);
			$o = $this->main->getServer()->getPlayer($isim);
			$this->main->getScheduler()->scheduleRepeatingTask($task = new FlyTask($this->main, $o), 20);
			$this->main->FlyId[$o->getName()] = $task->getTaskID();
			$this->main->FlySure[$o->getName()] = 600;
			$o->sendMessage("§6Silver§fMcpe §7» §aAdaFly aktif edildi. Not: Oyundan çıkarsanız veya mekan değiştirirsiniz paranız boşa gider.");
			$o->setAllowFlight(true);
		}



		return true;
	}

}