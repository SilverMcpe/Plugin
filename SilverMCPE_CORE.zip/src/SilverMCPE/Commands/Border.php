<?php

namespace SilverMCPE\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\utils\CommandException;
use pocketmine\utils\Config;
use SilverMCPE\Main;

class Border extends Command{

    public function __construct(Main $main)
    {
        $this->main = $main;
        parent::__construct("sinir", "Bir oyuncunun sınırını ayarlamanızı sağlar");
        $this->setPermission("silver.cmd.sinir");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$this->testPermission($sender)) return;
        if (isset($args[0]) and isset($args[1])){
            $this->cfg = new Config($this->main->getDataFolder() . $args[0] . ".json", Config::JSON);
            $ada = $this->cfg->get("AIsim");
            $this->cfg = new Config($this->main->getDataFolder() . $ada . ".json", Config::JSON);
            if (is_int($args[1])){
                $sinir = $this->cfg->get("sınır");
                $sinir = $sinir + $args[1];
                $this->cfg->set("sınır", $sinir);
                $this->cfg->save();
            }

        }
    }
}