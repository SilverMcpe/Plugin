<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;

class ping extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('ping', $plugin);
		$this->setDescription('Ping değerini öğrenersin.');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
        
           $p->sendMessage("§6Silver§fMCPE §7» §aPingin:§f "  . $p->getPing());

      return true;
	}



	}