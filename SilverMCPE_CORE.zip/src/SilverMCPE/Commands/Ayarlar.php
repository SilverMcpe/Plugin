<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\entity\{Zombie, Human, Entity};
use pocketmine\math\Vector3;
use pocketmine\item\Item;

class Ayarlar extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('ayarlar', $plugin);
		$this->setDescription('Ayarlar');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
		$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $p->getName() . ".yml", Config::YAML);
		$apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

		$for = $apii->createCustomForm(function (Player $p, array $data = null) {
		$result = $data;
	if ($result === null) {
			return true;
		}
		        $h = array(1, 2, 3);
				$this->cfg->set("Otoenvanter", $data[0]);
				$this->cfg->set("Tpa", $data[1]);
				$this->cfg->set("Msg", $data[2]);
				$this->cfg->set("Arkadas", $data[3]);
			    //$this->cfg->set("Scoreboard", $data[4]);
			$this->cfg->set("oturma", $data[4]);

			/*$api = $this->main->getServer()->getPluginManager()->getPlugin("ScoreboardAPI");
			$scoreboard = $api->createScoreboard("objective", "SilverMCPE"); //create scoreboard
			    if($data[4]){

					$api->sendScoreboard($scoreboard, [$p]);
				}else{
					$api->removeScoreboard($scoreboard, [$p]);
				}*/
				$this->cfg->set("TasHız", $h[$data[5]]);
				$this->cfg->save();
				$p->sendMessage("§6Silver§fMCPE §7» §aAyarlar kaydedildi.");
				

	});
		
		$for->setTitle("§6Silver§fMcpe§r - Ayarlar");
		$for->addToggle("Oto Envanter", $this->cfg->get("Otoenvanter"));
		$for->addToggle("Tpa İstekleri", $this->cfg->get("Tpa"));
		$for->addToggle("Özel Mesaj", $this->cfg->get("Msg"));
		$for->addToggle("Arkadaşlık İstekleri", $this->cfg->get("Arkadas"));
        $for->addToggle("Oturma", $this->cfg->get("oturma"));
        if($this->cfg->get("Scoreboard") != null){
			$a = $this->cfg->get("Scoreboard");
		}else{
			$a = true;
		}
		/*$for->addToggle("Scoreboard", $this->cfg->get("Scoreboard"));*/
		if($p->hasPermission("vip")){
			$hiz = ["3", "4"];
		}elseif($p->hasPermission("vip")){
			$hiz = ["2", "3", "4"];
		}elseif($p->hasPermission("vip")){
			$hiz = ["1", "2", "3", "4"];
		}else{
            $hiz = ["4"];
		}
        $for->addStepSlider("Taş Hızı", $hiz);
		$for->sendToPlayer($p);
       

      return true;
	}



	}