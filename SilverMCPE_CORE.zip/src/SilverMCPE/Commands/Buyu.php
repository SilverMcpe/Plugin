<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use korado531m7\InventoryMenuAPI\InventoryMenu;
use korado531m7\InventoryMenuAPI\InventoryType;
use korado531m7\InventoryMenuAPI\inventory\ChestInventory;
use korado531m7\InventoryMenuAPI\event\InventoryClickEvent;
use korado531m7\InventoryMenuAPI\inventory\DoubleChestInventory;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\Level;
use onebone\economyapi\EconomyAPI;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;

class Buyu extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('buyu', $plugin);
		$this->setDescription('Eşyalarınıza büyü basarsınız.');
		$this->plugin = $plugin;
	}


	public function execute(CommandSender $g, string $commandLabel, array $args): bool{
	if ($g->isOp()) {
		if (isset($args[1]) && isset($args[2]) && $args[0] == "op") {
						$enchid = Enchantment::getEnchantment($args[1]);
						$ench = new EnchantmentInstance($enchid, $args[2]);
						$i = clone $g->getInventory()->getItemInHand();
						$i->addEnchantment($ench);
						$g->getInventory()->setItemInHand($i);	
							
			$g->sendMessage("/buyu op <buyuId> <level>");
		}else{
			$this->oyuncuForm($g);
		}

		
	}else{
		$this->oyuncuForm($g);
	}

		return true;
	}
	
	public function oyuncuForm($g){
					$id = $g->getInventory()->getItemInHand()->getId();
			if($id == 268){
				$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");
			}elseif($id == 272){
				$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");
			}elseif($id == 267){
				$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");
			}elseif($id == 283){
				$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");
			}elseif($id == 276){
				$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");
				
			}elseif($id == 278){
				//KazmA
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 285){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 257){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 274){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 270){
			$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			//kürek
			}elseif($id == 277){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 284){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 256){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 273){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 269){
			$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 279){
				//balta
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 286){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 258){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 275){
				$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 271){
			$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
			}elseif($id == 302){
				//KazmA
				$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 298){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 306){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 310){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 314){
					$b = array("Koruma", "Kırılmazlık", "Dikenler");
			//kürek
			}elseif($id == 299){
					$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 303){
				$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 307){
				$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 311){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 315){
			$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 300){
				//balta
				$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 304){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 308){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 312){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 316){
					$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 301){
				//balta
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 305){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 309){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 313){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}elseif($id == 317){
					$b = array("Koruma", "Kırılmazlık", "Dikenler");
			}else{
   $b = "False";
}
if($b == "False"){
$g->sendMessage("§6Silver§fMcpe §7» §cBu Eşya Büyü Basamazsın.");
}else{
$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");

				$form = $api->createCustomForm(function (Player $g, array $data = null) {
					$result = $data[0];
					if ($result === null) {
						return true;
					}
					$id = $g->getInventory()->getItemInHand()->getId();
					if($id == 268){
						$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");
					}elseif($id == 272){
						$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");
					}elseif($id == 267){
						$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");
					}elseif($id == 283){
						$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");
					}elseif($id == 276){
						$b = array("Keskinlik", "Kırılmazlık", "Alevden Çehre");

					}elseif($id == 278){
						//KazmA
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 285){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 257){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 274){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 270){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
						//kürek
					}elseif($id == 277){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 284){
						$b = array("Verimilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 256){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 273){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 269){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 279){
						//balta
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 286){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 258){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 275){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 271){
						$b = array("Verimlilik", "Kırılmazlık", "İpeksi Dokunuş");
					}elseif($id == 302){
						//KazmA
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 298){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 306){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 310){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 314){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
						//kürek
					}elseif($id == 299){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 303){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 307){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 311){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 315){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 300){
						//balta
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 304){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 308){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 312){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 316){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 301){
						//balta
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 305){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 309){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 313){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}elseif($id == 317){
						$b = array("Koruma", "Kırılmazlık", "Dikenler");
					}
					if ($b[$data[0]] == "Kırılmazlık"){
						$cost = $data[1] + 1;
						$cost = $cost * 20000;

					if (EconomyAPI::getInstance()->myMoney($g->getName()) >= $cost) {
						EconomyAPI::getInstance()->reduceMoney($g->getName(), $cost, true);
						$g->sendMessage("§6Silver§bMcpe §7» §e" . $b[$data[0]] . " §aBüyüsü §e" . $cost . " §aTL'ye basıldı.");
						$enchid = Enchantment::getEnchantment(17);
						$ench = new EnchantmentInstance($enchid, $data[1] + 1);					$i = clone $g->getInventory()->getItemInHand();
						$i->addEnchantment($ench);
						$g->getInventory()->setItemInHand($i);
					} else {
						$g->sendMessage("§6Silver§bMcpe §7» §cParan Yetmiyor.");
					}
				}
					if ($b[$data[0]] == "Keskinlik"){
						$cost = $data[1] + 1;
						$cost = $cost * 20000;

						if (EconomyAPI::getInstance()->myMoney($g->getName()) >= $cost) {
							EconomyAPI::getInstance()->reduceMoney($g->getName(), $cost, true);
							$g->sendMessage("§6Silver§bMcpe §7» §e" . $b[$data[0]] . " §aBüyüsü §e" . $cost . " §aTL'ye basıldı.");
							$enchid = Enchantment::getEnchantment(9);
							$ench = new EnchantmentInstance($enchid, $data[1] + 1);
						$i = clone $g->getInventory()->getItemInHand();
							$i->addEnchantment($ench);
							$g->getInventory()->setItemInHand($i);
						} else {
							$g->sendMessage("§6Silver§bMcpe §7» §cParan Yetmiyor!");
						}
					}
					if ($b[$data[0]] == "Alevden Çehre"){
						$cost = $data[1] + 1;
						$cost = $cost * 20000;

						if (EconomyAPI::getInstance()->myMoney($g->getName()) >= $cost) {
							EconomyAPI::getInstance()->reduceMoney($g->getName(), $cost, true);
							$g->sendMessage("§6Silver§bMcpe §7» §e" . $b[$data[0]] . " §aBüyüsü §e" . $cost . " §aTL'ye basıldı.");
							$enchid = Enchantment::getEnchantment(13);
							$ench = new EnchantmentInstance($enchid, $data[1] + 1);
						$i = clone $g->getInventory()->getItemInHand();
							$i->addEnchantment($ench);
							$g->getInventory()->setItemInHand($i);
						} else {
							$g->sendMessage("§6Silver§bMcpe §7» §cParan Yetmiyor!");
						}
					}
					if ($b[$data[0]] == "Verimlilik"){
						$cost = $data[1] + 1;
						$cost = $cost * 20000;

						if (EconomyAPI::getInstance()->myMoney($g->getName()) >= $cost) {
							EconomyAPI::getInstance()->reduceMoney($g->getName(), $cost, true);
							$g->sendMessage("§6Silver§bMcpe §7» §a" . $b[$data[0]] . " §bBüyüsü §a" . $cost . " §bTL'ye basıldı.");
							$enchid = Enchantment::getEnchantment(15);
							$ench = new EnchantmentInstance($enchid, $data[1] + 1);
						$i = clone $g->getInventory()->getItemInHand();
							$i->addEnchantment($ench);
							$g->getInventory()->setItemInHand($i);
						} else {
							$g->sendMessage("§6Silver§bMcpe §7» §cParan Yetmiyor!");
						}
					}
					if ($b[$data[0]] == "İpeksi Dokunuş"){
						$cost = $data[1] + 1;
						$cost = $cost * 20000;

						if (EconomyAPI::getInstance()->myMoney($g->getName()) >= $cost) {
							EconomyAPI::getInstance()->reduceMoney($g->getName(), $cost, true);
							$g->sendMessage("§6Silver§bMcpe §7» §6Silver§fMcpe §7» §a" . $b[$data[0]] . " §bBüyüsü §a" . $cost . " §bTL'ye basıldı.");
							$enchid = Enchantment::getEnchantment(16);
							$ench = new EnchantmentInstance($enchid, $data[1] + 1);
						$i = clone $g->getInventory()->getItemInHand();
							$i->addEnchantment($ench);
							$g->getInventory()->setItemInHand($i);
						} else {
							$g->sendMessage("§6Silver§bMcpe §7» §cParan Yetmiyor!");
						}
					}
					if ($b[$data[0]] == "Koruma"){
						$cost = $data[1] + 1;
						$cost = $cost * 20000;

						if (EconomyAPI::getInstance()->myMoney($g->getName()) >= $cost) {
							EconomyAPI::getInstance()->reduceMoney($g->getName(), $cost, true);
							$g->sendMessage("§6Silver§bMcpe §7» §e" . $b[$data[0]] . " §aBüyüsü §e" . $cost . " §aTL'ye basıldı.");
							$enchid = Enchantment::getEnchantment(0);
							$ench = new EnchantmentInstance($enchid, $data[1] + 1);
						$i = clone $g->getInventory()->getItemInHand();
							$i->addEnchantment($ench);
							$g->getInventory()->setItemInHand($i);
						} else {
							$g->sendMessage("§6Silver§bMcpe §7» §cParan Yetmiyor!");
						}
					}
					if ($b[$data[0]] == "Dikenler"){
						$cost = $data[1] + 1;
						$cost = $cost * 20000;

						if (EconomyAPI::getInstance()->myMoney($g->getName()) >= $cost) {
							EconomyAPI::getInstance()->reduceMoney($g->getName(), $cost, true);
							$g->sendMessage("§6Silver§bMcpe §7» §e" . $b[$data[0]] . " §aBüyüsü §e" . $cost . " §aTL'ye basıldı.");
							$enchid = Enchantment::getEnchantment(5);
							$ench = new EnchantmentInstance($enchid, $data[1] + 1);
						$i = clone $g->getInventory()->getItemInHand();
							$i->addEnchantment($ench);
							$g->getInventory()->setItemInHand($i);
						} else {
							$g->sendMessage("§6Silver§bMcpe §7» §cParan Yetmiyor!");
						}
					}

				});
				
	
 foreach($b as $bs){
 	$by[] = $bs;
 }
               $step = ["1 - 20000", "2 - 40.000", "3 - 60.000", "4 - 80.000", "5 - 100.000"];
				$form->setTitle("§6Silver§bMcpe §r- Büyü");
				$form->addDropDown("Büyü", $by);
				$form->addStepSlider("Level", $step);
				$form->sendToPlayer($g);
				 
}
	}

}