<?php

namespace SilverMCPE\Commands;

use DateTime;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;
use SilverMCPE\Main;

class Sorgu extends Command
{

    public function __construct()
    {
        parent::__construct("sorgu", "Sabıka kaydı sorgulamanızı sağlar");
        $this->setPermission("silver.cmd.sorgu");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$this->testPermission($sender)) return;
        if (empty($args[0])) return;
        $api = Main::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createCustomForm(function (Player $p, array $data = null) {
            $result = $data;
            if ($result === null) {
                return true;
            }
        });
        $this->kayit = new Config(Main::getInstance()->getDataFolder() . "kayit.yml", Config::YAML);
        $kyt = $this->kayit->get($args[0]);
        if (count($kyt) < 1){
            $sender->sendMessage("Oyuncu hiç bir ceza almamış");
            return true;
        }
        foreach ($kyt as $ky){
            $exp = explode(":", $ky);
            $date = new DateTime();
            $date->setTimestamp($exp[1]);
            $form->addLabel($exp[0]." (".$date->format('Y-m-d H:i:s') .")\n");
        }
        $form->sendToPlayer($sender);

    }
}