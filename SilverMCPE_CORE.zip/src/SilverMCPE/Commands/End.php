<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use korado531m7\InventoryMenuAPI\InventoryMenu;
use korado531m7\InventoryMenuAPI\InventoryType;
use korado531m7\InventoryMenuAPI\inventory\ChestInventory;
use korado531m7\InventoryMenuAPI\event\InventoryClickEvent;
use korado531m7\InventoryMenuAPI\inventory\DoubleChestInventory;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\Level;
use onebone\economyapi\EconomyAPI;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use SilverMCPE\Tasks\isinlanTask;

class End extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('end', $plugin);
		$this->setDescription('End Işınlanma');
		$this->plugin = $plugin;
	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool{
		$api = $this->plugin->getServer()->getPluginManager()->getPlugin("FormAPI");

				$form = $api->createModalForm(function (Player $p, $data) {
					$result = $data;
					if ($result === null) {
						return true;
					}
					switch ($result) {
						case 0:
						break;
						case 1:
							$this->plugin->getServer()->loadLevel("tend");


							$eco = $this->plugin->getServer()->getPluginManager()->getPlugin("EconomyAPI");
		if (EconomyAPI::getInstance()->myMoney($p->getName()) >= 7000) {
			$süre = 900;
	$this->plugin->getScheduler()->scheduleRepeatingTask($task = new isinlanTask($this->plugin, $p, "tend"), 20);
        $this->plugin->endId[$p->getName()] = $task->getTaskID();
        $this->plugin->endSüre[$p->getName()] = $süre;
									$dnya = $this->plugin->getServer()->getLevelByName("tend");
						$spawn = $dnya->getSafeSpawn();
						$p->teleport($spawn, 0, 0);
						$p->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));
						$eco->reduceMoney($p->getName(), 7000, true);
		}

					}
				});
				$form->setTitle("§6Silver§bMcpe §r- End");
				$form->setContent("§aEnd ışınlanmak istiyor musunuz?\n§aFiyat:§b 7000 §aTL\n§aSüre:§b 900§a Saniye");
				$form->setButton1("Işınlan");
				$form->setButton2("İptal");
				$form->sendToPlayer($p);

		


		return true;
	}
}