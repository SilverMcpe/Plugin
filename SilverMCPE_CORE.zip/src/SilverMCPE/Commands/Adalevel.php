<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\entity\{Zombie, Human, Entity};
use pocketmine\math\Vector3;
use pocketmine\item\Item;

class AdaLevel extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('adalevelim', $plugin);
		$this->setDescription('Ada Level');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
		$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $p->getName() . ".yml", Config::YAML);
		$apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

		$for = $apii->createCustomForm(function (Player $p, array $data = null) {
		$result = $data;
	if ($result === null) {
			return true;
		}

				

	});
    $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
    if($this->cfg->get("AIsim") != null){
        $this->cfg = new Config($this->main->getDataFolder() . $this->cfg->get("AIsim") . ".json", Config::JSON);
    }
   
		$for->setTitle("§6Silver§fMcpe §r- Ada Level");
        $for->addLabel("§aİsim:§b " . $this->cfg->get("AIsim") . "\n§aAda Levelin:§b " . $this->cfg->get("level") . "\n§aSıradaki xp:§b " .  $this->cfg->get("sxp")  . "\n§aMevcut xp:§b " .  $this->cfg->get("xp"));

		$for->sendToPlayer($p);
       

      return true;
	}



	}