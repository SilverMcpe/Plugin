<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
    Command,
    PluginCommand,
    ConsoleCommandSender,
    CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;

class Koruma extends PluginCommand{


    public function __construct($plugin){
        parent::__construct('koruma', $plugin);
        $this->setDescription('Koruma');
        $this->main = $plugin;

    }



    public function execute(CommandSender $p, string $commandLabel, array $args): bool
    {
                      if ($p->hasPermission("koruma.admin")){
       if(count($args) < 3){
           $p->sendMessage("/koruma <world> <touch|pvp> <aktif|false>");
           return false;
       }

       $cfg = new Config($this->main->getDataFolder(). "mapler.yml", Config::YAML);
       $cfg->set($args[0] . "-" . $args[1], $args[2]);
       $cfg->save();
       $p->sendMessage("Map ayarlandı.");
}else{
$p->sendMessage("Yetkin yok");

}
        return true;
    }



}