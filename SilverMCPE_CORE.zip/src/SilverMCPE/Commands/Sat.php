<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\item\Item;
use onebone\economyapi\EconomyAPI;

class Sat extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('sat', $plugin);
		$this->setDescription('Sat Menü');
		$this->main = $plugin;
	}


	public function execute(CommandSender $g, string $commandLabel, array $args): bool
	{
		      
            $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
            $form = $api->createSimpleForm(function (Player $g, int $args = null){
                $result = $args;
                if($result === null){

                    return true;
                }
                switch ($result) {
                    case 0:
                        $ap = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
                        $form = $ap->createSimpleForm(function (Player $g, int $args = null) {
                            $result = $args;
                            if ($result === null) {
                                return true;
                            }
                            switch ($result) {
                                case 0:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 10;
                                            if ($inv->contains(Item::get(1, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(1, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Taş ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 1) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 10;
                                    
                                    $for->setTitle("§6Silver§bMcpe §7- §rTaş");
									$for->addLabel("§eSatıcağın Eşya: §fTaş\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eTaş var\n\n§eFiyatı: §f" . $fiy);
									$for->addSlider("Miktar", 0, $count);
                                    $for->sendToPlayer($g);
                                    break;
                                case 1:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(4, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(4, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Kırıktaş ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 4) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§bMcpe §7- §rKırıktaş");
									$for->addLabel("§eSatıcağın Eşya: §fKırıktaş\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKırıktaş var\n\n§eFiyatı: §f" . $fiy);
									 $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 2:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 10;
                                            if ($inv->contains(Item::get(2, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(2, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Çimen ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 2) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 10;

                                    $for->setTitle("§6Silver§bMcpe §7- §rÇimen");
									$for->addLabel("§eSatıcağın Eşya: §fÇimen\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eÇimen var\n\n§eFiyatı: §f" . $fiy);
									 $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 3:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 7;
                                            if ($inv->contains(Item::get(3, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(3, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Toprak ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 3) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 7;

                                    $for->setTitle("§6Silver§bMcpe §7- §rToprak");
									$for->addLabel("§eSatıcağın Eşya: §fToprak\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eToprak var\n\n§eFiyatı: §f" . $fiy);
									 $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 4:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 8;
                                            if ($inv->contains(Item::get(17, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(17, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Meşe Odunu ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 17) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 8;

                                   $for->setTitle("§6Silver§bMcpe §7- §rMeşe Kütüğü");
									$for->addLabel("§eSatıcağın Eşya: §fMeşe Kütüğü\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eOdun var\n\n§eFiyatı: §f" . $fiy);
									 $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 5:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 8;
                                            if ($inv->contains(Item::get(17, 1, $data[1]))) {
                                                $inv->removeItem(Item::get(17, 1, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Çam Odunu ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if($item->getId() == 17 && $item->getDamage() == 1){
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 8;

                                   $for->setTitle("§6Silver§bMcpe §7- §rÇam Kütüğü");
									$for->addLabel("§eSatıcağın Eşya: §fÇam Kütüğü\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eOdun var\n\n§eFiyatı: §f" . $fiy);
									 $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 6:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 8;
                                            if ($inv->contains(Item::get(17, 2, $data[1]))) {
                                                $inv->removeItem(Item::get(17, 2, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Huş Odunu ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if($item->getId() == 17 && $item->getDamage() == 2){
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 8;

                                   $for->setTitle("§6Silver§bMcpe §7- §rHuş");
									$for->addLabel("§eSatıcağın Eşya: §fHuş Kütüğü\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eOdun var\n\n§eFiyatı: §f" . $fiy);
									 $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 7:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 8;
                                            if ($inv->contains(Item::get(162, 1, $data[1]))) {
                                                $inv->removeItem(Item::get(162, 1, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Koyu Meşe Odun ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if($item->getId() == 162 && $item->getDamage() == 1){
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 8;

                                   $for->setTitle("§6Silver§bMcpe §7- §rKoyu Meşe Kütüğü");
									$for->addLabel("§eSatıcağın Eşya: §fKoyu Meşe Kütüğü\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eOdun var\n\n§eFiyatı: §f" . $fiy);
									 $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 8:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 10;
                                            if ($inv->contains(Item::get(12, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(12, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Kum ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 12) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 10;

                                    $for->setTitle("§6Silver§bMcpe §7- §rKum");
									$for->addLabel("§eSatıcağın Eşya: §fKum\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKum var\n\n§eFiyatı: §f" . $fiy);
									 $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 9:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(20, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(20, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Cam ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 20) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§bMcpe §7- §rCam");
									$for->addLabel("§eSatıcağın Eşya: §fCam\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eCam var\n\n§\neFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                            }

                        });
                	$form->setTitle("§6Silver§bMcpe §7- §rBloklar");
						$form->setContent("§eSatmak istediğin eşyayı seçin.");
						$form->addButton("Taş - 10 TL", 0 ,"textures/blocks/stone");
						$form->addButton("Kırıktaş - 5 TL", 0 ,"textures/blocks/cobblestone");
						$form->addButton("Çimen - 10 TL", 0 ,"textures/blocks/grass_side_carried");
						$form->addButton("Toprak - 7 TL", 0 ,"textures/blocks/dirt");
						$form->addButton("Meşe Kütüğü - 8 TL", 0 ,"textures/blocks/log_oak");
						$form->addButton("Çam Kütüğü - 8 TL", 0 ,"textures/blocks/log_spruce");
						$form->addButton("Huş Kütüğü - 8 TL", 0 ,"textures/blocks/log_birch");
						$form->addButton("Koyu Meşe Kütüğü - 8 TL", 0 ,"textures/blocks/dark_oak_log");
						$form->addButton("Kum - 10 TL", 0 ,"textures/blocks/sand");
						$form->addButton("Cam - 5 TL", 0 ,"textures/blocks/glass");

                        $form->sendToPlayer($g);
                        break;
                    case 1:
                        $ap = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
                        $form = $ap->createSimpleForm(function (Player $g, int $args = null) {
                            $result = $args;
                            if ($result === null) {
                                return true;
                            }
                            switch ($result) {
                                case 0:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 7;
                                            if ($inv->contains(Item::get(296, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(296, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Buğday ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 296) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 7;

                                    $for->setTitle("§6Silver§bMcpe §7- §rBuğday");
									$for->addLabel("§eSatıcağın Eşya: §fBuğday\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eBuğday var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 1:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 12;
                                            if ($inv->contains(Item::get(391, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(391, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Havuç ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 391) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 12;

                                    $for->setTitle("§6Silver§bMcpe §7- §rHavuç");
									$for->addLabel("§eSatıcağın Eşya: §fHavuç\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eHavuç var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 2:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 12;
                                            if ($inv->contains(Item::get(391, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(391, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Patates ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 391) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 12;

                                    $for->setTitle("§6Silver§bMcpe §7- §rPatates");
									$for->addLabel("§eSatıcağın Eşya: §fPatates\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §ePatates var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 3:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 15;
                                            if ($inv->contains(Item::get(457, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(457, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Pancar ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 457) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 15;

                                    $for->setTitle("§6Silver§bMcpe §7- §rPancar");
									$for->addLabel("§eSatıcağın Eşya: §fPancar\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §ePancar var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 4:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 25;
                                            if ($inv->contains(Item::get(86, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(86, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Balkabağı ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 86) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 25;

                                    $for->setTitle("§6Silver§bMcpe §7- §rBalkabağı");
									$for->addLabel("§eSatıcağın Eşya: §fBalkabağı\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eBalkabağı var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 5:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(360, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(360, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Karpuz ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 360) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§bMcpe §7- §Karpuz");
									$for->addLabel("§eSatıcağın Eşya: §fKarpuz\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKarpuz var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 6:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 10;
                                            if ($inv->contains(Item::get(338, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(338, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Seker Kamışı ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 338) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 10;

                                    $for->setTitle("§6Silver§bMcpe §7- §rSeker Kamışı");
									$for->addLabel("§eSatıcağın Eşya: §fSeker Kamışı\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eSeker Kamışı var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 7:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 7;
                                            if ($inv->contains(Item::get(81, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(81, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Kaktüs ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 81) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 7;

                                    $for->setTitle("§6Silver§bMcpe §7- §rKaktüs");
									$for->addLabel("§eSatıcağın Eşya: §fKaktüs \n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKaktüs var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 8:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 10;
                                            if ($inv->contains(Item::get(372, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(372, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Nether Wart ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 372) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 10;

                                    $for->setTitle("§6Silver§bMcpe §7- §rNether Wart");
									$for->addLabel("§eSatıcağın Eşya: §fNether Wart \n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eNether Wart var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 9:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 30;
                                            if ($inv->contains(Item::get(103, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(103, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Karpuz Blok ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 103) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 30;

                                    $for->setTitle("§6Silver§bMcpe §7- §rKarpuz Blok");
									$for->addLabel("§eSatıcağın Eşya: §fKarpuz Blok \n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKarpuz Blok var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;

                            }

                        });
						$form->setTitle("§6Silver§bMcpe §7- §rTarımlar");
						$form->setContent("§eSatmak istediğin eşyayı seçin.");
						$form->addButton("Buğday - 7 TL", 0 ,"textures/items/wheat");
						$form->addButton("Havuç - 12 TL", 0 ,"textures/items/carrot");
						$form->addButton("Patates - 12 TL", 0 ,"textures/items/potato");
						$form->addButton("Pancar - 15 TL", 0 ,"textures/items/beetroot");
						$form->addButton("Balkabağı - 25 TL", 0 ,"textures/blocks/pumpkin_face_off");
						$form->addButton("Karpuz Dilimi - 5 TL", 0 ,"textures/items/melon");
						$form->addButton("Seker Kamışı - 10 TL", 0 ,"textures/items/reeds");
						$form->addButton("Kaktüs - 7 TL", 0 ,"textures/blocks/cactus_side");
						$form->addButton("Nether Wart - 10 TL", 0 ,"textures/items/nether_wart");
						$form->addButton("Karpuz Blok - 30 TL", 0 ,"textures/blocks/melon_side");


                        $form->sendToPlayer($g);

                        break;
                    case 2:
                        $this->madenler($g);
                        break;
                    case 3:
                        $ap = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
                        $form = $ap->createSimpleForm(function (Player $g, int $args = null) {
                            $result = $args;
                            if ($result === null) {
                                return true;
                            }
                            switch ($result) {                               
                                case 0:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 25;
                                            if ($inv->contains(Item::get(460, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(460, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§7»§a Somon Balığı ". $fiyat ." TL satıldı !");
                                            } else {
                                                $g->sendMessage("§7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 460) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 25;

                                    $for->setTitle("§6Silver§bMcpe §7- §rSomon Balığı");
									$for->addLabel("§eSatıcağın Eşya: §fSomon Balığı\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eSomon Balığı var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 1:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 25;
                                            if ($inv->contains(Item::get(349, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(349, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§7»§a Morina Balığı ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 349) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 25;

                                    $for->setTitle("§6Silver§bMcpe §7- §rMorina Balığı");
									$for->addLabel("§eSatıcağın Eşya: §fMorina Balığı\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eMorina Balığı var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 2:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 25;
                                            if ($inv->contains(Item::get(462, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(462, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§7»§a Kirpi Balığı ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 462) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 25;

                                    $for->setTitle("§6Silver§bMcpe §7- §rKirpi Balığı");
									$for->addLabel("§eSatıcağın Eşya: §fKirpi Balığı\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKirpi Balığı var\n\n§eFiyatı: §f" . $fiy);									 $for->addSlider("Miktar", 0, $count);
                                

                                    $for->sendToPlayer($g);
                                    break;
                                case 3:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 25;
                                            if ($inv->contains(Item::get(461, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(461, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§7»§a Tropical Balığı ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 461) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 25;

                                    $for->setTitle("§6Silver§bMcpe §7- §rTropical Balığı");
									$for->addLabel("§eSatıcağın Eşya: §fTropical Balığı\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eTropical Balığı var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
 
                            }

                        });
                        $form->setTitle("§6Silver§fMcpe §7- §rBalıklar");
						$form->setContent("§eSatmak istediğin eşyayı seçin.");
						$form->addButton("Somon Balığı - 25 TL", 0 ,"textures/items/fish_salmon_raw");
						$form->addButton("Morina Balığı - 25 TL", 0 ,"textures/items/fish_raw");
						$form->addButton("Kirpi Balığı - 25 TL", 0 ,"textures/items/fish_pufferfish_raw");
						$form->addButton("Tropical Balığı - 25 TL", 0 ,"textures/items/fish_clownfish_raw");
						

                        $form->sendToPlayer($g);
                        break;
                        case 4:
                        $ap = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
                        $form = $ap->createSimpleForm(function (Player $g, int $args = null) {
                            $result = $args;
                            if ($result === null) {
                                return true;
                            }
                            switch ($result) { 
                            	case 0:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(334, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(334, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Deri ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 334) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§fMcpe §7- §rDeri");
									$for->addLabel("§eSatıcağın Eşya: §fDeri\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eDeri var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 1:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(288, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(288, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Tüy ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 288) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§fMcpe §7- §rTüy");
									$for->addLabel("§eSatıcağın Eşya: §fTüy\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eTüy var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 2:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(287, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(287, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Ip ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 287) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§fMcpe §7- §rIp");
									$for->addLabel("§eSatıcağın Eşya: §fIp\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eIp var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 3:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(375, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(375, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Örümcek Gözü ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 375) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§fMcpe §7- §rÖrümcek Gözü");
									$for->addLabel("§eSatıcağın Eşya: §fÖrümcek Gözü\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eÖrümcek Gözü var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 4:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(352, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(352, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Kemik ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 352) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§fMcpe §7- §rKemik");
									$for->addLabel("§eSatıcağın Eşya: §fKemik\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKemik var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 5:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 3;
                                            if ($inv->contains(Item::get(262, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(262, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Ok ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 262) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 3;

                                    $for->setTitle("§6Silver§fMcpe §7- §rOk");
									$for->addLabel("§eSatıcağın Eşya: §fOk\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eOk var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 6:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(369, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(369, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Alaz Çubuğu ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 369) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§fMcpe §7- §rAlaz Çubuğu");
									$for->addLabel("§eSatıcağın Eşya: §fAlaz Çubuğu\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eAlaz Çubuğu var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 7:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(367, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(367, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Çürük Et ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 367) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§fMcpe §7- §rÇürük Et");
									$for->addLabel("§eSatıcağın Eşya: §fÇürük Et\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eÇürük Et var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 8:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 5;
                                            if ($inv->contains(Item::get(289, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(289, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Barut ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 289) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 5;

                                    $for->setTitle("§6Silver§fMcpe §7- §rBarut");
									$for->addLabel("§eSatıcağın Eşya: §fBarut\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eBarut var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                            }

                        });
						$form->setTitle("§6Silver§fMcpe §7- §rMoblar");
						$form->setContent("§eSatmak istediğin eşyayı seçin.");
						$form->addButton("Deri - 5 TL", 0 ,"textures/items/leather");
						$form->addButton("Tüy - 5 TL", 0 ,"textures/items/feather");
						$form->addButton("Ip - 5 TL", 0 ,"textures/items/string");
						$form->addButton("Örümcek Gözü - 5 TL", 0 ,"textures/items/spider_eye");
						$form->addButton("Kemik - 5 TL", 0 ,"textures/items/bone");
						$form->addButton("Ok - 3 TL", 0 ,"textures/items/arrow");
						$form->addButton("Alaz Çubuğu - 5 TL", 0 ,"textures/items/blaze_rod");
						$form->addButton("Çürük Et - 5 TL", 0 ,"textures/items/rotten_flesh");
						$form->addButton("Barut - 5 TL", 0 ,"textures/items/gunpowder");
                        $form->sendToPlayer($g);
                        break;
                }
        });
		$form->setTitle("§6Silver§bMcpe §7- §rHızlı Sat");
		$form->setContent("§eSatmak istediğiniz eşyanın menüsüne gidebilirsin !");
        $form->addButton("Blocklar", 0 ,"textures/blocks/stone");
		$form->addButton("Tarımlar", 0 ,"textures/items/wheat");
		$form->addButton("Madenler", 0 ,"textures/items/diamond");
        $form->addButton("Balıklar", 0 ,"textures/items/fish_raw");
        $form->addButton("Moblar", 0 ,"textures/items/gunpowder");
        $form->sendToPlayer($g);

       
return true;
}
public function madenler($g){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $g, int $data = null){
            if($data === null){
                return true;
            }
            switch($data){
                case 0:
                        $ap = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
                        $form = $ap->createSimpleForm(function (Player $g, int $args = null) {
                            $result = $args;
                            if ($result === null) {
                                return true;
                            }
                            switch ($result) {                               
                                case 0:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 40;
                                            if ($inv->contains(Item::get(263, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(263, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Kömür ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 263) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 40;

                                    $for->setTitle("§6Silver§fMcpe §7- §rKömür");
									$for->addLabel("§eSatıcağın Eşya: §fKömür\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKömür var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 1:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 75;
                                            if ($inv->contains(Item::get(265, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(265, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Demir ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 265) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 75;

                                    $for->setTitle("§6Silver§fMcpe §7- §rDemir");
									$for->addLabel("§eSatıcağın Eşya: §fDemir\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eDemir var\n\n§eFiyatı: §f" . $fiy);

                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 2:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 85;
                                            if ($inv->contains(Item::get(266, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(266, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Altın ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 266) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 85;

                                    $for->setTitle("§6Silver§fMcpe §7- §rAltın");
									$for->addLabel("§eSatıcağın Eşya: §fAltın\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eAltın var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                      case 3:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 10;
                                            if ($inv->contains(Item::get(331, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(331, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Kızıltaş ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 331) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 10;

                                    $for->setTitle("§6Silver§fMcpe §7- §rKızıltaş");
                                    $for->addLabel("§eSatıcağın Eşya: §fKızıltaş\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKızıltaş var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 4:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 150;
                                            if ($inv->contains(Item::get(264, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(264, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Elmas ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 264) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 150;

                                    $for->setTitle("§6Silver§fMcpe §7- §rElmas");
                                    $for->addLabel("§eSatıcağın Eşya: §fElmas\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eElmas var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 5:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 175;
                                            if ($inv->contains(Item::get(388, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(388, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Zümrüt ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 388) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 175.;

                                    $for->setTitle("§6Silver§fMcpe §7- §rZümrüt");
									$for->addLabel("§eSatıcağın Eşya: §fZümrüt\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eZümrüt var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 6:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 10;
                                            if ($inv->contains(Item::get(351, 4, $data[1]))) {
                                                $inv->removeItem(Item::get(351, 4, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Lapis ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if($item->getId() == 351 && $item->getDamage() == 4){
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 10;

                                    $for->setTitle("§6Silver§fMcpe §7- §rLapis");
									$for->addLabel("§eSatıcağın Eşya: §fLapis\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eLapis var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    

                            }

                        });
						$form->setTitle("§6Silver§fMcpe §7- §rMaden Cevheri");
						$form->setContent("§eSatmak istediğin eşyayı seçin.");
						$form->addButton("Kömür - 40 TL", 0 ,"textures/items/coal");
						$form->addButton("Demir - 75 TL", 0 ,"textures/items/iron_ingot");
						$form->addButton("Altın - 85 TL", 0 ,"textures/items/gold_ingot");
						$form->addButton("Kızıltaş - 10 TL", 0 ,"textures/items/redstone_dust");
						$form->addButton("Elmas - 150 TL", 0 ,"textures/items/diamond");
						$form->addButton("Zümrüt - 175 TL", 0 ,"textures/items/emerald");
						$form->addButton("Lapis - 10 TL", 0 ,"textures/items/dye_powder_blue");
                        $form->sendToPlayer($g);
                        
                        break;
                        case 1:
                        $ap = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
                        $form = $ap->createSimpleForm(function (Player $g, int $args = null) {
                            $result = $args;
                            if ($result === null) {
                                return true;
                            }
                            switch ($result) {                               
                                case 0:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 360;
                                            if ($inv->contains(Item::get(173, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(173, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Kömür Blok ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 173) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 360;

                                    $for->setTitle("§6Silver§fMcpe §7- §rKömür Blok");
									$for->addLabel("§eSatıcağın Eşya: §fKömür Blok\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKömür Blok var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 1:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 675;
                                            if ($inv->contains(Item::get(42, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(42, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Demir Blok". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 42) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 675;

                                    $for->setTitle("§6Silver§fMcpe §7- §rDemir Blok");
									$for->addLabel("§eSatıcağın Eşya: §fDemir Blok \n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eDemir Blok var\n\n§eFiyatı: §f" . $fiy);

                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 2:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 765;
                                            if ($inv->contains(Item::get(41, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(41, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Altın Blok ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 41) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 765;

                                    $for->setTitle("§6Silver§fMcpe §7- §rAltın Blok");
									$for->addLabel("§eSatıcağın Eşya: §fAltın Blok\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eAltın Blok var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                      case 3:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 90;
                                            if ($inv->contains(Item::get(152, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(152, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Kızıltaş Blok". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 152) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 90;

                                    $for->setTitle("§6Silver§fMcpe §7- §rKızıltaş Blok");
                                    $for->addLabel("§eSatıcağın Eşya: §fKızıltaş Blok\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eKızıltaş Blok var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 4:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 1350;
                                            if ($inv->contains(Item::get(57, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(57, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Elmas Blok ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 57) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 1350;

                                    $for->setTitle("§6Silver§fMcpe §7- §rElmas Blok");
                                    $for->addLabel("§eSatıcağın Eşya: §fElmas Blok\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eElmas Blok var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                case 5:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 1575;
                                            if ($inv->contains(Item::get(133, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(133, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Zümrüt Blok". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if ($item->getId() == 133) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 1575.;

                                    $for->setTitle("§6Silver§fMcpe §7- §rZümrüt Blok");
									$for->addLabel("§eSatıcağın Eşya: §fZümrüt Blok\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eZümrüt Blok var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                                    case 6:

                                    $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                                    $for = $apii->createCustomForm(function (Player $g, array $data = null) {
                                        $result = $data;
                                        if ($result === null) {
                                            return true;
                                        }
                                        if (is_numeric($data[1])) {
                                            $inv = $g->getInventory();

                                            $fiyat = $data[1] * 90;
                                            if ($inv->contains(Item::get(22, 0, $data[1]))) {
                                                $inv->removeItem(Item::get(22, 0, $data[1]));
                                                EconomyAPI::getInstance()->addMoney($g->getName(), $fiyat, true);
                                                $g->sendMessage("§6Silver§fMcpe §7»§a Lapis Blok ". $fiyat ." TL satıldı !");
                                            } else {
                                                 $g->sendMessage("§6Silver§fMcpe §7» §cYeterince eşyan bulunmuyor!");
                                            }

                                        } else {
                                            $g->sendMessage("§6Silver§fMcpe §7» §cLütfen Sayı girin");
                                        }


                                    });
                                    $inv = $g->getInventory();
                                    $count = 0;
                                    $all = $inv->getContents();
                                    foreach ($all as $item) {
                                        if($item->getId() == 22) {
                                            $count = $count + $item->getCount();
                                        }
                                    }
                                    $fiy = 90;

                                    $for->setTitle("§6Silver§fMcpe §7- §rLapis Blok");
									$for->addLabel("§eSatıcağın Eşya: §fLapis Blok\n\n§eSatmak isteğin eşya üzerinde şu kadar var§f " . $count . " §eLapis Blok var\n\n§eFiyatı: §f" . $fiy);
                                     $for->addSlider("Miktar", 0, $count);

                                    $for->sendToPlayer($g);
                                    break;
                     
 
                            }

                        });
                        $form->setTitle("§6Silver§fMcpe §7- §rMaden Blokları");
						$form->setContent("§eSatmak istediğin eşyayı seçin.");
						$form->addButton("Kömür Block - 360 TL", 0 ,"textures/blocks/coal_block");
						$form->addButton("Demir Block - 675 TL", 0 ,"textures/blocks/iron_block");
						$form->addButton("Altın Block - 765 TL", 0 ,"textures/blocks/gold_block");
						$form->addButton("Kızıltaş Block - 90 TL", 0 ,"textures/blocks/redstone_block");
						$form->addButton("Elmas Block - 1350 TL", 0 ,"textures/blocks/diamond_block");
						$form->addButton("Zümrüt Block - 1575 TL", 0 ,"textures/blocks/emerald_block");
						$form->addButton("Lapis Block - 90 TL", 0 ,"textures/blocks/lapis_block");

                        $form->sendToPlayer($g);
                        break;
                }
        });

        $form->setTitle("§6Silver§fMcpe §7- §rMadenler");
        $form->addButton("Maden Cevherleri", 0 ,"textures/items/diamond");
        $form->addButton("Maden Blokları", 0 ,"textures/blocks/diamond_block");
        $form->sendToPlayer($g);
        return true;
    }
    }