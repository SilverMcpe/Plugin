<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use DateTime;
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;

class Panel extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('panel', $plugin);
		$this->setPermission("admin.command");
		$this->setDescription('Yetkili panel.');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
		if($p->hasPermission("yetkili")){
			$this->yetkiliPanel($p);
		}

		return true;
	}

	public function aktifPanel($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $p, int $data = null){
			if($data === null){
				return true;
			}
			switch($data){
				case 0:
				$this->aktifBan($p);
				break;
				case 1:
				$this->aktifSBan($p);
				break;
				case 2:
				$this->aktifKick($p);
				break;
				case 3:
				$this->aktifMute($p);

				break;
				case 4:
				$this->aktifSMute($p);
				break;
				case 5:
				$this->aktifIpBan($p);
				break;
				case 6:
				$this->aktifUyarı($p);
				break;


			}

		});
		$form->setTitle("Panel");
		$form->addButton("Ban");
		$form->addButton("Süreli Ban");
		$form->addButton("Kick");
		$form->addButton("Mute");
		$form->addButton("Süreli Mute");
		$form->addButton("İp-Ban");
		$form->addButton("Uyarı");


		$form->sendToPlayer($p);
	}

	public function offPanel($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $p, int $data = null){
			if($data === null){
				return true;
			}
			switch($data){
				case 0:
				$this->offBan($p);
				break;
				case 1:
				$this->offSBan($p);
				break;
				case 2:
				$this->offMute($p);
				break;
				case 3:
				$this->offUyarı($p);

				break;

			}

		});
		$form->setTitle("Panel");
		$form->addButton("Ban");
		$form->addButton("Süreli Ban");
		$form->addButton("Mute");
		$form->addButton("Uyarı");


		$form->sendToPlayer($p);
	}




	public function offUyarı($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			if($data === null){
				return true;
			}

			$this->banl = new Config($this->main->getDataFolder() . "uyarılist.yml", Config::YAML);
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($data[0]);
            if (is_array($kyt)){
                $kyt[] = $data[1]." Uyarı puanı. \n{$data[2]}:".time();
            }else{
                $kyt = [];
                $kyt[] = $data[1]." Uyarı puanı. \n{$data[2]}:".time();
            }
            $this->kayit->set($data[0], $kyt);
            $this->kayit->save();
            $uy = $this->banl->get($data[0]);
			$uy = $uy + $data[1];
			$this->banl->set($data[0]);
			$this->banl->save();
			if($uy >= 10){
				$this->banl = new Config($this->main->getDataFolder() . "banlist.yml", Config::YAML);
				$bans = $this->banl->get("Ban");
				$bans[] = $data[0];
				$this->banl->set("Ban", $bans);
				$this->banl->save();
				$this->main->getServer()->broadcastMessage($data[0] . "," . $p->getName() . " adlı  yetkili tarafından banlandı\nSebep: 10 Uyarı puanı" );
				return false;

			}
			$this->main->getServer()->broadcastMessage($data[0] . "," . $p->getName() . " adlı  yetkili tarafından " . $data[1] . " uyarı puanı yedi.\nSebep: " . $data[2]);






		});
		$form->setTitle("Uyarı");
		$form->addInput("Oyuncu", "örn: TalhaRST!");
		$form->addSlider("Uyarı", 1, 10);
		$form->addInput("Sebep", "örn: Hile Açtı!");
		$form->sendToPlayer($p);
	}

	public function offSBan($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			$result = $data[0];
			if($result === null){
				return true;
			}
			$now = time();
			$day = ($data[1] * 86400);
			$hour = ($data[2] * 3600);
			if($data[3] > 1){
				$min = ($data[3] * 60);
			} else {
				$min = 60;
			}
			$banTime = $now + $day + $hour + $min;
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($data[0]);
            $date = new DateTime();
            $date->setTimestamp($banTime);

            if (is_array($kyt)){
                $kyt[] = "Banlandı. Bitiş -> ".$date->format('Y-m-d H:i:s')." \n{$data[4]}:".time();
            }else{
                $kyt = [];
                $kyt[] = "Banlandı. Bitiş -> ".$date->format('Y-m-d H:i:s')." \n{$data[4]}:".time();
            }
            $this->kayit->set($data[0], $kyt);
            $this->kayit->save();
			$this->banl = new Config($this->main->getDataFolder() . "sbanlist.yml", Config::YAML);
			$this->banl->set($data[0], $banTime);
			$this->banl->save();
			$this->main->getServer()->broadcastMessage($data[0] . ", " . $p->getName() . " adlı  yetkili tarafından banlandı\n" . $data[1] . " Gün ". $data[2] . " Saat " . $data[3] . " Dakika" ."\nSebep:" . $data[4]);



			
		});
		$form->setTitle("Süreli Ban");
		$form->addInput("Oyuncu", "örn: TalhaRST!");
		$form->addSlider("Gün", 0, 30, 1);
		$form->addSlider("Saat", 0, 24, 1);
		$form->addSlider("Dakika", 0, 60, 5);
		$form->addInput("Sebep");
		$form->sendToPlayer($p);
	}

	public function offBan($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			if($data === null){
				return true;
			}
			$this->main->getServer()->broadcastMessage($data[0] . "," . $p->getName() . " adlı  yetkili tarafından banlandı\nSebep:" . $data[1]);
			$this->banl = new Config($this->main->getDataFolder() . "banlist.yml", Config::YAML);
			$bans = $this->banl->get("Ban");
			$bans[] = $data[0];
			$this->banl->set("Ban", $bans);
			$this->banl->save();
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($data[0]);


            if (is_array($kyt)){
                $kyt[] = "Banlandı. Sınırsız \n{$data[4]}:".time();
            }else{
                $kyt = [];
                $kyt[] = "Banlandı. Sınırsız \n{$data[4]}:".time();
            }
            $this->kayit->set($data[0], $kyt);
            $this->kayit->save();


		});
		$form->setTitle("Ban");
		$form->addInput("Oyuncu", "örn: TalhaRST!");
		$form->addInput("Sebep", "örn: Hile Açtı!");
		$form->sendToPlayer($p);
	}

	public function offMute($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			if($data === null){
				return true;
			}
			$this->main->getServer()->broadcastMessage($data[0] . "," . $p->getName() . " adlı  yetkili tarafından susturuldu\nSebep:" . $data[1]);
			$this->banl = new Config($this->main->getDataFolder() . "mutelist.yml", Config::YAML);
			$bans = $this->banl->get("Mute");
			$bans[] = $data[0];
			$this->banl->set("Mute", $bans);
			$this->banl->save();
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($data[0]);


            if (is_array($kyt)){
                $kyt[] = "Susturuldu. Sınırsız \n{$data[1]}:".time();
            }else{
                $kyt = [];
                $kyt[] = "Susturuldu. Sınırsız \n{$data[1]}:".time();
            }
            $this->kayit->set($data[0], $kyt);
            $this->kayit->save();


		});
		$form->setTitle("Mute");
		$form->addInput("Oyuncu", "örn: TalhaRST!");
		$form->addInput("Sebep", "örn: Hile Açtı!");
		$form->sendToPlayer($p);
	}




	public function aktifKick($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			if($data === null){
				return true;
			}
			$o = $this->getOnlinePlayers();
			$o = $o[$data[0]];
			$o = $this->main->getServer()->getPlayer($o);
			$this->main->getServer()->broadcastMessage($o->getName() . "," . $p->getName() . " adlı  yetkili tarafından atıldı\nSebep:" . $data[1]);
			$o->kick($p->getName() . " adlı  yetkili tarafından atıldın\nSebep:" . $data[1]);
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($o->getName());


            if (is_array($kyt)){
                $kyt[] = "Oyundan atıldı.\n{$data[1]}:".time();
            }else{
                $kyt = [];
                $kyt[] = "Oyundan atıldı. \n{$data[1]}:".time();
            }
            $this->kayit->set($o->getName(), $kyt);
            $this->kayit->save();




		});
		$form->setTitle("Kick");
		$form->addDropdown("Oyuncu", $this->getOnlinePlayers());
		$form->addInput("Sebep", "örn: Hile Açtı!");
		$form->sendToPlayer($p);
	}

	public function aktifBan($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			if($data === null){
				return true;
			}
			$o = $this->getOnlinePlayers();
			$o = $o[$data[0]];
			$o = $this->main->getServer()->getPlayer($o);
			$this->main->getServer()->broadcastMessage($o->getName() . "," . $p->getName() . " adlı  yetkili tarafından banlandı\nSebep:" . $data[1]);
			$o->kick($p->getName() . " adlı  yetkili tarafından banlandın\nSebep:" . $data[1]);
			$this->banl = new Config($this->main->getDataFolder() . "banlist.yml", Config::YAML);
			$bans = $this->banl->get("Ban");
			$bans[] = $o->getName();
			$this->banl->set("Ban", $bans);
			$this->banl->save();
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($o->getName());


            if (is_array($kyt)) {
                $kyt[] = "Banlandı. Sınırsız \n{$data[1]}:" . time();
            } else {
                $kyt = [];
                $kyt[] = "Banlandı. Sınırsız \n{$data[1]}:" . time();
            }
            $this->kayit->set($o->getName(), $kyt);
            $this->kayit->save();



		});
		$form->setTitle("Ban");
		$form->addDropdown("Oyuncu", $this->getOnlinePlayers());
		$form->addInput("Sebep", "örn: Hile Açtı!");
		$form->sendToPlayer($p);
	}

	public function aktifMute($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			if($data === null){
				return true;
			}
			$o = $this->getOnlinePlayers();
			$o = $o[$data[0]];
			$o = $this->main->getServer()->getPlayer($o);
			$this->main->getServer()->broadcastMessage($o->getName() . "," . $p->getName() . " adlı  yetkili tarafından susturuldu\nSebep:" . $data[1]);
			$this->banl = new Config($this->main->getDataFolder() . "mutelist.yml", Config::YAML);
			$bans = $this->banl->get("Mute");
			$bans[] = $o->getName();
			$this->banl->set("Mute", $bans);
			$this->banl->save();
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($o->getName());

            if (is_array($kyt)){
                $kyt[] = "Susturuldu. Sınırsız \n{$data[1]}:".time();
            }else{
                $kyt = [];
                $kyt[] = "Susturuldu. Sınırsız \n{$data[1]}:".time();
            }
            $this->kayit->set($o->getName(), $kyt);
            $this->kayit->save();



		});
		$form->setTitle("Mute");
		$form->addDropdown("Oyuncu", $this->getOnlinePlayers());
		$form->addInput("Sebep", "örn: Hile Açtı!");
		$form->sendToPlayer($p);
	}


	public function aktifUyarı($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			if($data === null){
				return true;
			}
			$o = $this->getOnlinePlayers();
			$o = $o[$data[0]];
			$o = $this->main->getServer()->getPlayer($o);
			$this->banl = new Config($this->main->getDataFolder() . "uyarılist.yml", Config::YAML);
			$uy = $this->banl->get($o->getName());
			$uy = $uy + $data[1];
			$this->banl->set($o->getName());
			$this->banl->save();
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($o->getName());
            if (is_array($kyt)){
                $kyt[] = $data[1]." Uyarı puanı. \n{$data[2]}:".time();
            }else{
                $kyt = [];
                $kyt[] = $data[1]." Uyarı puanı. \n{$data[2]}:".time();
            }
            $this->kayit->set($o->getName(), $kyt);
            $this->kayit->save();
			if($uy >= 10){
				$o->kick($p->getName() . " adlı  yetkili tarafından banlandın\nSebep: 10 Uyarı puanı");
				$this->banl = new Config($this->main->getDataFolder() . "banlist.yml", Config::YAML);
				$bans = $this->banl->get("Ban");
				$bans[] = $o->getName();
				$this->banl->set("Ban", $bans);
				$this->banl->save();
				$this->main->getServer()->broadcastMessage($o->getName() . "," . $p->getName() . " adlı  yetkili tarafından banlandı\nSebep: 10 Uyarı puanı" );
				return false;

			}
			$this->main->getServer()->broadcastMessage($o->getName() . "," . $p->getName() . " adlı  yetkili tarafından " . $data[1] . " uyarı puanı yedi.\nSebep: " . $data[2]);






		});
		$form->setTitle("Uyarı");
		$form->addDropdown("Oyuncu", $this->getOnlinePlayers());
		$form->addSlider("Uyarı", 1, 10);
		$form->addInput("Sebep", "örn: Hile Açtı!");
		$form->sendToPlayer($p);
	}


	public function aktifSMute($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			if($data === null){
				return true;
			}
			$o = $this->getOnlinePlayers();
			$o = $o[$data[0]];
			$o = $this->main->getServer()->getPlayer($o);
			$now = time();

			$min = ($data[1] * 60);

			$banTime = $now + $min;
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($o->getName());
            $date = new DateTime();
            $date->setTimestamp($banTime);

            if (is_array($kyt)){
                $kyt[] = "Susturuldu. Bitiş -> ".$date->format('Y-m-d H:i:s')." \n{$data[2]}:".time();
            }else{
                $kyt = [];
                $kyt[] = "Susturuldu. Bitiş -> ".$date->format('Y-m-d H:i:s')." \n{$data[2]}:".time();
            }
            $this->kayit->set($o->getName(), $kyt);
            $this->kayit->save();
			$this->banl = new Config($this->main->getDataFolder() . "smutelist.yml", Config::YAML);
			$this->banl->set($o->getName(), $banTime);
			$this->banl->save();
			$this->main->getServer()->broadcastMessage($o->getName() . "," . $p->getName() . " adlı  yetkili tarafından  susturuldu\n" . $data[1] . " Dakika"."\nSebep:" . $data[2]);





		});
		$form->setTitle("Mute");
		$form->addDropdown("Oyuncu", $this->getOnlinePlayers());
		$form->addSlider("Dakika", 1, 30);
		$form->addInput("Sebep", "örn: Hile Açtı!");
		$form->sendToPlayer($p);
	}

	public function aktifIpBan($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			if($data === null){
				return true;
			}
			$o = $this->getOnlinePlayers();
			$o = $o[$data[0]];
			$o = $this->main->getServer()->getPlayer($o);
			$this->main->getServer()->broadcastMessage($o->getName() . "," . $p->getName() . " adlı  yetkili tarafından banlandı\nSebep:" . $data[1]);
			$o->kick($p->getName() . " adlı  yetkili tarafından banlandın\nSebep:" . $data[1]);
			$this->banl = new Config($this->main->getDataFolder() . "ipbanlist.yml", Config::YAML);
			$bans = $this->banl->get("Ban");
			$bans[] = $o->getAddress();
			$this->banl->set("Ban", $bans);
			$this->banl->save();
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($o->getName());

            if (is_array($kyt)){
                $kyt[] = "IP-BAN. Sınırsız \n{$data[1]}:".time();
            }else{
                $kyt = [];
                $kyt[] = "IP-BAN. Sınırsız \n{$data[1]}:".time();
            }
            $this->kayit->set($o->getName(), $kyt);
            $this->kayit->save();



		});
		$form->setTitle("IP-Ban");
		$form->addDropdown("Oyuncu", $this->getOnlinePlayers());
		$form->addInput("Sebep", "örn: Hile Açtı!");
		$form->sendToPlayer($p);
	}

	public function aktifSBan($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			$result = $data[0];
			if($result === null){
				return true;
			}
			$o = $this->getOnlinePlayers();
			$o = $o[$data[0]];
			$o = $this->main->getServer()->getPlayer($o);
			$now = time();
			$day = ($data[1] * 86400);
			$hour = ($data[2] * 3600);
			if($data[3] > 1){
				$min = ($data[3] * 60);
			} else {
				$min = 60;
			}
			$banTime = $now + $day + $hour + $min;
			$this->banl = new Config($this->main->getDataFolder() . "sbanlist.yml", Config::YAML);
			$this->banl->set($o->getName(), $banTime);
			$this->banl->save();
			$o->kick($p->getName() . " adlı  yetkili tarafından banlandın\n" . $data[1] . " Gün ". $data[2] . " Saat " . $data[3] . " Dakika" . "\nSebep:" . $data[4]);
			$this->main->getServer()->broadcastMessage($o->getName() . "," . $p->getName() . " adlı  yetkili tarafından banlandı\n" . $data[1] . " Gün ". $data[2] . " Saat " . $data[3] . " Dakika" ."\nSebep:" . $data[4]);
            $this->kayit = new Config($this->main->getDataFolder() . "kayit.yml", Config::YAML);
            $kyt = $this->kayit->get($o->getName());
            $date = new DateTime();
            $date->setTimestamp($banTime);

            if (is_array($kyt)){
                $kyt[] = "Susturuldu. Bitiş -> ".$date->format('Y-m-d H:i:s')." \n{$data[4]}:".time();
            }else{
                $kyt = [];
                $kyt[] = "Susturuldu. Bitiş -> ".$date->format('Y-m-d H:i:s')." \n{$data[4]}:".time();
            }
            $this->kayit->set($o->getName(), $kyt);
            $this->kayit->save();

			
		});
		$form->setTitle("Süreli Ban");
		$form->addDropdown("Oyuncu", $this->getOnlinePlayers());
		$form->addSlider("Gün", 0, 30, 1);
		$form->addSlider("Saat", 0, 24, 1);
		$form->addSlider("Dakika", 0, 60, 5);
		$form->addInput("Sebep");
		$form->sendToPlayer($p);
	}

	public function getOnlinePlayers(){
		$isim = null;
		foreach($this->main->getServer()->getOnlinePlayers() as $o){
			$isim[] = $o->getName();
		}
		return $isim;
	}

	public function yetkiliPanel($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $p, int $data = null){
			if($data === null){
				return true;
			}
			switch($data){
				case 0:
				$this->aktifPanel($p);

				break; 
				case 1:
				$this->offPanel($p);

				break;
				case 2:
				$this->yasakKaldir($p);
				break;
			}

		});
		$form->setTitle("Panel");
		$form->addButton("Aktif");
		$form->addButton("Offline");
		$form->addButton("Yasak kaldır");

		$form->sendToPlayer($p);
	}

	public function yasakKaldir($p){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createCustomForm(function (Player $p, array $data = null){
			$result = $data[0];
			if($result === null){
				return true;
			}

			$yasak = ["Ban", "Süreli Ban","Mute", "Süreli Mute"];
			if($data[0] == 0){
				$this->banl = new Config($this->main->getDataFolder() . "banlist.yml", Config::YAML);
				$bans = $this->banl->get("Ban");
				if(!is_array($bans)) return false;
				$d = array_search($data[1], $bans);
				if(isset($bans[$d])){
					unset($bans[$d]);
					$this->banl->set("Ban", $bans);
					$this->banl->save();
				}
			}

			if($data[0] == 2){
				$this->banl = new Config($this->main->getDataFolder() . "mutelist.yml", Config::YAML);
				$bans = $this->banl->get("Mute");
				if(!is_array($bans)) return false;
				$d = array_search($data[1], $bans);
				if(isset($bans[$d])){
					unset($bans[$d]);
					$this->banl->set("Mute", $bans);
					$this->banl->save();
				}
			}
			if($data[0] == 1){
				$this->banl = new Config($this->main->getDataFolder() . "sbanlist.yml", Config::YAML);
				$this->banl->remove($data[1]);
				$this->banl->save();

			}

			if($data[0] == 3){
				$this->banl = new Config($this->main->getDataFolder() . "smutelist.yml", Config::YAML);
				$this->banl->remove($data[1]);
				$this->banl->save();

			}
			$p->sendMessage("Yasak kaldırıldı");


			
		});
		$yasak = ["Ban", "Süreli Ban","Mute", "Süreli Mute"];
		$form->setTitle("Yasak kaldır");
		$form->addDropdown("Tür", $yasak);
		$form->addInput("Nick");
		$form->sendToPlayer($p);
	}



}