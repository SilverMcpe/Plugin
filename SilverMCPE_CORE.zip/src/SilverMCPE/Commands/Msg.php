<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;

class Msg extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('msg', $plugin);
		$this->setDescription('Oyuncuya mesaj gönderir');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
		if(empty($args[0]) && empty($args[1])){

}else{
			$o = $this->main->getServer()->getPlayer($args[0]);
			if ($o instanceof Player) {
				$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $o->getName() . ".yml", Config::YAML);
				if ($o->getName() == $p->getName()) {
				
				$p->sendMessage("§6Silver§fMCPE §7» §cKendine mesaj yollayamazsın.");
				}else{
			
				if ($this->cfg->get("Msg") == true) {
				unset($args[0]);
				$this->main->getServer()->getLogger()->info("(" .$p->getName() . " -> " . $o->getName() . ") " . implode(" ", $args));
				foreach ($this->main->getServer()->getOnlinePlayers() as $g){
					if($g->hasPermission("Msg.okuma")){
						$g->sendMessage("\n" . "§c" .$p->getName() . " §7-> §c" . $o->getName() . "§f " . implode(" ", $args));
					}
				}
				$p->sendMessage("§c" .$p->getName() . " §7->§c " . $o->getName() . "§f " . implode(" ", $args));
				$o->sendMessage("§c" .$p->getName() . " §7->§c " . $o->getName() . "§f " . implode(" ", $args));
				}else{
					$p->sendMessage("§6Silver§fMCPE §7» §cOyuncu mesajları kapatmış.");
				}
			}

			}else{
             $p->sendMessage("§6Silver§fMCPE §7» §a/msg <oyuncu ismi> <mesaj>");
			}
		}

      return true;
	}



	}