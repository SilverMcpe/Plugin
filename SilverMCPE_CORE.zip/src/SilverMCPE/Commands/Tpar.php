<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;

class Tpar extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('tpar', $plugin);
		$this->setDescription('Oyuncuya ışınlanma isteği reddet');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
		$istek = $this->main->tpaIstekSorgula($p);
		if($istek == "false"){
			$p->sendMessage("§6Silver§fMCPE §7» §cIşınlanma isteği bulunamadı.");
		}else{
			$o = $this->main->getServer()->getPlayer($istek);
			if ($o instanceof Player) {
               						unset($this->main->istek[$p->getName()]);
               						$p->sendMessage("§6Silver§fMCPE §7» §aIşınlanma isteği reddedildi.");
               						$o->sendMessage("§6Silver§fMCPE §7» §cOyuncu isteğini reddetti.");

			}else{
				$p->sendMessage("§6Silver§fMCPE §7» §eOyuncu bulunamadı.");
			}
		}

      return true;
	}



	}