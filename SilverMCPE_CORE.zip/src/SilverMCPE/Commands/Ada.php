<?php

namespace SilverMCPE\Commands;

use pocketmine\{
    command\Command,
    command\PluginCommand,
    command\CommandSender,
    utils\Config,
    Player,
    math\Vector3,
    scheduler\Task
};

class Ada extends PluginCommand{

	public function __construct($plugin){
		parent::__construct('ada', $plugin);
        $this->setDescription('Ada Menüsü');
        $this->setAliases(["is", "sb"]);
		$this->main = $plugin;

    }
    public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
       $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);

       if($this->cfg->get("AIsim") == null){
            $this->adaYok($p);
           
       
       }elseif(is_dir("worlds/" . $p->getName())){
      
        $this->adaVar($p);
         }else{
            $this->adaVar($p); 
         }
       

       

        return true;
    }

    public function adaYok($p){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $args = null){
        $result = $args;
        if($result === null){

        return true;
        }
        switch ($result) {
            case 0:
         $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);

         $this->adaOlustur($p);
         $this->cfg->set("AIsim", $p->getName());
         $this->cfg->set("xp", 0);
         $this->cfg->set("level", 0);
         $this->cfg->set("sxp", 400);
         $this->cfg->save();
          $p->sendMessage("§6Silver§fMCPE §7» §aAdanız oluşturuldu.");
            break;
            case 1:
            $this->ortakKabul($p);
            break;
        }
        });
        $form->setTitle("§6Silver§fMCPE §r- Ada Menü");
        $form->addButton("Ada Oluştur");
        $form->addButton("Ortaklık isteği kabul et");
        $form->sendToPlayer($p);
    }

    public function adaVar($p){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $args = null){
        $result = $args;
        if($result === null){

        return true;
        }
        switch ($result) {
            case 0:
         $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
         if($this->cfg->get("AIsim") == null){
            $this->main->getServer()->loadLevel($p->getName());
            $world = $this->main->getServer()->getLevelByName($p->getName());
         }else{
            $this->main->getServer()->loadLevel($this->cfg->get("AIsim"));
            $world = $this->main->getServer()->getLevelByName($this->cfg->get("AIsim"));
         }

         $spawn = $world->getSafeSpawn();
         $p->teleport($spawn, 0, 0);
         $p->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));
          $p->sendMessage("§6Silver§fMCPE §7» §aAdana ışınlandın.");
            break;
            case 1:
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                if($this->cfg->get("AIsim") == $p->getLevel()->getFolderName() || $this->cfg->get("AIsim") == null){
                    $pos = new Vector3($p->getX(), $p->getY(), $p->getZ());
                    $p->getLevel()->setSpawnLocation($pos);
                    $p->sendMessage("§6Silver§fMCPE §7» §aAda doğma yeri ayarlandı.");
                }

            break;
            case 2:
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);

                $this->pcfg = new Config($this->main->getDataFolder(). $this->cfg->get("AIsim") .".json", Config::JSON);
                if($this->pcfg->get("AdaK") === null || !$this->pcfg->get("AdaK")){
                    $this->pcfg->set("AdaK", true);
                    $p->sendMessage("§6Silver§fMCPE §7» §cAda kilitlendi.");
                }else{
                    $this->pcfg->set("AdaK", false);
                    $p->sendMessage("§6Silver§fMCPE §7» §aAda kilidi açıldı.");

                }
                $this->pcfg->save();
            break;
            case 3:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                            foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
                                $oyuncular[] = $o;
                            }
                            $o = $oyuncular[$data[0]];
                    if ($o instanceof Player) {
                      if ($o->getName() == $p->getName()) {
                        $p->sendMessage("§6Silver§fMCPE §7» §cKendine ziyaret edemezsin.");
                        }else{
                                            $this->cfg = new Config($this->main->getDataFolder() . $o->getName() . ".json", Config::JSON);
                                            $this->cfg = new Config($this->main->getDataFolder() . $this->cfg->get("AIsim") . ".json", Config::JSON);
                            if(!$this->cfg->get("AdaK") || $this->cfg->get("AdaK") == null) {
                                if($this->cfg->get("AIsim") == null){
                                    $this->main->getServer()->loadLevel($p->getName());
                                    $world = $this->main->getServer()->getLevelByName($p->getName());
                                 }else{
                                    $this->main->getServer()->loadLevel($this->cfg->get("AIsim"));
                                    $world = $this->main->getServer()->getLevelByName($this->cfg->get("AIsim"));
                                 }
                             
                    
                             $spawn = $world->getSafeSpawn();
                             $p->teleport($spawn, 0, 0);
                             $p->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));
                            }else{
        $p->sendMessage("§6Silver§fMCPE §7» §cOyuncunun adası kilitli.");
                    }
        
                    }
                    }else{
                        $p->sendMessage("§6Silver§fMCPE §7» §eOyuncu bulunamadı.");
                    }
        
            });
                $for->setTitle("§6Silver§fMCPE §r- Ziyaret");
                            foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
                                $oyuncular[] = $o->getName();
                            }
                $for->addDropdown("Oyuncu Seç", $oyuncular);
                $for->sendToPlayer($p);
            break;
            case 4:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                foreach ($p->getLevel()->getPlayers() as $o) {
                    $oyuncular[] = $o;
                }
                            $o = $oyuncular[$data[0]];
                    if ($o instanceof Player) {
                      if ($o->getName() == $p->getName()) {
                       $p->sendMessage("§6Silver§fMCPE §7» §cKendine tekmeliyemezsin.");
                      }else{
                                            $this->cfg = new Config($this->main->getDataFolder() . $o->getName() . ".json", Config::JSON);
                                            $this->cfg = new Config($this->main->getDataFolder() . $this->cfg->get("AIsim") . ".json", Config::JSON);
                          
                                    

                                 
                             
                             $world = $this->main->getServer()->getDefaultLevel();
                             $spawn = $world->getSafeSpawn();
                             $o->teleport($spawn, 0, 0);
                             $o->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));

        
                   }
                    }else{
                        $p->sendMessage("§6Silver§fMCPE §7» §cOyuncu bulunamadı.");
                    }
        
            });
                $for->setTitle("§6Silver§fMCPE §r- Tekmele");
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                            foreach ($p->getLevel()->getPlayers() as $o) {
                                $oyuncular[] = $o->getName();
                            }
                            
                            if($this->cfg->get("AIsim") == null){
                                if($p->getLevel()->getFolderName() == $p->getName()){

                                }else{
                                    $p->sendMessage("§6Silver§fMCPE §7» §cAdanda olmalısın.");
                                 return true;
                                } 
                            }else{
                                if($p->getLevel()->getFolderName() == $this->cfg->get("AIsim")){

                                }else{
                                    $p->sendMessage("§6Silver§fMCPE §7» §cAdanda olmalısın.");
                                     return true;
                                }
                            }
                            
                            
                            if($oyuncular == null){
                                $p->sendMessage("§6Silver§fMCPE §7» §cAdanda kimse yok.");
                             return true;
                            }
                            
                         
                          
                            
                $for->addDropdown("Oyuncu Seç", $oyuncular);
                $for->sendToPlayer($p);
            break;
            case 5:
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                 $level = $this->main->getServer()->getLevelByName($this->cfg->get("AIsim"));
                 if($level == null){
                    $p->sendMessage("Adanda kimse yok.");
                       return false;
                 }
                 if(!empty($level->getPlayers())){
                      $mesaj = " ";
                      foreach($level->getPlayers() as $o){
                          $mesaj .= "-> " . $o->getName() . "\n";
                      }
                      $p->sendMessage("§6Silver§fMCPE §7» §aAdandaki kişiler:\n§f" . $mesaj);
                 }else{
                    $p->sendMessage("§6Silver§fMCPE §7» §cAdanda kimse yok.");

                 }
            break;
            case 6:
				$this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
				if($this->cfg->get("AIsim") == $p->getName() || is_dir("worlds/" . $p->getName())) {

					$this->ortakMenu($p);

				}else{
					$this->pcfg = new Config($this->main->getDataFolder() . $this->cfg->get("AIsim") . ".json", Config::JSON);
					$ortaklar = $this->pcfg->get("Ortaklar");
					$da = array_search($p->getName(), $ortaklar);
					unset($ortaklar[$da]);
					$this->pcfg->set("Ortaklar", $ortaklar);
					$this->pcfg->save();

					$this->cfg->remove("AIsim");
					$this->cfg->save();
					$p->sendMessage("§6Silver§fMCPE §7» §cAdadan ayrıldın.");
				}
            break;
            case 7:
                $this->yardimciMenu($p);
            break;
            case 8:
              $this->engelMenü($p);
            break;
            case 9:
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                if($this->cfg->get("Pvp")){
                    $this->cfg->set("Pvp", false);
                    $p->sendMessage("§6Silver§fMCPE §7» §cPvp Kapatıldı."); 
                }elseif(!$this->cfg->get("Pvp")){
                    $this->cfg->set("Pvp", true);
                    $p->sendMessage("§6Silver§fMCPE §7» §aPvp açıldı."); 
                }else{
                    $this->cfg->set("Pvp", false);
                    $p->sendMessage("§6Silver§fMCPE §7» §cPvp Kapatıldı."); 
                }
                $this->cfg->save();
            break;
            case 10:

                $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

				$form = $api->createModalForm(function (Player $p, $data) {
					$result = $data;
					if ($result === null) {
						return true;
					}
					switch ($result) {
						case 0:
							$p->sendMessage("§6Silver§fMCPE §7» §cAda Silinmedi.");
							break;
                        case 1:
                            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                            $time = $this->cfg->get("SilmeS");
                            $now = time();
                            if($time > $now){
                                $remainingTime = $time - $now;
                                $hour = floor($remainingTime / 3600);
                                $minuteSec = $remainingTime % 3600;
                                $minute = floor($minuteSec / 60);
                                $remainingSec = $minuteSec % 60;
                                $second = ceil($remainingSec);
                                $p->sendMessage("§6Silver§fMCPE §7» §cAdanı silmek için kalan süre§f " . $hour . " §cSaat §f". $minute . " §cDakika §f" . $second . " §cSaniye");
                                return true;
                            }
                            
                                $sd = $this->main->getServer()->getDataPath();
                                $dir = $sd . "worlds/" . $p->getName();
                                $this->main->getServer()->loadLevel($p->getName());
                                if($this->main->getServer()->getLevelByName($p->getName())->getPlayers() == null) {

								}else{
                                    foreach($this->main->getServer()->getLevelByName($p->getName())->getPlayers() as $o){
                                                                 
                                        $world = $this->main->getServer()->getDefaultLevel();
                                        $spawn = $world->getSafeSpawn();
                                        $o->teleport($spawn, 0, 0);
                                        $o->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));
                                    }
                                }
                
                
                                $this->main->getServer()->unloadLevel($this->main->getServer()->getLevelByName($p->getName()));
                                
                                if($this->cfg->get("Ortaklar") != null){
                                    foreach($this->cfg->get("Ortaklar") as $o){
                                        $this->pcfg = new Config($this->main->getDataFolder() . $o . ".json", Config::JSON);    
                                        $this->pcfg->remove("AIsim");  
                                        $this->pcfg->save();                
                                       
                                    }
                            
                                }
                                $this->cfg->remove("Ortaklar");
                                $this->cfg->remove("AIsim");
                                $this->cfg->remove("xp");
                                $this->cfg->remove("sxp");
                                $this->cfg->remove("level");
                                $this->level = new Config($this->main->getDataFolder() ."toplevel.json", Config::JSON);
                                $this->level->remove($p->getName());
                                $this->level->save();
                                $now = time();
                                $hour = (24 * 3600);
                                $time = $now + $hour;
                                $this->cfg->set("SilmeS", $time);
                                $this->cfg->save();
							$this->ocfg = new Config($this->main->getDataFolder() . "OSpawnerlar.yml", Config::YAML);
							foreach ($this->ocfg->getAll() as $sp => $bilgi) {
								$kordi = explode(",", $sp);
                          if($kordi[3] == $p->getName()){
                          	$this->ocfg->remove($sp);
                          	$this->cfg->save();
						  }
							}
                                
                        $this->main->getScheduler()->scheduleDelayedTask(new class($this, $dir) extends Task{
                
                            public function __construct($c, $e){
                
                                $this->c = $c;
                
                                $this->dir = $e;
                
                            }
                
                            public function onRun(int $currentTick){
                                
                                 $this->c->remove_dir($this->dir);
                
                            }
                
                        }, 15);
                                
                                $p->sendMessage("§6Silver§fMCPE §7» §aAda Silindi.");
					
					}


				});
                $form->setTitle("§6Silver§fMCPE §r- Ada");
				$form->setContent("Adanı silmek istiyor musun?");
				$form->setButton1("Sil");
				$form->setButton2("İptal");
				$form->sendToPlayer($p);
            break;

        }
        });

        $form->setTitle("§6Silver§fMCPE §r- Ada Menü");
        $form->addButton("Ada Işınlan");
        $form->addButton("Ada Spawn Ayarla");
        $form->addButton("Ada Kilit");
        $form->addButton("Ada Ziyaret");
        $form->addButton("Ada Tekmele");
        $form->addButton("Ada Kişiler");
        $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
        if($this->cfg->get("AIsim") == $p->getName() || is_dir("worlds/" . $p->getName())){
        	if(!$this->cfg->get("Pvp")){
				$pvp = "§cKapalı";
			}else{
				$pvp = "§aAktif";
			}
            $form->addButton("§6Silver§fMCPE §r- Ortak Menü");
            $form->addButton("Yardımcı Menü");
			$form->addButton("Ada Engel");
			$form->addButton("Ada Pvp: " . $pvp);
            $form->addButton("Ada Sil");
        }else{
        	$form->addButton("Ada Ayrıl");
		}
        $form->sendToPlayer($p);
    }

    function remove_dir($dir)
	{
		if (is_dir($dir)) {
			$objects = scandir($dir);
			foreach ($objects as $object)
			{
				if($object != "." && $object != "..")
				{
					if(is_dir($dir. "/" . $object)) {
						$this->remove_dir($dir . "/" . $object);
					}else{
						unlink($dir . "/" . $object);
					}
				}
			}

			rmdir($dir);
		}
    }
    
    public function ortakKabul($p){
        if(isset($this->istek[$p->getName()])){
        	$or = $this->main->getServer()->getPlayer($this->istek[$p->getName()]);
        	if($or instanceof Player){
        		$or->sendMessage("§6Silver§fMCPE §7» §aOyuncu isteğini kabul etti");
        	}
            $this->cfg = new Config($this->main->getDataFolder() . $this->istek[$p->getName()] . ".json", Config::JSON);
            $ortaklar = $this->cfg->get("Ortaklar");
            $ortaklar[] = $p->getName();
            $this->cfg->set("Ortaklar", $ortaklar);
            $this->cfg->save();   
            $this->pcfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            $this->pcfg->set("BKo", true);
            $this->pcfg->set("BKı", true);
            $this->pcfg->set("CA", true);
            $this->pcfg->set("IA", true);
            $this->pcfg->set("AIsim", $this->istek[$p->getName()]);
            unset($this->istek[$p->getName()]);
            $this->pcfg->save();
            $p->sendMessage("§6Silver§fMCPE §7» §aOrtak Eklendi");

        }else{
            $p->sendMessage("§6Silver§fMCPE §7» §cOrtak isteği bulunamadı");
        }

    }

    public function engelMenü($p){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $args = null){
        $result = $args;
        if($result === null){

        return true;
        }
        switch ($result) {
            case 0:
               $this->adaEngelle($p);
            break;
            case 1:
                $this->engelAc($p);
            break;
 
        }
        });
        $form->setTitle("§6Silver§fMCPE §r- Ortak Menü");
        $form->addButton("Oyuncu engelle");
        $form->addButton("Oyuncu engel aç");
        $form->sendToPlayer($p);
    }


    public function adaEngelle($p){
        $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

        $for = $apii->createCustomForm(function (Player $p, array $data = null) {
        $result = $data;
    if ($result === null) {
            return true;
        }
        $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
        $engel = $this->cfg->get("Engel");
        if($engel == null){
            $engel = array($data[0]);
        }else{
            $engel[] = $data[0];
        }
        $this->cfg->set("Engel", $engel);
        $this->cfg->save();
        $p->sendMessage($data[0] . " Oyuncu engellendi.");


    });

        $for->setTitle("§6Silver§fMCPE §r- Ada Engelle");
        $for->addInput("Oyuncu ismi", "örn: TalhaRST");

        $for->sendToPlayer($p);

    }

    public function engelAc($p){
        $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

        $for = $apii->createCustomForm(function (Player $p, array $data = null) {
        $result = $data;
    if ($result === null) {
            return true;
        }
        $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
        $engel = $this->cfg->get("Engel");
        if($engel == null){
            $p->sendMessage("§6Silver§fMCPE §7» §cEngelli oyuncu bulunamadı.");
            return false;
        }else{
            $de = array_search($data[0], $engel);
            if($engel[$de] == null){
                $p->sendMessage("§6Silver§fMCPE §7» §cEngelli oyuncu bulunamadı.");
                return false;

            }else{
                unset($engel[$de]);
            }
        }
        $this->cfg->set("Engel", $engel);
        $this->cfg->save();
        $p->sendMessage($data[0] . " Oyuncu engelli kaldırıldı.");


    });

        $for->setTitle("§6Silver§fMCPE §r- Ada Engel Kaldır");
        $for->addInput("Oyuncu ismi", "örn: TalhaRST");

        $for->sendToPlayer($p);
    }

    public function ortakIzin($p, $o){
        $this->ortak = $o;
        $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

        $for = $apii->createCustomForm(function (Player $p, array $data = null) {
        $result = $data;
    if ($result === null) {
            return true;
        }
        $this->pcfg = new Config($this->main->getDataFolder() . $this->ortak . ".json", Config::JSON);   
        $this->pcfg->set("BKo", $data[0]);
        $this->pcfg->set("BKı", $data[1]);
        $this->pcfg->set("CA", $data[2]);
      
        $this->pcfg->save();
        $p->sendMessage("§6Silver§fMCPE §7» §aAyarlar kaydedildi.");

    });
    $this->pcfg = new Config($this->main->getDataFolder() . $this->ortak . ".json", Config::JSON);   

        $for->setTitle("§6Silver§fMCPE §r- Ortaklar");
        $for->addToggle("Blok Koyma", $this->pcfg->get("BKo"));
        $for->addToggle("Blok Kırma", $this->pcfg->get("BKı"));
        $for->addToggle("Chest Açma", $this->pcfg->get("CA"));

        $for->sendToPlayer($p);

    }

    
    public function yardımcıIzin($p, $o){
        $this->ortak = $o;
        $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $this->pcfg = new Config($this->main->getDataFolder() . $this->ortak . ".json", Config::JSON);   

        $for = $apii->createCustomForm(function (Player $p, array $data = null) {
        $result = $data;
    if ($result === null) {
            return true;
        }
        $this->pcfg->setNested($p->getName() . ".BKo", $data[0]);
        $this->pcfg->setNested($p->getName() . ".BKı", $data[1]);
        $this->pcfg->setNested($p->getName() . ".CA", $data[2]);
      
        $this->pcfg->save();
        $p->sendMessage("§6Silver§fMCPE §7» §aAyarlar kaydedildi.");

    });
    $this->pcfg = new Config($this->main->getDataFolder() . $this->ortak . ".json", Config::JSON);   

        $for->setTitle("§6Silver§fMCPE §r- Yardımcı");
        $for->addToggle("Blok Koyma", $this->pcfg->getNested($p->getName() . ".BKo"));
        $for->addToggle("Blok Kırma", $this->pcfg->getNested($p->getName() . ".BKı"));
        $for->addToggle("Chest Açma", $this->pcfg->getNested($p->getName() . ".CA"));

        $for->sendToPlayer($p);

    }


    public function ortakMenu($p){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $args = null){
        $result = $args;
        if($result === null){

        return true;
        }
        switch ($result) {
            case 0:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                        
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if($this->cfg->get("Ortaklar") == null || !is_array($this->cfg->get("Ortaklar"))){
                $p->sendMessage("§6Silver§fMCPE §7» §cHiç ortağın yok."); 
                return true;
            } 
            if(is_array($this->cfg->get("Ortaklar"))){
                $mesaj = null;
                foreach($this->cfg->get("Ortaklar") as $ortak){
                $mesaj .= "\n" . $ortak;
                }
            }else{
                $mesaj = $this->cfg->get("Ortaklar");
            }
                $for->setTitle("§6Silver§fMCPE §r- Ortaklar");
                $for->addLabel($mesaj);
                $for->sendToPlayer($p);
            break;
            case 1:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                $ortaklar = $this->cfg->get("Ortaklar");
                    $this->ortakIzin($p, $ortaklar[$data[0]]);
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if($this->cfg->get("Ortaklar") == null || !is_array($this->cfg->get("Ortaklar"))){
                $p->sendMessage("§6Silver§fMCPE §7» §cHiç ortağın yok."); 
                return true;
            } 
            if(is_array($this->cfg->get("Ortaklar"))){
                $ortak = $this->cfg->get("Ortaklar");
            }else{
                $ortak = [$this->cfg->get("Ortaklar")];
            }
           
                $for->setTitle("§6Silver§fMCPE §r- Ortaklar");
                $for->addDropdown("Ortak", $ortak);

                $for->sendToPlayer($p);

            break;
            case 2:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                $ortaklar = $this->cfg->get("Ortaklar");
                $this->pcfg = new Config($this->main->getDataFolder() . $ortaklar[$data[0]] . ".json", Config::JSON);   
                $this->pcfg->remove("AIsim");
                $this->pcfg->save();
                unset($ortaklar[$data[0]]);
                $this->cfg->set("Ortaklar", $ortaklar);
                $this->cfg->save();
                $p->sendMessage("§6Silver§fMCPE §7» §aOyuncu ortaklıktan çıkarıldı.");
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if($this->cfg->get("Ortaklar") == null){
                $p->sendMessage("§6Silver§fMCPE §7» §cHiç ortağın yok."); 
                return true;
            } 
            if(is_array($this->cfg->get("Ortaklar"))){
                $ortak = $this->cfg->get("Ortaklar");
            }else{
                $ortak = [$this->cfg->get("Ortaklar")];
            }
           
                $for->setTitle("§6Silver§fMCPE §r- Ortaklar");
                $for->addDropdown("Ortak", $ortak);

                $for->sendToPlayer($p);
            break;
            case 3:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                            foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
                                $oyuncular[] = $o;
                            }
                            $o = $oyuncular[$data[0]];
                            $this->cfg = new Config($this->main->getDataFolder() . $o->getName() . ".json", Config::JSON);
                    if ($o instanceof Player) {
                     if ($o->getName() == $p->getName()) {
                       $p->sendMessage("§6Silver§fMCPE §7» §cKendine ortak ekliyemezsin.");
                        }else{
                        if($this->cfg->get("AIsim") == null || !is_dir("worlds/" . $o->getName())){
                            $p->sendMessage("Ortaklık isteği gönderildi");
                            $o->sendMessage("§6Silver§fMCPE §7» §e".$p->getName() . " §asana ortaklık isteği gönderdi kabul etmek için /ada");
                            $this->istek[$o->getName()] = $p->getName();

                            }else{
        $p->sendMessage("§6Silver§fMCPE §7» §cOyuncunun adası var.");
                    }
               }
                    
                    }else{
                        $p->sendMessage("§6Silver§fMCPE §7» §cOyuncu bulunamadı.");
                    }

                
        
            });
                $for->setTitle("§6Silver§fMCPE §r- Ortak Ekle");
                            foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
                                $oyuncular[] = $o->getName();
                            }
                $for->addDropdown("Oyuncu Seç", $oyuncular);
                $for->sendToPlayer($p);
            break;
            case 4:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                $ortaklar = $this->cfg->get("Ortaklar");
                $or = $ortaklar[$data[0]];

                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                        
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON); 
                $for->setTitle("§6Silver§fMCPE §r- Ortaklar");
                $for->addLabel("Blok kırma: " . $this->izinDurum("BKı", $or) . "\nBlok Koyma: " . $this->izinDurum("BKo", $or) . "\nChest Açma: " . $this->izinDurum("CA", $or));
                $for->sendToPlayer($p);
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if($this->cfg->get("Ortaklar") == null){
                $p->sendMessage("§6Silver§fMCPE §7» §cHiç ortağın yok."); 
                return true;
            } 
            if(is_array($this->cfg->get("Ortaklar"))){
                $ortak = $this->cfg->get("Ortaklar");
            }else{
                $ortak = [$this->cfg->get("Ortaklar")];
            }
           
                $for->setTitle("§6Silver§fMCPE §r- Ortaklar");
                $for->addDropdown("Ortak", $ortak);

                $for->sendToPlayer($p);  
            break;
 
        }
        });
        $form->setTitle("§6Silver§fMCPE §r- Ortak Menü");
        $form->addButton("Ortaklar");
        $form->addButton("Ortak Izin");
        $form->addButton("Ortak Çıkar");
        $form->addButton("Ortak Ekle");
        $form->addButton("Ortak İzinler");
        $form->sendToPlayer($p);
    }

    public function yardimciMenu($p){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $args = null){
        $result = $args;
        if($result === null){

        return true;
        }
        switch ($result) {
            case 0:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                        
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if($this->cfg->get("Yardımcılar") == null){
                $p->sendMessage("§6Silver§fMCPE §7» §cHiç yardımcın yok."); 
                return true;
            } 
            if(is_array($this->cfg->get("Yardımcılar"))){
                $mesaj = null;
                foreach($this->cfg->get("Yardımcılar") as $ortak){
                $mesaj .= "\n" . $ortak;
                }
            }else{
                $mesaj = $this->cfg->get("Yardımcılar");
            }
                $for->setTitle("§6Silver§fMCPE §r- Yardımcılar");
                $for->addLabel($mesaj);
                $for->sendToPlayer($p);
            break;
            case 1:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                $ortaklar = $this->cfg->get("Yardımcılar");
                    $this->yardımcıIzin($p, $ortaklar[$data[0]]);
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if($this->cfg->get("Yardımcılar") == null || !is_array($this->cfg->get("Yardımcılar"))){
                $p->sendMessage("§6Silver§fMCPE §7» §cHiç yardımcın yok."); 
                return true;
            } 
            if(is_array($this->cfg->get("Yardımcılar"))){
                $ortak = $this->cfg->get("Yardımcılar");
            }else{
                $ortak = [$this->cfg->get("Yardımcılar")];
            }
           
                $for->setTitle("§6Silver§fMCPE §r- Yardımcılar");
                $for->addDropdown("Yardımcılar", $ortak);

                $for->sendToPlayer($p);

            break;
            case 2:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                $ortaklar = $this->cfg->get("Yardımcılar");
                $this->pcfg = new Config($this->main->getDataFolder() . $ortaklar[$data[0]] . ".json", Config::JSON);   
                $this->pcfg->remove($p->getName());
                $this->pcfg->save();
                unset($ortaklar[$data[0]]);
                $this->cfg->set("Yardımcılar", $ortaklar);
                $this->cfg->save();
                $p->sendMessage("§6Silver§fMCPE §7» §aOyuncu yardımcılıktan çıkarıldı.");
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if(empty($this->cfg->get("Yardımcılar")) || !is_array($this->cfg->get("Yardımcılar"))){
                $p->sendMessage("§6Silver§fMCPE §7» §cHiç yardımcın yok."); 
                return true;
            } 
            if(!is_array($this->cfg->get("Yardımcılar"))){
				$p->sendMessage("§6Silver§fMCPE §7» §cHiç yardımcın yok.");
				return true;
			}
            if(is_array($this->cfg->get("Yardımcılar"))){
                $ortak = $this->cfg->get("Yardımcılar");
            }else{
                $ortak = [$this->cfg->get("Yardımcılar")];
            }

				if(is_object($ortak)){
					$p->sendMessage("§6Silver§fMCPE §7» §cHiç yardımcın yok.");
					return true;
				}
                $for->setTitle("§6Silver§fMCPE §r- Yardımcılar");
                $for->addDropdown("Yardımcı", $ortak);

                $for->sendToPlayer($p);
            break;
            case 3:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                            foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
                                $oyuncular[] = $o;
                            }
                            $o = $oyuncular[$data[0]];
                            $this->cfg = new Config($this->main->getDataFolder() . $o->getName() . ".json", Config::JSON);
                    if ($o instanceof Player) {
                     if ($o->getName() == $p->getName()) {
                       $p->sendMessage("§6Silver§fMCPE §7» §cKendine yardımcı ekliyemezsin.");
                        }else{
                       
                            $p->sendMessage("§6Silver§fMCPE §7» §aYardımcı isteği gönderildi");
                            $o->sendMessage("§6Silver§fMCPE §7» §e".$p->getName() . " §asana yardımcı isteği gönderdi kabul etmek için /ykabul");
                            $this->main->yistek[$o->getName()] = $p->getName();

                            
               }
                    
                    }else{
                        $p->sendMessage("§6Silver§fMCPE §7» §cOyuncu bulunamadı.");
                    }

                
        
            });
                $for->setTitle("§6Silver§fMCPE §r- Yardımcı Ekle");
                            foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
                                $oyuncular[] = $o->getName();
                            }
                $for->addDropdown("Oyuncu Seç", $oyuncular);
                $for->sendToPlayer($p);
            break;
            case 4:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                              
                $ortak = $this->cfg->get("IYardımcılar");
                $o = $ortak[$data[0]];
                   $this->main->getServer()->loadLevel($o);
                   $world = $this->main->getServer()->getLevelByName($o);

                $spawn = $world->getSafeSpawn();
                $p->teleport($spawn, 0, 0);
                $p->teleport(new Vector3($spawn->getX(), $spawn->getY(), $spawn->getZ()));
                 $p->sendMessage("§6Silver§fMCPE §7» §aAdana ışınlandın.");
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if($this->cfg->get("IYardımcılar") == null || !is_array($this->cfg->get("IYardımcılar"))){
                $p->sendMessage("§6Silver§fMCPE §7» §cHiç yardımcın yok."); 
                return true;
            } 
            if(is_array($this->cfg->get("IYardımcılar"))){
                $ortak = $this->cfg->get("IYardımcılar");
            }else{
                $ortak = [$this->cfg->get("IYardımcılar")];
            }
           
                $for->setTitle("§6Silver§fMCPE §r- Yardımcılar");
                $for->addDropdown("Yardımcı", $ortak);

                $for->sendToPlayer($p);
            break;
            case 5:
                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                $ortaklar = $this->cfg->get("Yardımcılar");
                $or = $ortaklar[$data[0]];

                $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

                $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
            if ($result === null) {
                    return true;
                }
                        
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON); 
                $for->setTitle("§6Silver§fMCPE §r- Yardımcılar");
                $for->addLabel("Blok kırma: " . $this->yizinDurum("BKı", $or) . "\nBlok Koyma: " . $this->yizinDurum("BKo", $or) . "\nChest Açma: " . $this->yizinDurum("CA", $or));
                $for->sendToPlayer($p);
        
            });
            $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
            if($this->cfg->get("Yardımcılar") == null){
                $p->sendMessage("§6Silver§fMCPE §7» §cHiç yardımcın yok."); 
                return true;
            } 
            if(is_array($this->cfg->get("Yardımcılar"))){
                $ortak = $this->cfg->get("Yardımcılar");
            }else{
                $ortak = [$this->cfg->get("Yardımcılar")];
            }
           
                $for->setTitle("§6Silver§fMCPE §r- Ortaklar");
                $for->addDropdown("Yardımcılar", $ortak);

                $for->sendToPlayer($p);  
            break;
 
        }
        });
        $form->setTitle("§6Silver§fMCPE §r- Yardımcı");
        $form->addButton("Yardımcılar");
        $form->addButton("Yardımcı Izin");
        $form->addButton("Yardımcı Çıkar");
        $form->addButton("Yardımcı Ekle");
        $form->addButton("Yardımcı Işınlan");
        $form->addButton("Yardımcı İzinler");
        $form->sendToPlayer($p);
    }




    public function izinDurum($tür, $i): string{
        $this->pcfg = new Config($this->main->getDataFolder() . $i . ".json", Config::JSON);   
        if($this->pcfg->get($tür)){
                return "Aktif";
        }else{
                return "Kapalı";
        }

      
    }

    public function yizinDurum($tür, $i): string{
        $this->pcfg = new Config($this->main->getDataFolder() . $i . ".json", Config::JSON);   
        if($this->pcfg->getNested($i . "." . $tür)){
                return "Aktif";
        }else{
                return "Kapalı";
        }

      
    }
    public function adaOlustur($p){
        $sd = $this->main->getServer()->getDataPath();
        @mkdir($sd . "worlds/" . $p->getName() . "/");
        @mkdir($sd . "worlds/" . $p->getName() . "/region/");
        $dunya = opendir($this->main->getServer()->getDataPath() . "Ada/region/");
        while ($dosya = readdir($dunya)) {
            if ($dosya != "." and $dosya != "..") {
                copy($sd . "Ada/region/" . $dosya, $sd . "worlds/" . $p->getName() . "/region/" . $dosya);
            }
        }
        copy($sd . "Ada/level.dat", $sd . "worlds/" . $p->getName() . "/level.dat");

    }
}