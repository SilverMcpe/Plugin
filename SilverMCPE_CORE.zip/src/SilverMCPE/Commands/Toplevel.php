<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\entity\{Zombie, Human, Entity};
use pocketmine\math\Vector3;
use pocketmine\item\Item;

class TopLevel extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('toplevel', $plugin);
		$this->setDescription('Top Level');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
		$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $p->getName() . ".yml", Config::YAML);
		$apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

		$for = $apii->createCustomForm(function (Player $p, array $data = null) {
		$result = $data;
	if ($result === null) {
			return true;
		}

				

	});
    $this->level = new Config($this->main->getDataFolder() ."toplevel.json", Config::JSON);
$message = null;
       $level_top = $this->level->getAll();

    if(count($level_top) > 0){
        arsort($level_top);
        $i = 1;
       
        foreach($level_top as $name => $level){
            $message .= "\n§b ".$i.". §d".$name.": §f".$level;
           
            if($i >= 10){
                break;
                }
                $i++;
            }
        }else{
    	$p->sendMessage("§6Silver§fMCPE §7» §cSıralamada suan kimsenin leveli yok.");
    	return true;
	}

		$for->setTitle("§6Silver§fMcpe§r - Toplevel");
        $for->addLabel($message);

		$for->sendToPlayer($p);
       

      return true;
	}



	}