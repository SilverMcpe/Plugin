<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use onebone\economyapi\EconomyAPI;
use pocketmine\Player;
use pocketmine\Server;

class Rütbe extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('rutbe', $plugin);
		$this->setDescription('Rütbe atlama');
		$this->main = $plugin;
	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
				$oc = new Config($this->main->getDataFolder(). $p->getName() . ".yml", Config::YAML);
			$rutbe = $oc->get("Rutbe");
			if($rutbe == "Emekli"){

			}else{
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

				$form = $api->createModalForm(function (Player $p, $data) {
					$result = $data;
					if ($result === null) {
						return true;
					}
					switch ($result) {
						case 0:
							$p->sendMessage("§6Silver§bMcpe §7» §cRütbe Atlayamadınız.");
							break;
						case 1:
							$oc = new Config($this->main->getDataFolder() . $p->getName() . ".yml", Config::YAML);
							$rutbe = $oc->get("Rutbe");
							if (empty($rutbe)){
								$srutbe = "İsci";
								$rutbe = "Yok";
								$fiyat = 35000;
								$yperm = "yetki.isci";
								$perm = "";
							}elseif ($rutbe == "İsci"){
								$srutbe = "Usta";
								$fiyat = 75000;
								$yperm = "yetki.usta";
								$perm = "yetki.isci";
							}elseif ($rutbe == "Usta"){
								$srutbe = "İş Adamı";
								$fiyat = 110000;
								$perm = "yetki.usta";
								$yperm = "yetki.is.adami";
								$yperm = "tamir.vip";
							}elseif ($rutbe == "İş Adamı"){
								$srutbe = "Patron";
								$fiyat = 150000;
								$yperm = "yetki.patron";
								$perm = "yetki.is.adami";
								$yperm = "tamir.vip";								
							}elseif ($rutbe == "Patron"){
								$srutbe = "Emekli";
								$fiyat = 200000;
								$yperm = "yetki.emekli";
								$perm = "yetki.patron";
								$yperm = "tamir.vip";								
							}
							if (EconomyAPI::getInstance()->myMoney($p->getName()) >= $fiyat) {


								EconomyAPI::getInstance()->reduceMoney($p->getName(), $fiyat, true);
								$pureperms = $this->main->getServer()->getPluginManager()->getPlugin("PureChat");
								$pureperms->setPrefix($srutbe, $p);
								$oc->set("Rutbe", $srutbe);
								$oc->save();
								Server::getInstance()->dispatchCommand(new ConsoleCommandSender, "setuperm ". $p->getName() . " " . $yperm);
								if ($perm !== null) {
								Server::getInstance()->dispatchCommand(new ConsoleCommandSender, "unsetuperm ". $p->getName() . " " . $perm);

								}
								$p->sendMessage("§6Silver§fMCPE §7» §aBaşarılı bir şekilde §f" .$srutbe. " §arütbesini atladınız.");
							}
					}


				});

				if (empty($rutbe)){
					$srutbe = "İsci";
					$rutbe = "Yok";
					$fiyat = 35000;
					$conyetki = "Yetki Yok";
				}elseif ($rutbe == "İsci"){
					$srutbe = "Usta";
					$fiyat = 75000;
					$conyetki = "Yetki Yok";
				}elseif ($rutbe == "Usta"){
					$srutbe = "İş Adamı";
					$fiyat = 110000;
					$conyetki = "Tamir /tamir \n§bMaas /maas";
				}elseif ($rutbe == "İş Adamı"){
					$srutbe = "Patron";
					$fiyat = 150000;
					$conyetki = "Tamir /tamir \n§bMaas /maas";
				}elseif ($rutbe == "Patron"){
					$srutbe = "Emekli";
					$fiyat = 200000;
					$conyetki = "Tamir /tamir \n§bMaas /maas";
				}
				$form->setTitle("§6Silver§bMcpe§r - Rütbe");
				$form->setContent("§aRütben:§b " . $rutbe . "\n§aSıradaki Rütbe:§b " . $srutbe . "\n§aFiyat: §b" . $fiyat . "\n§aYetki: §b" . $conyetki);
				$form->setButton1("Rütbe Atla");
				$form->setButton2("Kapat");
				$form->sendToPlayer($p);
			}
      return true;
	}



	}