<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use korado531m7\InventoryMenuAPI\event\InventoryCloseEvent;
use korado531m7\InventoryMenuAPI\inventory\ChestInventory;
use korado531m7\InventoryMenuAPI\inventory\DoubleChestInventory;
use korado531m7\InventoryMenuAPI\InventoryMenu;
use korado531m7\InventoryMenuAPI\InventoryType;

class Canta extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('canta', $plugin);
		$this->setDescription('Cantanızı açarsınız.');
		$this->main = $plugin;
		

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
	  $this->cfg = new Config($this->main->getDataFolder() . $p->getName() . ".yml", Config::YAML);
	  $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
	  $form = $api->createSimpleForm(function (Player $p, int $args = null){
	  $result = $args;
	  if($result === null){

	  return true;
	  }
	  switch ($result) {
		  case 0:
			if($this->cfg->get("Canta-1") == "purchased"){
				$this->backpack($p, 1);
			}else{
				$this->backpackBuy($p, 1);
			}
			
		  break;
		  case 1:
			if($this->cfg->get("Canta-2") == "purchased"){
				$this->noPermission($p, "2");
			   }else{
				   $this->backpackBuy($p, 2);
			   }
		  break;
		  case 2:
			if($this->cfg->get("Canta-3") == "purchased"){
				$this->noPermission($p, "3");
			   }else{
				   $this->backpackBuy($p, 3);
			   }
		  break;
		  case 3:
			if($this->cfg->get("Canta-4") == "purchased"){
				$this->noPermission($p, "4");
			   }else{
				   $this->backpackBuy($p, 4);
			   }
		
			  
			  }
			  
  });
  $this->message = $this->messageTake($p);
  $form->setTitle("§6Silver§bMcpe §r- Çanta");
  $form->addButton("Oyuncu Çantası \n" . $this->message[1]);
  $form->addButton("Svip Çantası \n" . $this->message[2]);
  $form->addButton("Svip+ Çantası \n" . $this->message[3]);
  $form->addButton("SMega Çantası \n" . $this->message[4]);
  $form->sendToPlayer($p);
				


      return true;
	}

	public function messageTake($p){
		$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/". $p->getName() . ".yml", Config::YAML);
		$bp1 = $this->backpackStatus($p, $this->cfg->get("Canta-1"), "Canta 1");
		$bp2 = $this->backpackStatus($p, $this->cfg->get("Canta-2"), "Canta 2");
		$bp3 = $this->backpackStatus($p, $this->cfg->get("Canta-3"), "Canta 3");
		$bp4 = $this->backpackStatus($p, $this->cfg->get("Canta-4"), "Canta 4");
		$message = array(1 => $bp1, 2 => $bp2, 3 => $bp3, 4 => $bp4);
		return $message;


	}
	
	public function backpackBuy($p, $canta){
		$bp = array(1 => 5000, 2 => 10000, 3 => 15000, 4 => 20000);
		$eco = $this->main->getServer()->getPluginManager()->getPlugin("EconomyAPI");
		if(!$this->permissionCont($p, $canta)){
			$p->sendMessage("Bu çantayı alamazsın");
			return true;
		}
		if($eco->myMoney($p->getName()) >= $bp[$canta]){
			$eco->reduceMoney($p->getName(), $bp[$canta], true);
			$this->cfg->set("Canta-". $canta , "purchased");
			$this->cfg->set("Canta-". $canta . "S" , 2);
			$p->sendMessage("Çanta Alındı");
			$this->cfg->save();
		}else{
			$p->sendMessage("§6Silver§fMCPE §7» §cParan Yetersiz.");
		}
	}
	public function backpackStatus($p, $bp, $canta){
     if($bp == null){
	
		if($canta == "Canta 2"){

			if($p->hasPermission("vip") || $p->hasPermission("vipp") || $p->hasPermission("mvip")){
				$mesaj = "§e(25000)";
			}else{
				$mesaj = "§c(Bu Çantayı alamazsınız)";
			}
		}elseif($canta == "Canta 3"){

		   if($p->hasPermission("vipp") || $p->hasPermission("mvip")){
			$mesaj = "§e(35000)";
		}else{
			$mesaj = "§c(Bu Çantayı alamazsınız)";
		}
	   }elseif($canta == "Canta 4"){
		

		   if($p->hasPermission("mvip")){
			$mesaj = "§e(45000)";
		}else{
			$mesaj = "§c(Bu Çantayı alamazsınız)";
		}
	   }else{

		   $mesaj = "§e(10000)";
	   }
	 }elseif($bp == "purchased"){
		 if($canta == "Canta 2"){
			 if($p->hasPermission("vip") || $p->hasPermission("vipp") || $p->hasPermission("mvip")){
				 $mesaj = "§a(Aktif)";
			 }else{
				 $mesaj = "§c(Yetkiniz bitti lütfen itemlerinizi alın!!!)";
			 }
		 }elseif($canta == "Canta 3"){
			if($p->hasPermission("vipp") || $p->hasPermission("mvip")){
				$mesaj = "§a(Aktif)";
			}else{
				$mesaj = "§c(Yetkiniz bitti lütfen itemlerinizi alın!!!)";
			}
		}elseif($canta == "Canta 4"){
			if($p->hasPermission("mvip")){
				$mesaj = "§a(Aktif)";
			}else{
				$mesaj = "§c(Yetkiniz bitti lütfen itemlerinizi alın!!!)";
			}
		}else{
			$mesaj = "§a(Aktif)";
		}

	 }
	 return $mesaj;
	}
	
	public function backpack($p, $canta)
	{
		if($canta == 1){
         echo 0;
			$inv = new ChestInventory();
			$inv = InventoryMenu::createInventory();
		}else{
			$inv = new DoubleChestInventory();
			$inv = InventoryMenu::createInventory(DoubleChestInventory::class);
		}

echo 1;
			$inv->setReadonly(false);
			$inv->setName("Çanta ". $canta);
			$inv->send($p);

			$cfg = new Config($this->main->getDataFolder()."Oyuncu Verileri/".  $p->getName() . ".yml", Config::YAML);
			$items = unserialize($cfg->get("canta-". $canta ."E"));
			if(empty($items)){

			}else{
				$inv->setContents($items);
			}
	}

	public function permissionCont($p, $canta){
         if($canta == 1){
			 $data = true;
		 }elseif($canta == 2){
			 if($p->hasPermission("vip")){
				$data = true;
			 }else{
				 $data = false;
			 }
			
		}elseif($canta == 3){
			if($p->hasPermission("vipp")){
			   $data = true;
			}else{
				$data = false;
			}
		   
	   }elseif($canta == 4){
		if($p->hasPermission("mvip")){
		   $data = true;
		}else{
			$data = false;
		}
	   
   }
		 return $data;
	}
	
	public function noPermission($p, $canta){
		if($this->permissionCont($p, $canta)){
          $this->backpack($p, $canta);
		}else{
			$cfg = new Config($this->main->getDataFolder()."Oyuncu Verileri/".  $p->getName() . ".yml", Config::YAML);	
				$s = $cfg->get("Canta-". $canta . "S");
				$ys = $s - 1;
				if($s <= 0){
                   $p->sendMessage("§6Silver§fMCPE §7» §cÇantayı Açma hakkınız doldu.");
				}else{
					$this->backpack($p, $canta);
					$cfg->set("Canta-". $canta . "S", $ys);
					$cfg->save();
				}
			
		}
	}


	}