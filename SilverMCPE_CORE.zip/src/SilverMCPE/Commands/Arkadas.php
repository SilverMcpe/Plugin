<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;

class Arkadas extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('arkadas', $plugin);
		$this->setDescription('Arkadaş Menüsü');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $args = null) {
			$result = $args;
			if($result === null){

			return true;
			}
			switch ($result) {
				case 0:
				$this->arkadaslarForm($p);
				break;
				case 1:
				if (isset($this->arkadasIstekD[$p->getName()])) {
					$this->arkadasIstek($p);
				}else{
					$p->sendMessage("§6Silver§fMCPE §7» §cArkadaşlık isteği bulunamadı.");
				}

				break;
				case 2:
				$this->arkadasEkle($p);
			}
			});
			$form->setTitle("§6Silver§fMcpe §r- Arkadaş Menüsü");
			$form->addButton("Arkadaşlarım");
			$form->addButton("Arkadaşlık istekleri");
			$form->addButton("Arkadaş Ekle");
			$form->sendToPlayer($p);

      return true;
	}

    public function arkadasEkle($p)
    {
    	
		$apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

		$for = $apii->createCustomForm(function (Player $p, array $data = null) {
		$result = $data;
	if ($result === null) {
			return true;
		}
					foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
						$oyuncular[] = $o;
					}
					$o = $oyuncular[$data[0]];
					$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $o->getName() . ".yml", Config::YAML);
					if ($this->cfg->get("Arkadas") == true) {
											$this->arkadasIstekD[$o->getName()] = $p->getName();
					$o->sendMessage("§6Silver§fMcpe §7» §e".$p->getName() . " §aSize arkadaşlık isteği gönderdi kabul etmek için /arkadas");
					$p->sendMessage("§6Silver§fMcpe §7» §aArkadaşlık istegi §e" . $o->getName() ." §aoyuncusuna gönderildi.");
					}else{
						$p->sendMessage("§6Silver§fMCPE §7» §cOyuncu arkadaşlık isteklerini kapatmış.");
					}

	});
		$for->setTitle("Arkadas");
					foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
						$oyuncular[] = $o->getName();
					}
		$for->addDropdown("Oyuncu Seç", $oyuncular);
		$for->sendToPlayer($p);
    }
    public function arkadasIstek($p){
    					$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

				$form = $api->createModalForm(function (Player $p, $data) {
					$result = $data;
					if ($result === null) {
						return true;
					}
					switch ($result) {
						case 0:
						$o = $this->main->getServer()->getPlayer($this->arkadasIstekD[$p->getName()]);
						if ($o instanceof Player) {
							$o->sendMessage("§6Silver§fMcpe §7» §e".$p->getName() . " §aisteğinizi reddetti.");
						}
						unset($this->arkadasIstekD[$p->getName()]);
						$p->sendMessage("§6Silver§fMCPE §7» §cIstek reddedildi.");
						break;
						case 1:
						$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $p->getName() . ".yml", Config::YAML);
						$arkadaslar = $this->cfg->get("Arkadaslar");
						$o = $this->main->getServer()->getPlayer($this->arkadasIstekD[$p->getName()]);
						if(is_array($arkadaslar)){
                        if (in_array($this->arkadasIstekD[$p->getName()], $arkadaslar)) {
                            
                        $p->sendMessage("§6Silver§fMCPE §7» §cBu oyuncu zaten arkadaşın.");	
                        }else{
                        	$this->cfg2 = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $this->arkadasIstekD[$p->getName()] . ".yml", Config::YAML);
                        	$arkadaslar2 = $this->cfg2->get("Arkadaslar");
                        	$arkadaslar[] = $this->arkadasIstekD[$p->getName()];
                        	$arkadaslar2[] = $p->getName();
                        	$this->cfg->set("Arkadaslar", $arkadaslar);
                        	$this->cfg2->set("Arkadaslar", $arkadaslar2);
                        	$this->cfg->save();
                        	$this->cfg2->save();
                        	if ($o instanceof Player) {
                        		$o->sendMessage("§6Silver§fMcpe §7»§e". $p->getName() . " §aİsteğinizi kabul etti");
                        	}
                        	$p->sendMessage("§6Silver§fMcpe §7»§e" . $this->arkadasIstekD[$p->getName()] . " §aArkadaş olarak eklendi.");
                        	unset($this->arkadasIstekD[$p->getName()]);
                        }
						}elseif($arkadaslar == $this->arkadasIstekD[$p->getName()]){
                            
                        $p->sendMessage("§6Silver§fMcpe §7»§a Bu oyuncu zaten arkadaşın.");	
                        }else{
                        	$this->cfg2 = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $this->arkadasIstekD[$p->getName()] . ".yml", Config::YAML);
                        	$arkadaslar2 = $this->cfg2->get("Arkadaslar");
                        	$arkadaslar[] = $this->arkadasIstekD[$p->getName()];
                        	$arkadaslar2[] = $p->getName();
                        	$this->cfg->set("Arkadaslar", $arkadaslar);
                        	$this->cfg2->set("Arkadaslar", $arkadaslar2);
                        	$this->cfg->save();
                        	$this->cfg2->save();
                        	if ($o instanceof Player) {
                        		$o->sendMessage("§6Silver§fMcpe §7»§e".$p->getName() . " §aİsteğinizi kabul etti.");
                        	}
                        	$p->sendMessage("§6Silver§fMcpe §7»§e" .$this->arkadasIstekD[$p->getName()] . " §aArkadaş olarak eklendi.");
                        	unset($this->arkadasIstekD[$p->getName()]);
                        }
					}
				});
				$form->setTitle("Arkadas");
				$form->setContent($this->arkadasIstekD[$p->getName()] . " §aSana arkadaşlık isteği gönderdi");
				$form->setButton1("§aKabul Et");
				$form->setButton2("§cReddet");
				$form->sendToPlayer($p);
    }
    public function arkadaslarForm($p){
    					$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $p->getName() . ".yml", Config::YAML);
             $this->arkadas = $this->cfg->get("Arkadaslar");
                   $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
			$form = $api->createSimpleForm(function (Player $p, int $args = null){
			$result = $args;
			if($result === null){

			return true;
			}
			   
                $arks = [];
                 if(is_array($this->arkadas)){
                    foreach($this->arkadas as $ark) $arks[] = $ark;
                    $o = $arks[$result];
                }else{
                    $o = $this->arkadas;
                }

             
				
				$this->arkadasBilgiForm($p, $o);
			
		});
			$form->setTitle("Arkadaşlar");

             if($this->cfg->get("Arkadaslar") == null) {
             	$p->sendMessage("§6Silver§fMCPE §7» §cMalesef hiç arkadaşın yok.");
             }else{
                if(is_array($this->arkadas)){
             	foreach ($this->arkadas as $o) {
             		$form->addButton($o);
             	}
                }else{
                    $form->addButton($this->arkadas);
                }
                
                
             				$form->sendToPlayer($p);

             }
             	

    


	}
 public function arkadasBilgiForm($p, $oisim){
             $this->oisim = $oisim;
                   $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
			$form = $api->createSimpleForm(function (Player $p, int $args = null){
			$result = $args;
			if($result === null){

			return true;
			}
			 $o = $this->main->getServer()->getPlayer($this->oisim);
			$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $p->getName() . ".yml", Config::YAML);
			$this->cfg2 = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $this->oisim . ".yml", Config::YAML);
			 if ($o instanceof Player) {
          if($result == 0){
			 		$p->teleport($o);
			 	}
			 	if($result == 1){
			 		$arkadaslar = $this->cfg->get("Arkadaslar");
			 		$d = array_search($this->oisim, $arkadaslar);
			 		unset($arkadaslar[$d]);
			 		$arkadaslar2 = $this->cfg2->get("Arkadaslar");
			 		$d2 = array_search($p->getName(), $arkadaslar2);
			 		unset($arkadaslar2[$d]);
			 		$this->cfg->set("Arkadaslar", $arkadaslar);
			 		$this->cfg->save();
			 		$this->cfg2->set("Arkadaslar", $arkadaslar2);
			 		$this->cfg2->save();
                    $o->sendMessage("§6Silver§fMcpe §7»§e" . $p->getName() . " §cSeni arkadaşlıktan çıkardı.");
                    $p->sendMessage("§6Silver§fMcpe §7»§e§e" . $o->getName() . " §cArkadaşlıktan Çıkarıldı.");


			 	}
          if($result == 2){
			 		$this->arkadaslarForm($p);
			 	}
			 }else{
			 	if($result == 0){
			 		$arkadaslar = $this->cfg->get("Arkadaslar");
			 		$d = array_search($this->oisim, $arkadaslar);
			 		unset($arkadaslar[$d]);
			 		$arkadaslar2 = $this->cfg2->get("Arkadaslar");
			 		$d2 = array_search($p->getName(), $arkadaslar2);
			 		unset($arkadaslar2[$d]);
			 		$this->cfg->set("Arkadaslar", $arkadaslar);
			 		$this->cfg->save();
			 		$this->cfg2->set("Arkadaslar", $arkadaslar2);
			 		$this->cfg2->save();
                    $p->sendMessage("§6Silver§fMcpe §7»§e" . $this->oisim . " §aArkadaşlıktan Çıkarıldı.");
			 	}
			 	if($result == 1){
			 		$this->arkadaslarForm($p);
			 	}
			 	
			 }
			
			
		});
			$form->setTitle("Arkadaşlar");
            $o = $this->main->getServer()->getPlayer($oisim);
            if ($o instanceof Player) {
             	$durum = "Online";
             }else{
             	$durum = "Ofline";
             }
            $form->setContent("                  " . $oisim . "\n\n\n\n" ."Durum: " . $durum);
            
              if ($durum == "Online") {
              	$form->addButton("Işınlan");
              }
              $form->addButton("Arkadaşlıktan Çıkar");
              $form->addButton("Geri");
              $form->sendToPlayer($p);
 }
}