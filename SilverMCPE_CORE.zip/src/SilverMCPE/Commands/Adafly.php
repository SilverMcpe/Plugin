<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
    Command,
    PluginCommand,
    ConsoleCommandSender,
    CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use SilverMCPE\Tasks\FlyTask;

class Adafly extends PluginCommand
{


    public function __construct($plugin)
    {
        parent::__construct('adafly', $plugin);
        $this->setDescription('5 Dakikalık fly');
        $this->main = $plugin;
    }


    public function execute(CommandSender $p, string $commandLabel, array $args): bool
    {
        if (isset($this->main->FlySure[$p->getName()])) {
            $p->sendMessage("Zaten adafly sahipsin");
            return true;
        }
        $cfg = new Config($this->main->getDataFolder(). "fly.json", Config::JSON);
        $hak = $cfg->get($p->getName());
        if (is_int($hak)){
            if ($hak > 0){
                $hak--;
                $cfg->set($p->getName(), $hak);
                $cfg->save();
                $this->main->getScheduler()->scheduleRepeatingTask($task = new FlyTask($this->main, $p), 20);
                $this->main->FlyId[$p->getName()] = $task->getTaskID();
                $this->main->FlySure[$p->getName()] = 600;
                $p->sendMessage("§6Silver§fMcpe §7» §aAdaFly aktif edildi. Not: Oyundan çıkarsanız veya mekan değiştirirsiniz paranız boşa gider.");
                $p->setAllowFlight(true);
                return false;
            }
        }
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $worlds = ["lobi", "Arena", "teanether", "ender", "markettt"];
        if ($p->getLevel()->getFolderName() == "[fab]" . $p->getName() || in_array($p->getLevel()->getFolderName(), $worlds)) return true;

        $form = $api->createModalForm(function (Player $p, $data) {
            $result = $data;
            if ($result === null) {
                return true;
            }
            switch ($result) {
                case 0:
                    $p->sendMessage("§6Silver§fMCPE §7» §cAdaFly Alınmadı.");
                    break;
                case 1:
                    $eco = $this->main->getServer()->getPluginManager()->getPlugin("EconomyAPI");
                    if (isset($this->main->FlyId[$p->getName()])) {
                        $p->sendMessage("§6Silver§fMcpe §7» §cAdaFly zaten aktif");
                        return;

                    }
                    if ($eco->myMoney($p) >= 5000) {
                        $eco->reduceMoney($p->getName(), 5000);
                        $this->main->getScheduler()->scheduleRepeatingTask($task = new FlyTask($this->main, $p), 20);
                        $this->main->FlyId[$p->getName()] = $task->getTaskID();
                        $this->main->FlySure[$p->getName()] = 600;
                        $p->sendMessage("§6Silver§fMcpe §7» §aAdaFly aktif edildi. Not: Oyundan çıkarsanız veya mekan değiştirirsiniz paranız boşa gider.");
                        $p->setAllowFlight(true);

                    }
            }

        });
        $form->setTitle("§6Silver§bMcpe §r- AdaFly");
        $form->setContent("§aÜCRET:§b 5000§a TL \n§aSüre:§b 600 §bSaniye");
        $form->setButton1("Satın Al");
        $form->setButton2("Kapat");
        $form->sendToPlayer($p);

        return true;
    }


}