<?php


namespace SilverMCPE\Commands;

use pocketmine\command\{
    Command,
    PluginCommand,
    ConsoleCommandSender,
    CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;

class Event extends PluginCommand
{


    public function __construct($plugin)
    {
        parent::__construct('event', $plugin);
        $this->setDescription('Event sistemi');
        $this->main = $plugin;
        $this->data = new Config($this->main->getDataFolder()."config.yml", Config::YAML);
    }


    public function execute(CommandSender $p, string $commandLabel, array $args): bool
    {
    						if ($p->hasPermission("event.admin")){
        if(!$p instanceof Player){
            $p->sendMessage("§cBu komut yalnızca oyunda kullanılabilir.");
            return false;
        }
        if(count($args) < 1){
            $p->sendMessage("§fKullanım: §e/event <pos1|pos2|baslat|soru>");
            return false;
        }
        if($args[0] == "baslat"){
        	if(!$p->isOp()) return true;
            if(!empty($this->data->get("pos1")) && !empty($this->data->get("pos2"))){
                $this->main->eventBaslat();
            } else {
                $p->sendMessage("§cEvent yapmadan önce alan seçmen gerekiyor.");
            }
        }
        if($args[0] == "pos1"){
               	if(!$p->isOp()) return true; $this->data->set("pos1", $p->getX().":".$p->getY().":".$p->getZ().":".$p->getLevel()->getFolderName());
            $this->data->save();
            $p->sendMessage("§a1.blok başarıyla seçildi.");
        }
        if($args[0] == "pos2"){
               	if(!$p->isOp()) return true; $this->data->set("pos2", $p->getX().":".$p->getY().":".$p->getZ().":".$p->getLevel()->getFolderName());
            $this->data->save();
            $p->sendMessage("§a2.blok başarıyla seçildi.");
            $p->sendMessage("§aEvent alanı hazır.");
        }
        if($args[0] == "soru"){
            $apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

            $for = $apii->createCustomForm(function (Player $p, array $data = null) {
                $result = $data;
                if ($result === null) {
                    return true;
                }
                $this->main->cevap = strtolower($data[1]);
                $this->main->getServer()->broadcastMessage("§aSoru Eventi §8» §e" . $data[0]);
            });
            $for->setTitle("§6Silver§fMCPE §r- Soru Sor");
            $for->addInput("Soru", "Örn: Mustafa Kemal Atatürk hangi yılda doğmuştur?");
            $for->addInput("Cevap", "Örn: 1881");
            $for->sendToPlayer($p);
        }


}else{
$p->sendMessage("Yetkin yok");
}
        return true;
    }


}