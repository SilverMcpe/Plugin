<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
    Command,
    PluginCommand,
    ConsoleCommandSender,
    CommandSender
};
use pocketmine\item\Item;
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;
use korado531m7\InventoryMenuAPI\{
	InventoryMenu,
	InventoryType,
	inventory\ChestInventory,
	event\InventoryClickEvent
};

class Mobsp extends PluginCommand{

    public $mobs = [
        "Koyun" => "Sheep",
        "Domuz" => "Pig",
        "İnek" => "Cow",
        "Tavuk" => "Chicken",
        "Örümcek" => "Spider",
        "İskelet" => "Skeleton",
        "Blaze" => "Blaze",
        "Zombi" => "Zombie",
        "Creeper" => "Creeper",
        "Golem" => "Iron_Golem"
    ];

    public function __construct($plugin){
        parent::__construct('mobsp', $plugin);
        $this->setDescription('Mob Spawner');
        $this->main = $plugin;

    }


    public function fiyat($mob){
        $cfg = new Config($this->main->getDataFolder() . "Ayarlar.json", Config::JSON);
        $fiyat = $cfg->get($mob);
        return $fiyat;
    }

    public function execute(CommandSender $p, string $commandLabel, array $args): bool
    {

             $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
             $form = $api->createSimpleForm(function (Player $p, int $data = null){
				 $items = array();
				 if($data === null){
				 	return true;
				 }

				 $items[0] = Item::get(52, 0, 1);
				 $items[0]->setCustomName("§r§fKoyun Spawner");
				 $items[0]->setLore(["Koyun"]);
				 $fiyat[0] = $this->fiyat("Koyun");

				 $items[1] = Item::get(52, 0, 1);

				 $items[1]->setCustomName("§r§eDomuz Spawner");
				 $items[1]->setLore(["Domuz"]);
				 $fiyat[1] = $this->fiyat("Domuz");
				 $items[2] = Item::get(52, 0, 1);

				 $items[2]->setCustomName("§r§3İnek Spawner");
				 $items[2]->setLore(["İnek"]);
				 $fiyat[2] = $this->fiyat("İnek");
				 $items[3] = Item::get(52, 0, 1);

				 $items[3]->setCustomName("§r§aTavuk Spawner");
				 $items[3]->setLore(["Tavuk"]);
				 $fiyat[3] = $this->fiyat("Tavuk");

				 $items[4] = Item::get(52, 0, 1);

				 $items[4]->setCustomName("§r§1Örümcek Spawner");
				 $items[4]->setLore(["Örümcek"]);
				 $fiyat[4] = $this->fiyat("Örümcek");
				 $items[5] = Item::get(52, 0, 1);

				 $items[5]->setCustomName("§r§2İskelet Spawner");
				 $items[5]->setLore(["İskelet"]);
				 $fiyat[5] = $this->fiyat("İskelet");
				 $items[6] = Item::get(52, 0, 1);

				 $items[6]->setCustomName("§r§3Zombi Spawner");
				 $items[6]->setLore(["Zombi"]);
				 $fiyat[6] = $this->fiyat("Zombi");
				 $items[7] = Item::get(52, 0, 1);

				 $items[7]->setCustomName("§r§4Blaze Spawner");
				 $items[7]->setLore(["Blaze"]);
				 $fiyat[7] = $this->fiyat("Blaze");
				 $items[8] = Item::get(52, 0, 1);
				 $items[8]->setCustomName("§r§5Creeper Spawner");
				 $items[8]->setLore(["Creeper"]);
				 $fiyat[8] = $this->fiyat("Creeper");
                 $items[9] = Item::get(52, 0, 1);
                 $items[9]->setCustomName("§r§6Golem Spawner");
                 $items[9]->setLore(["Golem"]);
                 $fiyat[9] = $this->fiyat("Golem");
				 $eco = $this->main->getServer()->getPluginManager()->getPlugin("EconomyAPI");
				 if($eco->mymoney($p) >= $fiyat[$data]){
				 	$eco->reduceMoney($p, $fiyat[$data], true);
					 $p->getInventory()->addItem($items[$data]);
				 }else{
				 	$p->sendMessage("Paran yetersiz");
				 }

			 });
             $form->setTitle("MobSpawner");
             $form->addButton("Koyun\n". $this->fiyat("Koyun"));
             $form->addButton("Domuz\n". $this->fiyat("Domuz"));
             $form->addButton("Inek\n" . $this->fiyat("İnek"));
             $form->addButton("Tavuk\n". $this->fiyat("Tavuk"));
             $form->addButton("Örümcek\n". $this->fiyat("Örümcek"));
             $form->addButton("İskelet\n". $this->fiyat("İskelet"));
             $form->addButton("Zombi\n". $this->fiyat("Zombi"));
             $form->addButton("Blaze\n". $this->fiyat("Blaze"));
             $form->addButton("Creeper\n". $this->fiyat("Creeper"));
             $form->addButton("Golem\n". $this->fiyat("Golem"));

        $form->sendToPlayer($p);





        return true;
    }



}
