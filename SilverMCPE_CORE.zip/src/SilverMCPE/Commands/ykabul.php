<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\math\Vector3;

class ykabul extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('ykabul', $plugin);
		$this->setDescription('Yardımcı isteği kabul etme.');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
        
            if(isset($this->main->yistek[$p->getName()])){
                $or = $this->main->getServer()->getPlayer($this->main->yistek[$p->getName()]);
                if($or instanceof Player){
                    $or->sendMessage("§6Silver§fMCPE §7» §aOyuncu isteğini kabul etti");
                }
                $this->cfg = new Config($this->main->getDataFolder() . $this->main->yistek[$p->getName()] . ".json", Config::JSON);
                $ortaklar = $this->cfg->get("Yardımcılar");
                $ortaklar[] = $p->getName();
                $this->cfg->set("Yardımcılar", $ortaklar);
                $this->cfg->save();   
                $this->pcfg = new Config($this->main->getDataFolder() . $p->getName() . ".json", Config::JSON);
                $ortaklar = $this->pcfg->get("IYardımcılar");
                $ortaklar[] = $this->main->yistek[$p->getName()];
                $this->pcfg->set("IYardımcılar", $ortaklar);
                $this->pcfg->setNested($this->main->yistek[$p->getName()] . ".BKo", true);
                $this->pcfg->setNested($this->main->yistek[$p->getName()] . ".BKı", true);
                $this->pcfg->setNested($this->main->yistek[$p->getName()] . ".CA", true);
                $this->pcfg->setNested($this->main->yistek[$p->getName()] . ".IA", true);
                unset($this->main->yistek[$p->getName()]);
                $this->pcfg->save();
                $p->sendMessage("§6Silver§fMCPE §7» §aYardımcı Eklendi");
    
            }else{
                $p->sendMessage("§6Silver§fMCPE §7» §cYardımcı isteği bulunamadı");
            }

      return true;
	}



	}