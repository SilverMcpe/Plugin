<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use onebone\economyapi\EconomyAPI;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;

class Spmarket extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('spmarket', $plugin);
		$this->setDescription('Spawner Market');
		$this->main = $plugin;
	}


	public function execute(CommandSender $o, string $commandLabel, array $args): bool
	{
				
				$folder = $this->main->getDataFolder();
			$this->cfg = new Config($folder . "Plugin Verileri/Spawnerlar.yml", Config::YAML);
			$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
			
			$form = $api->createSimpleForm(function (Player $o, int $args = null){
				$result = $args;
				if($result === null){

					return true;
				}

             
            $spawners = $this->cfg->get("Spawnerlar");
            foreach($spawners as $isim => $bilgi){
            $spawners2[] = $isim;
            $spawnersb[] = $bilgi["Fiyat"];
            }
        	
        	if ($spawners === null) {
        	$o->sendMessage("§7» §cSatın alma gerçekleşmedi");    
        	
        	}else{
        	$eco = $this->main->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        	$bilgif = $spawnersb[$result];
        	if ($eco->myMoney($o) >= $bilgif["SatınAl"]) {
        	$eco->reduceMoney($o->getName(), $bilgif["SatınAl"]);
        	$isim = $spawners2[$result];
        	if ($isim == "SpKazma") {
            $item = Item::get(278, 20, 1);
            $item->setLore([$isim]);
        	$item->setCustomName("§7» §e" .  $isim  ." §aSpawner §7«");
        	}else{
            $item = Item::get(52, 0, 1);
            $item->setLore([$isim . " 1"]);
        	$item->setCustomName("§7» §e" .  $isim  ." §aSpawner §7«");
        	}

        	$o->getInventory()->addItem($item);
        	$o->sendMessage("§6Silver§bMcpe §7» §e" . $isim . " §aspawnerı §e" . $bilgif["SatınAl"] . " §aTL'ye satın alındı");
        	}else{
        	$o->sendMessage("§6Silver§bMcpe §7» §cParan yetersiz.");
        	}
        
        	}
        	
        
       

		
			});
			
		 $form->setTitle("§6Silver§bMcpe §r-Spawner market");
		 $spc = $this->cfg->get("Spawnerlar");
	if (is_array($spc)) {
		foreach ($spc as $sp => $array) {
         	$fiya = $array["Fiyat"];
         	$fiyat = $fiya["SatınAl"];
            $form->addButton("§7» §e" . $sp . " §7«\n" . json_encode($fiyat));
         }
	}else{
	$fiya = $spc["Fiyat"];
         	$fiyat = $fiya["SatınAl"];
            $form->addButton($spc . "\n" . json_encode($fiyat));
	}
        
         $form->sendToPlayer($o);
	
      
      return true;
	}



	}