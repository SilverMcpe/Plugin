<?php


namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\entity\{Entity, Human};

class Top3 extends PluginCommand
{


	public function __construct($plugin)
	{
		parent::__construct('top3', $plugin);
		$this->setDescription('TOP3');
		$this->setPermission("admin.command");
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{
      if($p->isOp()){
      	if(count($args) > 0){
      		if($args[0] == 1){
				$this->spawnlaTop("1", $p);

			}
			if($args[0] == 2){
				$this->spawnlaTop("2", $p);

			}
			if($args[0] == 3){
				$this->spawnlaTop("3", $p);

			}

		}
	  }
      return true;
	}

	/**
	 * @param Int $d
	 * @param Player $p
	 */
	public function spawnlaTop(Int $b, Player $p): void{
		$this->cfg = new Config($this->main->getDataFolder() . "Top3.yml", Config::YAML);

		$nbt = Entity::createBaseNBT($p->add(0, 2));
		$skinTag = $p->namedtag->getCompoundTag("Skin");
		assert($skinTag !== null);
		$nbt->setTag(clone $skinTag);
		$entity = Entity::createEntity("Human", $p->getLevel(), $nbt);
		$entity->setHealth(1);
		$entity->setMaxHealth(1);
		$d = $p->getYaw();
		$d = (string) $d;
		if(45 < $d && $d < 135){
			$entity->setRotation(90, 0);
		}
		if(135 < $d && $d < 225){
			$entity->setRotation(180, 0);
		}

		if(225 < $d && $d < 315){
			$entity->setRotation(270, 0);
		}

		if(315 < $d || $d < 45){
			$entity->setRotation(360, 0);
		}
		if($b == 1){
			$entity->setNameTag("Güncellenicek-1");
			$entity->setScale(1.2);
			$en = $entity;
			$this->cfg->set(1, $en->getX() . ":". $en->getY() . ":". $en->getZ() .  ":" . $p->getLevel()->getFolderName());
			$this->cfg->save();

		}
		if($b == 2){
			$entity->setNameTag("Güncellenicek-2");
			$entity->setScale(1);
			$en = $entity;
			$this->cfg->set(2, $en->getX() . ":". $en->getY() . ":". $en->getZ() .  ":" . $p->getLevel()->getFolderName());
			$this->cfg->save();


		}
		if($b == 3){
			$entity->setNameTag("Güncellenicek-3");
			$entity->setScale(0.8);
			$en = $entity;
			$this->cfg->set(3, $en->getX() . ":". $en->getY() . ":". $en->getZ() .  ":" . $p->getLevel()->getFolderName());
			$this->cfg->save();

		}
		$entity->spawnToAll();

	}



}