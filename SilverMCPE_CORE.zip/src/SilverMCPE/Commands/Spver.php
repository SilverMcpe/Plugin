<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
    Command,
    PluginCommand,
    ConsoleCommandSender,
    CommandSender
};
use pocketmine\utils\Config;
use onebone\economyapi\EconomyAPI;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;

class Spver extends PluginCommand
{

    public $mobs = [
        "Koyun" => "Sheep",
        "Domuz" => "Pig",
        "İnek" => "Cow",
        "Tavuk" => "Chicken",
        "Iron Golem" => 20,
        "Örümcek" => "Spider",
        "İskelet" => "Skeleton",
        "Blaze" => "Blaze",
        "Zombi" => "Zombie"
    ];

    public function __construct($plugin)
    {
        parent::__construct('spver', $plugin);
        $this->setDescription('Spawner Verme');
        $this->main = $plugin;
    }


    public function execute(CommandSender $o, string $commandLabel, array $args): bool
    {
        if ($o->hasPermission("spver.yetki")) {
            if (isset($args[0]) && isset($args[1])) {
                $p = $this->main->getServer()->getPlayer($args[0]);
                echo 5;
                if ($args[1] == "SpKazma") {
                    $item = Item::get(278, 0, 1);
                    $item->setLore(["Spawner Kazması"]);
                    $item->setCustomName("§7» §aSpawner Kazma §7«");
                    $p->getInventory()->addItem($item);
                    return true;
                }
                echo 4;
                $this->cfg = new Config($this->main->getDataFolder() . "Plugin Verileri/Spawnerlar.yml", Config::YAML);
                $spawners = $this->cfg->get("Spawnerlar");
                foreach ($spawners as $isim => $bilgi) {
                    $spawners2[] = $isim;
                }
                echo 3;

                $deger = array_search($args[1], $spawners2);
                $isim = $spawners2[$deger];
                if ($isim == $args[1]) {
                    echo 2;
                    if ($p instanceof Player) {
                        echo 0;
                        if (isset($isim)) {
                            echo 1;
                            $item = Item::get(52, 0, 1);
                            $item->setLore([$isim . " 1"]);
                            $item->setCustomName("§7» §e" . $isim . " §aSpawner §7«");
                            $p->getInventory()->addItem($item);
                            $p->sendMessage("§6Silver§bMcpe §7» §e" . $o->getName() . " §esize §a" . $isim . "§e spawner verdi");
                            $o->sendMessage("§6Silver§bMcpe §7» §e" . $p->getName() . " §eadlı oyuncuya §a" . $isim . "§e spawner verildi");
                        } else {

                        }
                    } else {

                    }
                } else {
                    if ($p instanceof Player) {
                        $item = Item::get(52, 0, 1);
                        $item->setCustomName("§r§1" . $args[1] . " Spawner");
                        $item->setLore([$args[1]]);
                        $p->getInventory()->addItem($item);
                        $p->sendMessage($args[1] . " Spawner verildi.");
                    } else {
                        $this->cfg = new Config($this->main->getDataFolder() . "Plugin Verileri/OffSp.yml", Config::YAML);
                        $this->cfg->set($args[0], $args[1]);
                        $this->cfg->save();
                    }


                }


            } else {
                $o->sendMessage("§7» §c/spver <oyuncu ismi> <spawner türü>");
            }
        } else {
            $o->sendMessage("§6Silver§bMcpe §7» §cBu komutu kullanma yetkin yok");
        }

        return true;
    }


}