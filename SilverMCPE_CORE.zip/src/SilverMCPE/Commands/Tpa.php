<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;

class Tpa extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('tpa', $plugin);
		$this->setDescription('Oyuncuya ışınlanma isteği gönderir');
		$this->main = $plugin;

	}


	public function execute(CommandSender $p, string $commandLabel, array $args): bool
	{

		if(isset($args[0])){

			$o = $this->main->getServer()->getPlayer($args[0]);
			if ($o instanceof Player) {
				if ($o->getName() == $p->getName()) {
					$p->sendMessage("§6Silver§fMCPE §7» §cKendine Tpa yolluyamazsın");
				}else{
					$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $o->getName() . ".yml", Config::YAML);
					if ($this->cfg->get("Tpa") == true) {
						$this->main->istek[$o->getName()] = $p->getName();
						$p->sendMessage("§6Silver§fMCPE §7» §aİstek gönderildi.");
						$o->sendMessage("§6Silver§fMCPE §7» §c".$p->getName() ." §asana ışınlanma isteği gönderdi kabul etmek için /tpak reddetmek için /tpar");
					}else{
						$p->sendMessage("§6Silver§fMCPE §7» §cOyuncunun tpa istekleri kapalı.");
					}

				}
			}else{
				$p->sendMessage("§6Silver§fMCPE §7» §cOyuncu bulunamadı.");
			}

			return true;
		}
				$apii = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

		$for = $apii->createCustomForm(function (Player $p, array $data = null) {
		$result = $data;
	if ($result === null) {
			return true;
		}
					foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
						$oyuncular[] = $o;
					}
					$o = $oyuncular[$data[0]];
			if ($o instanceof Player) {
				if ($o->getName() == $p->getName()) {
                $p->sendMessage("§6Silver§fMCPE §7» §cKendine Tpa yolluyamazsın");
				}else{
									$this->cfg = new Config($this->main->getDataFolder() . "Oyuncu Verileri/" . $o->getName() . ".yml", Config::YAML);
                    if ($this->cfg->get("Tpa") == true) {
                    					$this->main->istek[$o->getName()] = $p->getName();
				$p->sendMessage("§6Silver§fMCPE §7» §aİstek gönderildi.");
				$o->sendMessage("§6Silver§fMCPE §7» §c".$p->getName() ." §asana ışınlanma isteği gönderdi kabul etmek için /tpak reddetmek için /tpar");
                    }else{
$p->sendMessage("§6Silver§fMCPE §7» §cOyuncunun tpa istekleri kapalı.");
			}

			}
			}else{
				$p->sendMessage("§6Silver§fMCPE §7» §cOyuncu bulunamadı.");
			}

	});
		$for->setTitle("§6Silver§fMCPE §r- Tpa");
					foreach ($this->main->getServer()->getOnlinePlayers() as $o) {
						$oyuncular[] = $o->getName();
					}
		$for->addDropdown("Oyuncu Seç", $oyuncular);
		$for->sendToPlayer($p);


      return true;
	}



	}