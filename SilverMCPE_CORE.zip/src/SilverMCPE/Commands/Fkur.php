<?php

namespace SilverMCPE\Commands;

use pocketmine\command\{
	Command,
	PluginCommand,
	ConsoleCommandSender,
	CommandSender
};
use pocketmine\utils\Config;
use pocketmine\Player;

class Fkur extends PluginCommand{


	public function __construct($plugin){
		parent::__construct('fkur', $plugin);
		$this->setDescription('Fabrika Kurma');
		$this->main = $plugin;
	}


	public function execute(CommandSender $g, string $commandLabel, array $args): bool
	{
		      
            if ($g->hasPermission("yetki.fabrika")) {

            $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");

            $form = $api->createCustomForm(function (Player $g, array $data = null) {
                $result = $data[0];
                if ($result === null) {
                    return true;
                }
				$tur = array("Vip", "Kömür", "Demir", "Altın", "Elmas", "Zümrüt", "Çim", "Cam", "Kum", "Kırıktaş", "Taş", "Toprak", "Tohum", "Buğday", "Havuç", "Patates", "Ekmek", "Elma");

                $this->main->tur[$g->getName()] = $tur[$data[0]];
                $g->sendMessage("§7» §aBir tabelaya tıkla ama tabelanın altında sandık olmalı yoksa çalışmaz");

            });

				$s = array("Vip", "Kömür", "Demir", "Altın", "Elmas", "Zümrüt", "Çim", "Cam", "Kum", "Kırıktaş", "Taş", "Toprak", "Tohum", "Buğday", "Havuç", "Patates", "Ekmek", "Elma");
            foreach ($s as $ks) {
                $fabrika[] = $ks;
            }
            $form->setTitle("§c§k!§r §bFabrika §c§k!§r");
            $form->addDropdown("§bTür", $fabrika);
            $form->sendToPlayer($g);
        }
        return true;
        }
       



	}