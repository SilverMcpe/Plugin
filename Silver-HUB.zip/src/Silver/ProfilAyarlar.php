<?php

namespace Silver;

use pocketmine\form\MenuForm;
use pocketmine\form\MenuOption;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use jojoe77777\FormAPI\SimpleForm;

class ProfilAyarlar implements Listener{
	
	/** @var Main */
	private $plugin;

	public function __construct(Main $plugin){
		$this->plugin = $plugin;
	}
	
	public function ClickItem(PlayerInteractEvent $e){
        $p = $e->getPlayer();
        $item = $e->getItem();
        $meta = $item->getDamage();
        $level = $p->getLevel();
        if(empty($this->second[$p->getName()])){
            $this->second[$p->getName()] = strtotime("-1seconds");
        }
        if(strtotime("now") > $this->second[$p->getName()] || $p->isOp()){
            if($item->getId() == 467 && $item->getCustomName() == "Profil & Ayarlar"){
                $this->SettingsForm($p);
                $this->second[$p->getName()] = strtotime("+5seconds");
            }
            }else{
            $p->sendMessage("§7»§a Elinizdeki eşyayı çok hızlı kullanıyorsunuz.");
        }

    }
    
    public function SettingsForm($sender){
            $form = new SimpleForm(function (Player $p, int $data = null) {
                if ($data == null) {
                    return true;
                }
                switch ($data) {
                    case 0:
                        $sender->sendForm(new PetForm());

                        break;
                    case 1:
                        $this->transfer($p, "mg");
                        break;
                }
            });
            $form->setTitle("Profil & Ayarlar");
            $form->addButton("Profil");
            $form->addButton("Ayarlar");
            $form->sendToPlayer($sender);
        }
	
	}//class