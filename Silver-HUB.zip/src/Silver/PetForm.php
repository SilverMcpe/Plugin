<?php

namespace  Silver;

use pocketmine\entity\{Entity, Zombie};
use pocketmine\form\CustomForm;
use pocketmine\form\CustomFormResponse;
use pocketmine\form\element\Dropdown;
use pocketmine\form\element\Input;
use pocketmine\form\element\Label;
use pocketmine\form\element\Button;
use pocketmine\utils\TextFormat;
use pocketmine\Player;
use pocketmine\math\Vector3;

class PetForm extends CustomForm
{

    public $perms = [
        "silver.vip",
        "silver.vipplus",
        "silver.mega"
    ];
	private $pets = ["Kaldır", "Domuz", "Kedi",  "Kurt", "Köylü", "Zombi", "Slime", "Iskelet", "Tavuk", "At", "Inek", "Magma küp"];

	public $petent = [
		"Domuz" => "Pig",
		"Kedi" => "Cat",
        "Kurt" => "Wolf",
        "Köylü" => "Villager",
        "Zombi" => "Zombie",
        "Slime" => "Slime",
		"Iskelet" => "Skeleton",
        "Tavuk" => "Chicken",
		"At" => "Horse",
		"Inek" => "Cow",
		"Magma küp" => "MagmaCube"

	];
	public static $instance;
	
public function __construct()
	{
		self::$instance = $this;{

		parent::__construct("Pet", [
			new Label("", ""),
			new Dropdown("Pet", "Pet Cinsi:", $this->pets),
			new Input("name", "Pet isimi"),
			//new Buttons("buton", "Geri Dön")
		], function (Player $p, CustomFormResponse $res): void{
			$value = $res->getInt("Pet");
			$pet = $this->pets[$value];
			if ($value == 0){
				if (isset(Main::getInstance()->id[$p->getName()])) {
					$ent = $p->getLevel()->getEntity(Main::getInstance()->id[$p->getName()]);
					if ($ent != null) {
						if (!($ent instanceof Player)) {
						    $p->sendMessage("Pet kaldırıldı.");
						$p->sendForm(new KozForm());
						    $ent->close();
							unset(Main::getInstance()->id[$p->getName()]);
						}
					}
				}else{
					$p->sendMessage("§cPet bulunamadı.");
				}
				return;
			}
            $pet = $this->pets[$value ];
            if (isset(Main::getInstance()->id[$p->getName()])) {
				$ent = $p->getLevel()->getEntity(Main::getInstance()->id[$p->getName()]);
				if ($ent != null) {
					if (!($ent instanceof Player)) {
						$ent->close();

					}
				}
			}
			if (!$this->perm($value, $p)){
			    $p->sendMessage("Bu peti alamazsınız.");
                return;
            }
			if (empty($res->getString("name"))){
				$this->petSpawn($p, $pet, null);
			}else{
				$this->petSpawn($p, $pet, $res->getString("name"));

			}
			if(empty($res->getString("buton"))){

			}else{
				$p->sendForm(new KozForm());
			}
		});
	}
}


    /**
     * @param int $index
     * @param Player $p
     * @return bool
     */
	public function perm(int $index, Player $p): bool {

	    if ($index > 1 and $index < 5) return $p->hasPermission($this->perms[0]);
        if ($index > 4 and $index < 8) return $p->hasPermission($this->perms[1]);
        if ($index > 7 and $index < 11) return $p->hasPermission($this->perms[2]);
        return true;
    }

    public function petSpawn(Player $p, $pet, $name = null){
		$value = array_search($pet, $this->pets);
		$nbt = Entity::createBaseNBT(new Vector3((int)$p->x, (int)$p->y, (int)$p->z));
		$entity = Entity::createEntity($this->petent[$pet], $p->getLevel(), $nbt);
		if ($name == null){
			$entity->setNameTag(TextFormat::RED. $this->pets[$value] . TextFormat::GRAY ."\n§c §7".$p->getName());
		}else{
			$entity->setNameTag(TextFormat::RED. $name ."\n§c §7".$p->getName());
		}
		if ($this->pets[$value] == "Slime" || $this->pets[$value] == "Magma küp"){
			$entity->setScale(1);
		}
		$entity->spawnToAll();
		$p->sendMessage("Pet aktif edildi.");
		Main::getInstance()->id[$p->getName()] = $entity->getId();
	}


}