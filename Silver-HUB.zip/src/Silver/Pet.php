<?php

namespace Silver;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\utils\CommandException;
use pocketmine\Player;

class Pet extends Command{

    public function __construct()
    {
        parent::__construct("pet", "Pet münüsü");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player){
            $sender->sendForm(new PetForm());
        }
    }
}