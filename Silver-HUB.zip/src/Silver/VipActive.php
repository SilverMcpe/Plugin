<?php

namespace Silver;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\utils\CommandException;
use pocketmine\utils\Config;

class VipActive extends Command
{

    public function __construct()
    {
        parent::__construct("aktivasyon", "Deponuzdaki ürünleri aktif etmenizi sağlar");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        $cfg = new Config(Main::getInstance()->getDataFolder() . "vips.json", Config::JSON);
        $vips = $cfg->get($sender->getName());
        if (is_array($vips)) {
            if (!(count($vips) > 0)) {
                $sender->sendMessage("Depon boş.");
                return;
            }
        }else{
            $sender->sendMessage("Depon boş.");
            return;
        }
    }
}