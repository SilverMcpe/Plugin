<?php

namespace Silver;

use pocketmine\form\MenuForm;
use pocketmine\form\MenuOption;
use pocketmine\entity\{Entity, Zombie};
use pocketmine\form\CustomForm;
use pocketmine\form\CustomFormResponse;
use pocketmine\form\element\Dropdown;
use pocketmine\form\element\Input;
use pocketmine\form\element\Label;
use pocketmine\utils\TextFormat;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use jojoe77777\FormAPI\SimpleForm;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\utils\CommandException;
use Silver\ParticleForm;

class KozForm implements Listener{
	
	
	/** @var Main */
	private $plugin;
	private $main;

	public function __construct(Main $plugin){
		$this->plugin = $plugin;
		$this->f = new PetForm($this->plugin);
    $this->f = new ParticleForm($this->plugin);
	}
	
	public function ClickItem(PlayerInteractEvent $e){
        $p = $e->getPlayer();
        $item = $e->getItem();
        $meta = $item->getDamage();
        $level = $p->getLevel();
        if(empty($this->second[$p->getName()])){
            $this->second[$p->getName()] = strtotime("-1seconds");
        }
        if(strtotime("now") > $this->second[$p->getName()] || $p->isOp()){
            if($item->getId() == 130 && $item->getCustomName() == "Kozmetik"){
                $this->CosmeticForm($p);
                $this->second[$p->getName()] = strtotime("+5seconds");
            }
            }else{
            $p->sendMessage("§7»§a Elinizdeki eşyayı çok hızlı kullanıyorsunuz.");
        }

    }
    


    public function CosmeticForm($p){
        $form = new SimpleForm(function (Player $p, $data = null){
            $re = $data;
            if($re === null){
                return true;
            }
            switch($re){     
                case 0:
                    $p->sendForm(new PetForm());
                break;
                case 1:
                    if($p->hasPermission("cosmeticmenu.particles.blizzardaura")){
                        $name = $p->getName();
                        
                        if(!in_array($name, $this->main->particle3)) {

                            $this->main->particle3[] = $name;

                            }
                    };
                break;
            }
        });
        $form->setTitle("Kozmetik");
        $form->addButton("Pet");
        $form->addButton("Partikul");
        $form->sendToPlayer($p);

    }
    
    public function ParticleForm($p){
        $form = new SimpleForm(function (Player $p, $data = null){
            $re = $data;
            if($re === null){
                return true;
            }
            switch($re){     
                case 0:
                    $p->sendForm(new PetForm());
                break;
                case 1:
                    $p->sendForm(new ParticleForm(Main::getInstance()));;
                break;
            }
        });
        $form->setTitle("Partikul");
        $form->addButton("Pet");
        $form->addButton("Partikul");
        $form->sendToPlayer($p);

    }


        
		
	
	}//class