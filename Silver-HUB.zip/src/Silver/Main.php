<?php

namespace Silver;

use jojoe77777\FormAPI\SimpleForm;
use libpmquery\PMQuery;
use libpmquery\PmQueryException;

use MongoDB\BSON\Binary;
use pocketmine\entity\Monster;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\utils\Config;
use pocketmine\utils\MainLogger;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\network\mcpe\protocol\ScriptCustomEventPacket;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Item;
use pocketmine\block\Block;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use slapper\events\SlapperCreationEvent;
use slapper\events\SlapperDeletionEvent;

use Silver\KozForm;
use Silver\ParticleForm;
use Silver\BlizzardAura;

class Main extends PluginBase implements Listener
{
	
	public $particle3 = array("Blizzard Aura");

    public $rcons = [];
    /**@var Main*/
    public static $instance;

    public static function getInstance(){
        return self::$instance;
    }
    public function onEnable()
    {
        $this->rcons["Fabrikacraft"] = new Rcon("88.198.34.234", "10289", "", "3");
        $this->rcons["Minigames"] = new Rcon("88.198.34.234", "10289", "sifre", "3");
        

        self::$instance = $this;
        $this->getScheduler()->scheduleRepeatingTask(new UpdateTask($this), 20);
        $this->getScheduler()->scheduleRepeatingTask(new BlizzardAura($this), 3);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
$this->loadTasks();
$event = $this->getServer()->getPluginManager();
        $event->registerEvents($this, $this);
        $event->registerEvents(new KozForm($this), $this);
       // $event->registerEvents(new ParticleForm($this), $this);
        $this->getServer()->getCommandMap()->register("pet", new Pet());
        
        $particlePath = $this->getDataFolder()."particles.yml";
		$this->particleconfig = new Config($particlePath, Config::YAML);
		$this->particleconfig->getAll();
		if($this->particleconfig->getNested("Particles.Enable")){
			$this->particleSupport = true;
			$this->particleFormContent = $this->particleconfig->getNested("Particles.Form-Content");
			if($this->raincloud = $this->particleconfig->getNested("Blizzard-Aura.Enable")){
				$this->raincloud = true;
			}
			} else {
			$this->particleSupport = false;
		}
    }
    private function loadTasks() : void {
		$this->getScheduler()->scheduleRepeatingTask(new BlizzardAura($this), 3);
		}

    public function onDamage(EntityDamageEvent $event){
        if (!($event->getEntity() instanceof Player)) $event->setCancelled();
    }

    public function onQuit(PlayerQuitEvent $event){
        $player = $event->getPlayer();
        if (isset($this->id[$player->getName()])) {
            $entity = $player->getLevel()->getEntity($this->id[$player->getName()]);
            if ($entity != null) {
                $entity->close();
            }
        }
    }
    function getParticleForm() : ParticleForm {
		return $this->particles;
	}
    public function onMove(PlayerMoveEvent $event)
    {
        $player = $event->getPlayer();
        if (isset($this->id[$player->getName()])) {
            $entity = $player->getLevel()->getEntity($this->id[$player->getName()]);
            if ($entity != null) {
                $entity->lookAt($player);
                $motion = clone $player->subtract($entity)->normalize();
                $dx = (int)$entity->x - (int)$player->x;
                $dy = (int)$entity->y - (int)$player->y;
                if ($dx < -5 || 5 < $dx || $dy < -5 || $dy > 5) {
                    $entity->teleport($player);
                } else {
                    $entity->move($motion->x + 0.7, $motion->y, $motion->z + 0.7);
                }

            }
        }
    }
    public function onSlapperCreate(SlapperCreationEvent $ev)
    {
        $entity = $ev->getEntity();
        $lines = explode("\n", $entity->getNameTag());
        $line = count($lines);
        if ($this->isValidIP($lines[0]) or $this->is_valid_domain_name($lines[0])) {
            $entity->namedtag->setString("server", $lines[0]);
            $this->update();
        }
    }

    public function isValidIP(string $ip)
    {
        return (preg_match("/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})/", $ip) !== false);
    }

    public function is_valid_domain_name(string $domain_name)
    {
        return (preg_match("/([a-z\d](-*[a-z\d])*)(\.([a-z\d](-*[a-z\d])*))*:(\d{1,5})/i", $domain_name) //valid chars check
            and preg_match("/.{1,253}/", $domain_name) //overall length check
            and preg_match("/[^\.]{1,63}(\.[^\.]{1,63})*/", $domain_name)); //length of each label
    }

    public function onJoin(PlayerJoinEvent $e)
    {
        $p = $e->getPlayer();
        /*if ($p->getAddress() != "127.0.0.1"){
            $e->setCancelled();
            $p->kick("hub üzerinden bağlanınız");
                return;
        }*/
        $cfg = new Config($this->getDataFolder()."vips.json", Config::JSON);
        $vips = $cfg->get($p->getName());
        if (is_array($vips)){
           if (count($vips) > 0){
               $p->sendMessage("Deponda aktif tagların bulunmakta aktif etmek için /aktivasyon yazabilirsin.");
           }
        }
    }
    
    public function onPlayerJoin(PlayerJoinEvent $e)
    {
        $player = $e->getPlayer()->getInventory();
        $player->clearAll();
        $player->setItem(0, Item::get(Item::ENDER_CHEST, 0, 1)->setCustomName("Kozmetik"));
        $player->setItem(4, Item::get(Item::COMPASS, 0, 1)->setCustomName("Sunucu Seçici"));
        $player->setItem(8, Item::get(Item::HEART_OF_THE_SEA, 0, 1)->setCustomName("Profil & Ayarlar"));
    }

    public function update()
    {
        foreach ($this->getServer()->getLevels() as $level) {
            foreach ($level->getEntities() as $entity) {

                try {

                    if (!empty($entity->namedtag->getString("server", ""))) {

                        $server = explode(":", $entity->namedtag->getString("server", ""));
                        try {
                            $query = PMQuery::query($server[0], $server[1], "4");
                            $online = (int)$query['Players'];
                            $lines = explode("\n", $entity->getNameTag());
                            $line = count($lines);

                            if ($server[0] == "88.99.247.98") {
                                $lines[0] = TextFormat::colorize("&l&b" . $online . " &l&ekişi aktif!");
                            } else {
                                $lines[0] = TextFormat::colorize("&l&b" . $online . " &l&ekişi aktif!!");
                            }
                            $nametag = implode("\n", $lines);
                            $entity->setNameTag($nametag);
                        } catch (PmQueryException $e) {
                            $this->getLogger()->logException($e);
                            $lines = explode("\n", $entity->getNameTag());
                            $line = count($lines);
                            $lines[0] = TextFormat::RED . "Sunucuya Kapalı" . TextFormat::WHITE;
                            $nametag = implode("\n", $lines);
                            $entity->setNameTag($nametag);
                        }
                    }
                } catch (\Exception $e) {
                }


            }
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        $rcon = new Rcon("88.198.50.237", "10289", "ahrametsit", "3");

        if ($command->getName() == "duyuru") {
            if ($sender->isOp()) {
                if (isset($args[0])) {
                    $this->getServer()->broadcastMessage("§7» §a" . implode(" ", $args));
                    if ($rcon->connect()) {
                        $rcon->sendCommand("duyuru " . implode(" ", $args));
                    }

                }
            }
            return true;
        } 
        }
 public function GameForm($sender){
            $form = new SimpleForm(function (Player $p, int $data = null) {
                if ($data == null) {
                    return true;
                }
                switch ($data) {
                    case 0:
                        $this->transfer($p, "fab");

                        break;
                    case 1:
                        $this->transfer($p, "mg");
                        break;
                }
            });
            try {
                $queryData = PMQuery::query("oyna.silvermcpe.net", 19132);
                $f = $queryData["Players"] . "/" . $queryData["MaxPlayers"];
            } catch (PmQueryException $e) {
                $f = "Kapalı";
            }
            $form->setTitle("Sunucu Seçici");
            $form->addButton("Skyblock\n[" . $f . "]");
            $form->addButton("Minigames\n[");
            $form->sendToPlayer($sender);
        }
    
    public function onItemHold(InventoryTransactionEvent $event){
        $transaction = $event->getTransaction();
        $p = $transaction->getSource();
        if(!$p->isOp()){
            $event->setCancelled(true);
        }else{

        }

    }
    
    public function ClickItem(PlayerInteractEvent $e){
        $p = $e->getPlayer();
        $item = $e->getItem();
        $meta = $item->getDamage();
        $level = $p->getLevel();
        if(empty($this->second[$p->getName()])){
            $this->second[$p->getName()] = strtotime("-1seconds");
        }
        if(strtotime("now") > $this->second[$p->getName()] || $p->isOp()){
            if($item->getId() == 288 && $item->getCustomName() == "§r§6Zıplama Tüyü"){
                $this->second[$p->getName()] = strtotime("+5seconds");
            }

            	if($item->getId() == 345 && $item->getCustomName() == "Sunucu Seçici"){
                $this->GameForm($p);
                $this->second[$p->getName()] = strtotime("+5seconds");
            }
        }else{
            $p->sendMessage("§7»§a Elinizdeki eşyayı çok hızlı kullanıyorsunuz.");
        }

    }
    
    public static function transfer(Player $player, string $server): bool
    {

        $pk = new ScriptCustomEventPacket();
        $pk->eventName = "bungeecord:main";
        $pk->eventData = Binary::writeShort(strlen("Connect")) . "Connect" . Binary::writeShort(strlen($server)) . $server;
        $player->sendDataPacket($pk);
        return true;
    }
public function Keep(PlayerDeathEvent $e){
    $e->setKeepInventory(true);
  }
}