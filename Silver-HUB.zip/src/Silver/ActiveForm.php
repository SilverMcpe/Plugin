<?php

namespace Silver;

use pocketmine\form\MenuForm;
use pocketmine\form\MenuOption;
use pocketmine\Player;
use pocketmine\utils\Config;

class ActiveForm extends MenuForm
{


    public function __construct(Player $player)
    {
        $buttons = [];
        $buttons[] = new Rcon("88.198.50.237", "10289", "ahrametsit", "3");

        $cfg = new Config(Main::getInstance()->getDataFolder() . "vips.json", Config::JSON);
        $vips = $cfg->get($player->getName());
        foreach ($vips as $vip) {
            $exp = explode(":", $vip);
            $buttons[] = new MenuOption($exp[0] . "\n" . $exp[1]);
        }
        parent::__construct("Aktivasyon", "", $buttons, function (Player $player, int $data): void {
            $cfg = new Config(Main::getInstance()->getDataFolder() . "vips.json", Config::JSON);
            $vips = $cfg->get($player->getName());
            $exp = explode(":", $vips[$data]);
            if (Main::getInstance()->rcons[$exp[1]]->connect()){
                Main::getInstance()->rcons[$exp[1]]->sendCommand("vipver ".$player->getName()." ".$exp[0]);
                $player->sendMessage("Ürün aktif edildi.");
                unset($vips[$data]);
                $cfg->set($player->getName(), $vips);
                $cfg->save();
                return;
            }
            $player->sendMessage("Ürün aktif edilemedi.");

        });
    }
}