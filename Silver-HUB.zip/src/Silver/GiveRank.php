<?php

namespace Silver;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class GiveRank extends Command{

    public function __construct()
    {
        parent::__construct("vipver", "Vip vermenizi sağlar.");
        $this->setPermission("silver.cmd.vipver");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$this->testPermission($sender)) return;
        if (count($args) >= 3){
           $cfg = new Config(Main::getInstance()->getDataFolder()."vips.json", Config::JSON);
           $vips = $cfg->get($args[0]);
           if (is_array($vips)){
               $vips[] = $args[1].":".$args[2];
           }else{
               $vips = [];
               $vips[] = $args[1].":".$args[2];
           }
           $cfg->set($args[0], $vips);
           $cfg->save();
           $sender->sendMessage("§aVip verildi.");
        }

    }
}