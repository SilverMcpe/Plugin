<?php

namespace SilverMcpe;

use pocketmine\plugin\PluginBase;
use pocketmine\{Player, Server};
use SilverMcpe\Vote\ServerListQuery;
use SilverMcpe\Vote\RequestThread;
use pocketmine\event\level\LevelLoadEvent;
use SilverMcpe\Vote\{Utils,PlayerVoteEvent};

use pocketmine\command\{Command,CommandSender,CommandExecutor,ConsoleCommandSender,PluginCommand};

use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use onebone\economyapi\EconomyAPI;

use pocketmine\item\Item;
use CortexPE\DiscordWebhookAPI\Message;
use CortexPE\DiscordWebhookAPI\Webhook;
use CortexPE\DiscordWebhookAPI\Embed;
use pocketmine\utils\{Random,TextFormat as R,TextFormat as TF,TextFormat as C,TextFormat,Config};

use SilverMcpe\EventListener;

class Main extends PluginBase implements Listener {
	
	public $p;
	private $message = "";
    private $items = [];
    private $commands = [];
    private $debug = false;
    public $queue = [];
	
	public function onLoad() {
        if(file_exists($this->getDataFolder() . "config.yml")) {
            $c = $this->getConfig()->getAll();
            if(isset($c["API-Key"])) {
                if(trim($c["API-Key"]) != "") {
                    if(!is_dir($this->getDataFolder() . "Lists/")) {
                        mkdir($this->getDataFolder() . "Lists/");
                    }
                    file_put_contents($this->getDataFolder() . "Lists/minecraftpocket-servers.com.vrc", "{\"website\":\"http://minecraftpocket-servers.com/\",\"check\":\"http://minecraftpocket-servers.com/api-vrc/?object=votes&element=claim&key=" . $c["API-Key"] . "&username={USERNAME}\",\"claim\":\"http://minecraftpocket-servers.com/api-vrc/?action=post&object=votes&element=claim&key=" . $c["API-Key"] . "&username={USERNAME}\"}");
                    rename($this->getDataFolder() . "config.yml", $this->getDataFolder() . "config.old.yml");
                    $this->getLogger()->info("§eConverting API key to VRC file...");
                } else {
                    rename($this->getDataFolder() . "config.yml", $this->getDataFolder() . "config.old.yml");
                    $this->getLogger()->info("§eSetting up new configuration file...");
                }
            }
        }
    }
	
	public function onEnable(){
		$this->getLogger()->info("\n§aSilverMcpe - Oy\n");
		$this->registerCommands();
		$this->registerEvents();
		$this->reload();
		$this->saveResource("ayarlar.yml");
        $this->ayarlar = new Config($this->getDataFolder() . "ayarlar.yml", Config::YAML);
		}
		
		private function registerCommands()
    {
        $map = $this->getServer()->getCommandMap();
        }
        
        
        private function registerEvents()
   {
        $event = $this->getServer()->getPluginManager();
        }
        
        public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
        $name = $sender->getName();
        
        switch ($command->getName()) {
            case "oy":
                if(isset($args[0]) && strtolower($args[0]) == "yenile") {
                    if(Utils::hasPermission($sender, "votereward.command.reload")) {
                        $this->reload();
                        $sender->sendMessage("[Oy] Tüm Düzenlemeler Yenilendi.");
                        break;
                    }
                    $sender->sendMessage("You do not have permission to use this subcommand.");
                    break;
                }
                if(!$sender instanceof Player) {
                    $sender->sendMessage("This command must be used in-game.");
                    break;
                }
                if(!Utils::hasPermission($sender, "votereward.command.vote")) {
                    $sender->sendMessage("You do not have permission to use this command.");
                    break;
                }
                if(in_array(strtolower($sender->getName()), $this->queue)) {
                    $sender->sendMessage("§8[§l§cX§r§8]§7 Oy Verip Vermediğini Kontrol Ediyoruz..");
                    break;
                }
                $this->queue[] = strtolower($sender->getName());
                $requests = [];
                foreach($this->lists as $list) {
                    if(isset($list["check"]) && isset($list["claim"])) {
                        $requests[] = new ServerListQuery($list["check"], $list["claim"]);
                    }
                }
                $query = new RequestThread(strtolower($sender->getName()), $requests);
                Server::getInstance()->getAsyncPool()->submitTask($query);
                break;
            default:
                $sender->sendMessage("Hatalı Komut.");
                break;
        }
        return true;
    }
public function reload() {
        $this->saveDefaultConfig();
        if(!is_dir($this->getDataFolder() . "Lists/")) {
            mkdir($this->getDataFolder() . "Lists/");
        }
        $this->lists = [];
        foreach(scandir($this->getDataFolder() . "Lists/") as $file) {
            $ext = explode(".", $file);
            $ext = (count($ext) > 1 && isset($ext[count($ext) - 1]) ? strtolower($ext[count($ext) - 1]) : "");
            if($ext == "vrc") {
                $this->lists[] = json_decode(file_get_contents($this->getDataFolder() . "Lists/$file"), true);
            }
        }
        /*$this->reloadConfig();
        $config = $this->getConfig()->getAll();
        $this->message = $config["Message"];
        $this->items = [];
        foreach($config["Items"] as $i) {
            $r = explode(":", $i);
            $this->items[] = new Item($r[0], $r[1], $r[2]);
        }
        $this->commands = $config["Commands"];
        $this->debug = isset($config["Debug"]) && $config["Debug"] === true ? true : false;*/
    }
        /*
        public function oyver($sender, $web) {
                	$web = new Webhook("https://discordapp.com/api/webhooks/774010096488415232/7Qunx4eF59wJQYgSl0VQv78rDC1Z6zlqSb6tIERaNzRVmeXa4DLTPb_zXHWSjZnJgAyW");
			$embed = new Embed();
			$msg = new Message();
       $embed->setTitle("www.silvermcpe.net");
       $embed->setColor(0xFFA900); 
       $embed->setDescription("** " . $sender->getName() . " ** sunucumuza oy verdi."); 
        $embed->setThumbnail("https://raw.githubusercontent.com/CortexPE/DiscordWebhookAPI/master/dwapi.png");
      $embed->setFooter("Oy ver: oy.silvermcpe.net","https://raw.githubusercontent.com/CortexPE/DiscordWebhookAPI/master/dwapi.png");
      $msg->addEmbed($embed); 
      $web->send($msg);
      }*/
                
                public function rewardPlayer($player, $multiplier) {
                	if(!$player instanceof Player) {
                		return;
                	}
                	if($multiplier < 1) {
                		$player->sendMessage("§6Silver§fMcpe §7» §cSunucuya oy vermemişsiniz.");
                		return;
                	}
                	$clones = [];
                	foreach($this->items as $item) {
                		$clones[] = clone $item;
                	}
                	foreach($clones as $item) {
                		$item->setCount($item->getCount() * $multiplier);
                		$player->getInventory()->addItem($item);
                	}
                	foreach($this->commands as $command) {
                		$this->getServer()->dispatchCommand(new ConsoleCommandSender, str_replace([
                			"{USERNAME}",
                			"{NICKNAME}",
                			"{X}",
                			"{Y}",
                			"{Y1}",
                			"{Z}"
                		], [
                			$player->getName(),
                			$player->getDisplayName(),
                			$player->getX(),
                			$player->getY(),
                			$player->getY() + 1,
                			$player->getZ()
                		], Utils::translateColors($command)));
                	}
                	if(trim($this->message) != "") {
                		$message = str_replace([
                			"{USERNAME}",
                			"{NICKNAME}"
                		], [
                			$player->getName(),
                			$player->getDisplayName()
                		], Utils::translateColors($this->message));
                		foreach($this->getServer()->getOnlinePlayers() as $p) {
                			$p->sendMessage($message);
                		}
                		$this->getServer()->getLogger()->info($message);
                	}
                	$item = Item::get(347,0,1);
                	$buyu = Enchantment::getEnchantment(0);
                	$buyu = new EnchantmentInstance($buyu, 0);
                	$item->addEnchantment($buyu);
                	$item->setCustomName("§6Oy Anahtarı");
                	$player->getInventory()->addItem($item);
                	EconomyAPI::getInstance()->addMoney($player, 5000);
                   $web = new Webhook("https://discordapp.com/api/webhooks/774010096488415232/7Qunx4eF59wJQYgSl0VQv78rDC1Z6zlqSb6tIERaNzRVmeXa4DLTPb_zXHWSjZnJgAyW");
			$embed = new Embed();
			$msg = new Message();
       $embed->setTitle("www.silvermcpe.net");
       $embed->setColor(0xFFA900); 
       $embed->setDescription("** " . $player->getName() . " ** sunucumuza oy verdi."); 
        $embed->setThumbnail("https://raw.githubusercontent.com/CortexPE/DiscordWebhookAPI/master/dwapi.png");
      $embed->setFooter("Oy ver: oy.silvermcpe.net","https://raw.githubusercontent.com/CortexPE/DiscordWebhookAPI/master/dwapi.png");
      $msg->addEmbed($embed); 
      $web->send($msg);
                	$player->sendMessage("§6Silver§fMcpe §7» §cSunucuya §7 $multiplier §coy Verdiginiz icin teşekkür ederiz." . ($multiplier == 1 ? "" : "s") . "!");
                }
		
        
		
	}//class
?>